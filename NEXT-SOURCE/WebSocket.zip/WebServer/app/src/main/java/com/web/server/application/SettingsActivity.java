package com.web.server.application;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.Preference;
import android.preference.Preference.OnPreferenceChangeListener;
import android.preference.PreferenceActivity;
import android.widget.Toast;

import com.web.server.R;
import com.web.server.engine.app.settings.Settings;
import com.web.server.engine.app.server.web.Intents;

public class SettingsActivity extends PreferenceActivity implements OnPreferenceChangeListener
{

    public static String TAG = SettingsActivity.class.getSimpleName();
    public static void startPreference(Context context){
        Intent mApplication = new Intent(context, SettingsActivity.class);
        context.startActivity(mApplication);
    }
    
    private final String KEY_SERVER_PORT = "edittext_server_port";
    private final String KEY_VERSION = "prdference_version";
    private EditTextPreference preferencePort;
    private Preference preferenceVersion;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.pref_server);
        preferencePort = (EditTextPreference) findPreference(KEY_SERVER_PORT);
        preferenceVersion = (Preference) findPreference(KEY_VERSION);
        if (preferencePort != null)
        {
            preferencePort.setOnPreferenceChangeListener(this);
            updatePreferences();
        }

        if (preferenceVersion != null)
        {
            try
            {
                preferenceVersion.setSummary(this.getPackageManager()
                                             .getPackageInfo(getPackageName(), 0).versionName);
            }
            catch (Exception e)
            {

            }
        }

    }

    private void updatePreferences()
    {
        if (preferencePort != null)
        {
            preferencePort.setText(String.valueOf(Settings.getPort()));
            preferencePort.setSummary(getResources().getString(R.string.web_server_port_summary, Settings.getPort()));
        }
    }

    @Override
    public boolean onPreferenceChange(Preference preference, Object newValue)
    {
        if (preference.getKey().equals(KEY_SERVER_PORT))
        {
            int port = Integer.parseInt(newValue.toString());
            if (port < 1024 || port > 65535)
            {
                Toast.makeText(this, R.string.web_server_port_invalid,
                               Toast.LENGTH_SHORT).show();
            }
            else
            {
                Settings.setPort(port);
                updatePreferences();
                Intent intent=new Intent(Intents.ACTION_RESTART_SERVER);
                sendBroadcast(intent);

            }

        }
        return false;
    }

}

