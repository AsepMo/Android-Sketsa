package com.web.server.application;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;

import com.web.server.R;
import com.web.server.engine.app.fragments.WebServerFragment;

public class ApplicationActivity extends FragmentActivity{
    
    public static String TAG = ApplicationActivity.class.getSimpleName();
      @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);
        switchFragment(new WebServerFragment());
    }
    
    public void switchFragment(Fragment fragment){
        getSupportFragmentManager()
        .beginTransaction()
        .replace(R.id.content_frame, fragment)
        .commit();
    }
}
