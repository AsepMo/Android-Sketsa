package com.web.server.engine.app.server.web;

public class Intents {
	public static final String ACTION_SERVER_STATE_CHANGE = "com.web.server.acction.SERVER_STATE_CHANGE";
	public static final String ACTION_RESTART_SERVER="com.web.server.acction.RESTART_SERVER";
}
