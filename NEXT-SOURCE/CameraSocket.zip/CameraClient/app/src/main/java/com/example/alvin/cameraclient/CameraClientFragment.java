package com.example.alvin.cameraclient;

import android.support.v4.app.Fragment;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PointF;
import android.graphics.drawable.BitmapDrawable;
import android.hardware.Camera;
import android.media.FaceDetector;
import android.os.AsyncTask;
import android.os.Handler;
import android.os.Message;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;
import java.net.Socket;

public class CameraClientFragment extends Fragment {

    public static String TAG = CameraClientFragment.class.getSimpleName();
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String EXTRA_CAMERA = "EXTRA_CAMERA";
    private String message;
    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    public static CameraClientFragment newInstance(String msg) {
        CameraClientFragment f = new CameraClientFragment();
        Bundle b = new Bundle();
        b.putString(EXTRA_CAMERA, msg);
        f.setArguments(b);

        return f;
    }
    
    public static String SERVER_IP = "192.168.43.1";
    public static final int SERVER_PORT = 9191;
    
    private MainActivity mActivity;
    private Context mContext;
    private TextView mStatus;
    private ImageView mCameraView;
    public MyClientThread mClient;
    public Bitmap mLastFrame;

    private int face_count;
    private Handler handler = new Handler(){
        @Override
        public void handleMessage(Message msg) {     
                try {
                    mLastFrame = (Bitmap) msg.obj;
                } catch (Exception e) {
                    e.printStackTrace();
                }
                super.handleMessage(msg);
            
        }
    };

    private FaceDetector mFaceDetector = new FaceDetector(320,240,10);
    private FaceDetector.Face[] faces = new FaceDetector.Face[10];
    private PointF tmp_point = new PointF();
    private Paint tmp_paint = new Paint();


    private Runnable mStatusChecker = new Runnable() {
        @Override
        public void run() {
            try {
                handler.post(new Runnable() {
                        @Override
                        public void run() {
                            if (mLastFrame!=null){

                                Bitmap mutableBitmap = mLastFrame.copy(Bitmap.Config.RGB_565, true);
                                face_count = mFaceDetector.findFaces(mLastFrame, faces);
                                Log.d("Face_Detection", "Face Count: " + String.valueOf(face_count));
                                Canvas canvas = new Canvas(mutableBitmap);

                                for (int i = 0; i < face_count; i++) {
                                    FaceDetector.Face face = faces[i];
                                    tmp_paint.setColor(Color.RED);
                                    tmp_paint.setAlpha(100);
                                    face.getMidPoint(tmp_point);
                                    canvas.drawCircle(tmp_point.x, tmp_point.y, face.eyesDistance(), tmp_paint);                                  
                                }

                                mCameraView.setImageBitmap(mutableBitmap);
                            }

                        }
                    }); //this function can change value of mInterval.
            } finally {
                // 100% guarantee that this always happens, even if
                // your update method throws an exception
                handler.postDelayed(mStatusChecker, 1000/15);
            }
        }
    };
    
    public CameraClientFragment() {
    }

    private View mRootView;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        message = getArguments().getString(EXTRA_CAMERA);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.fragment_app_camera_client, container, false);
        return mRootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mContext = getActivity();
        
        mCameraView = (ImageView) view.findViewById(R.id.camera_preview);
        mStatus = (TextView) view.findViewById(R.id.textView);
        mStatus.setText("IP : " + SERVER_IP); 
        new AsyncTask<Void, Void, Void>() {

            @Override
            protected Void doInBackground(Void... unused) {
                // Background Code
                Socket s;
                try {
                    s = new Socket(SERVER_IP, SERVER_PORT);
                    mClient = new MyClientThread(s, handler);
                    new Thread(mClient).start();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                return null;
            }

        }.execute();
        
        mStatusChecker.run();
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        
        mActivity = (MainActivity)getActivity();
    }
    
    
    public static Bitmap rotateImage(Bitmap source, float angle) {
        if (source != null){
            Bitmap retVal;

            Matrix matrix = new Matrix();
            matrix.postRotate(angle);
            retVal = Bitmap.createBitmap(source, 0, 0, source.getWidth(), source.getHeight(), matrix, true);
            source.recycle();
            return retVal;
        }
        return null;
    }
}
