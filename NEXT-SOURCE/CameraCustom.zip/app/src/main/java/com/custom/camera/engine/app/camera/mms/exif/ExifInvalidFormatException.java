package com.custom.camera.engine.app.camera.mms.exif;

public class ExifInvalidFormatException extends Exception {
    public ExifInvalidFormatException(String meg) {
        super(meg);
    }
}
