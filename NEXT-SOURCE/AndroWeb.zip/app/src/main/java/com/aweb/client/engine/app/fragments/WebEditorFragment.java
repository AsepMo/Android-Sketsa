package com.aweb.client.engine.app.fragments;

import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Environment;
import android.os.AsyncTask;
import android.util.Log;
import android.speech.RecognizerIntent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.webkit.WebView;
import android.webkit.WebChromeClient;
import android.webkit.JavascriptInterface;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;

import com.aweb.client.R;
import com.aweb.client.AppController;
import com.aweb.client.engine.widget.HtmlTextEditor;
import com.aweb.client.engine.app.folders.FolderMe;
import com.aweb.client.engine.app.folders.FileMe;
import java.io.File;
import android.support.annotation.Nullable;
import com.aweb.client.engine.app.tasks.SaveTask;
import com.aweb.client.engine.app.tasks.LoadTextTask;

public class WebEditorFragment extends Fragment {

    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_EXTRA_URL = "EXTRA_URL";
    private static final String TAG = WebEditorFragment.class.getSimpleName();

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    public static WebEditorFragment loadWeb(String url) {
        WebEditorFragment f = new WebEditorFragment();
        Bundle b = new Bundle();
        b.putString(ARG_EXTRA_URL, url);
        f.setArguments(b);

        return f;
    }

    public WebEditorFragment() {
    }

    private String url;
    private Context mContext;
    private TextView mTitle;
    private HtmlTextEditor htmlTextEditor;
    private boolean isRunning = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        url = getArguments().getString(ARG_EXTRA_URL);

        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater,  ViewGroup container, Bundle savedInstanceState) {

        return inflater.inflate(R.layout.fragment_app_web_editor, container, false);
    }

    @Override
    public void onViewCreated(View view,  Bundle savedInstanceState) {

        final String text = getArguments().getString(ARG_EXTRA_URL);
        mContext = getActivity();
        htmlTextEditor = (HtmlTextEditor)view.findViewById(R.id.html_editor);
        mTitle = (TextView)view.findViewById(R.id.web_editor);
        mTitle.setText(text);
        
    }

    public boolean isRunning() {
        isRunning = htmlTextEditor.canGoBack();
        return isRunning;
    }

    public void goBack(){
        htmlTextEditor.goBack();
    }
    
    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu_web_editor, menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // TODO: Implement this method
        switch (item.getItemId()) {
            case R.id.action_save:
                saveToFile();
                FileMe.getInstance().WebMe(FolderMe.FOLDER_WEB_EDITOR, FileMe.INDEX_HTML, htmlTextEditor.getText());                  
                break;
            case R.id.action_load:
                loadFromFile();
                FileMe.readFromStorage(FolderMe.FOLDER_WEB_EDITOR, FileMe.INDEX_HTML, htmlTextEditor);
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.v(TAG, "onResume:");   

    }

    @Override
    public void onPause() {
        super.onPause();
        Log.v(TAG, "onPause:");
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.v(TAG, "onDestroy:");
    }

    public void saveToFile(){
        File mFileMe = new File(FolderMe.FOLDER_WEB_EDITOR, FileMe.INDEX_HTML);
        if (!mFileMe.exists()) {
            new SaveTask(htmlTextEditor.getText(), mFileMe).start();
            
        }
    }
    
    public void loadFromFile(){
        File mFileMe = new File(FolderMe.FOLDER_WEB_EDITOR, FileMe.INDEX_HTML);
        if (!mFileMe.exists()) {
            new LoadTextTask(htmlTextEditor, true).execute(mFileMe);

        }
    }
}
