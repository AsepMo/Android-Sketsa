package com.aweb.client.engine.app.folders;

import android.util.Log;

import java.io.File;

public class IndexChecker {
    private static final String TAG = IndexChecker.class.getSimpleName();

    /**
     * Contains all possible places to check binaries
     */
    private static final String[] pathList;

    private static final String KEY_INDEX_HTML = "index.html";

    static {
        pathList = new String[]{
            FolderMe.FOLDER_WEB_EDITOR
        };
    }

    public static boolean isExists() {
        return doesFileExists(KEY_INDEX_HTML);
    }

    /**
     * Checks the all path until it finds it and return immediately.
     *
     * @param value must be only the binary name
     * @return if the value is found in any provided path
     */
    private static boolean doesFileExists(String value) {
        boolean result = false;
        for (String path : pathList) {
            File file = new File(path + "/" + value);
            result = file.exists();
            if (result) {
                Log.d(TAG, path + " contains index.html binary");
                break;
            }
        }
        return result;
    }
}
