package com.aweb.client.engine.app.fragments;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Menu;
import android.view.MenuItem;

import com.aweb.client.R;
import com.aweb.client.AppController;
import com.aweb.client.application.ApplicationActivity;

public class WebBrowserFragment extends Fragment {
      
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_EXTRA_URL = "EXTRA_URL";
    private static final String TAG = WebBrowserFragment.class.getSimpleName();

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    /*public static WebBrowserFragment loadWeb(String url) {
        WebBrowserFragment f = new WebBrowserFragment();
        Bundle b = new Bundle();
        b.putString(ARG_EXTRA_URL, url);
        f.setArguments(b);

        return f;
    }*/

    public WebBrowserFragment() {
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_app_web_browser, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
  
    }
}
