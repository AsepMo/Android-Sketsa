package com.aweb.client.receiver;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.widget.Toast;

public class NetworkReceiver extends BroadcastReceiver {

    public static String TAG = NetworkReceiver.class.getSimpleName();
    private boolean connected = false;
    private OnNetworkListener mOnNetworkListener;

    @Override
    public void onReceive(final Context context, final Intent intent) {
        final String action = intent.getAction();
        switch (action) {
            case ConnectivityManager.CONNECTIVITY_ACTION:

                if (isNetworkConnected(context)) {
                    //do action here
                    if (!connected) {
                        if (mOnNetworkListener != null) {
                            mOnNetworkListener.onConnected();
                        }
                        //  Toast.makeText(context, "Internet Available!", Toast.LENGTH_SHORT).show();
                    }
                    connected = true;
                } else {
                    if (connected) {
                        if (mOnNetworkListener != null) {
                            mOnNetworkListener.onDisconnected();
                        }
                        // Toast.makeText(context, "Internet Unavailable!", Toast.LENGTH_SHORT).show();
                    }
                    connected = false;
                }
                break;
        }
    }

    public static boolean isNetworkConnected(Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            return cm.getActiveNetworkInfo() != null;
        } catch (Exception e) {
            return true;
        }
    }

    public IntentFilter getIntentFilter(){
        return new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
    }
    
    public void unRegisterNetworkListener(){
        
    }
    
    public interface OnNetworkListener {
        void onConnected();
        void onDisconnected();
    }

    public void setOnNetworkListener(OnNetworkListener mOnNetworkListener) {
        this.mOnNetworkListener = mOnNetworkListener;
    }
}
