package com.aweb.client.engine.app.tasks;

import android.content.Context;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.Writer;

import com.aweb.client.engine.widget.HtmlTextEditor;

public class SaveTask extends Thread {
    public static String TAG = SaveTask.class.getSimpleName();

    private final String text;
    private final File fileToEdit;

    public SaveTask(String text, File fileToEdit) {
        this.text = text;
        this.fileToEdit = fileToEdit;
        fileToEdit.getParentFile().mkdirs();
    }

    @Override
    public void run() {
        try {

            fileToEdit.createNewFile();
            FileOutputStream fos = new FileOutputStream(fileToEdit);
            Writer w = new BufferedWriter(new OutputStreamWriter(fos));

            try {
                w.write(text);
                w.flush();
                fos.getFD().sync();
            }
            finally {
                w.close();
            }
        }
        catch (IOException e) {
            Log.e(TAG, "Exception writing file", e);
        }
    } 
}

