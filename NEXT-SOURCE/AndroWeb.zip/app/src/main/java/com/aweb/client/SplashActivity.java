package com.aweb.client;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

import java.io.File;
import java.util.List;
import java.util.ArrayList;

import com.aweb.client.application.Application;
import com.aweb.client.application.ApplicationActivity;
import com.aweb.client.engine.app.models.VideoData;
import com.aweb.client.engine.app.folders.FileMe;
import com.aweb.client.engine.app.folders.FolderMe;
import com.aweb.client.engine.widget.soundPool.SoundPoolManager;

public class SplashActivity extends AppCompatActivity {

    private ImageView mCover;
    private Handler mHandler = new Handler();
    private Runnable mRunner = new Runnable(){
        @Override
        public void run() {
            ApplicationActivity.start(SplashActivity.this);
            SplashActivity.this.finish();
        }
    };
    private Application mApplication;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme_NoActionBar);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

		Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);

        mCover = (ImageView)findViewById(R.id.cover_view);
        mApplication = Application.with(this);
        mApplication.setPermission(this, Application.requestPermissionStorage, new Application.OnActionPermissionListener(){
                @Override
                public void onGranted() {
                    setTask();
                }

                @Override
                public void onDenied(String permission) {

                }
            });

    }

    public void setTask() {
        Application.getInstance().setApplicationTaskListener(this, new Application.OnApplicationTaskListener(){
                @Override
                public void onPreExecute() {
                    FileMe fileMe = FileMe.with(SplashActivity.this);
                    fileMe.ScriptMe(FolderMe.EXTERNAL_DIR + "/"+ getString(R.string.app_name), getString(R.string.app_name) + ".dat", "Welcome To " + getString(R.string.app_name));
                    if(fileMe.isExists())
                    fileMe.WebMe(FolderMe.FOLDER_WEB_EDITOR, FileMe.INDEX_HTML, "<h2>Welcome To AndroWeb</h2>");

                    SoundPoolManager.getInstance().playSound(R.raw.add);
                }

                @Override
                public void onFailed() {

                }

                @Override
                public void isEmpty() {

                }
                @Override
                public void onSuccess(ArrayList<VideoData> result) {
                    SoundPoolManager.getInstance().playSound(R.raw.done);
                    
                    mHandler.postDelayed(mRunner, 100);
                }

            });
    }

    @Override
    protected void onPause() {
        super.onPause();
        mHandler.removeCallbacks(mRunner);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(mRunner);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Application.getInstance().onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

}
