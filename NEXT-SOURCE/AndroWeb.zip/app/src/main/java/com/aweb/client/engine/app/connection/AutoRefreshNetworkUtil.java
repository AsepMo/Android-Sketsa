package com.aweb.client.engine.app.connection;

import android.support.v7.app.AppCompatActivity;
import android.content.Context;
import com.aweb.client.engine.app.listeners.OnNetworkConnectionChangeListener;
import android.util.Log;
import android.app.Activity;

public final class AutoRefreshNetworkUtil {
    
    private static final String TAG = AutoRefreshNetworkUtil.class.getSimpleName();
    private Context mContext;
    private AppCompatActivity mAppCompatActivity;
    private CheckNetworkConnectionHelper mCheckNetwork;
    private OnAutoRefreshNetworkListener mOnAutoRefreshNetworkListener;
    private AutoRefreshNetworkUtil(Context context) {
        this.mContext = context;
        mCheckNetwork = CheckNetworkConnectionHelper.with(mContext);
    }

    public static AutoRefreshNetworkUtil with(Context context) {
        
        return new AutoRefreshNetworkUtil(context);
    }

    public void registerNetworkListener() {
        final AppCompatActivity appCompatActivity = (AppCompatActivity) mContext;
        if (mAppCompatActivity == null) {
            mAppCompatActivity = appCompatActivity;
        }
        mCheckNetwork.registerNetworkChangeListener(new OnNetworkConnectionChangeListener() {
                @Override
                public void onDisconnected() {
                    //Do your task on Network Disconnected!
                    Log.e(TAG, "onDisconnected");
                    
                    if(mOnAutoRefreshNetworkListener != null)
                        mOnAutoRefreshNetworkListener.onDisconnected();              
                }

                @Override
                public void onConnected() {
                    //Do your task on Network Connected!
                    Log.e(TAG, "onConnected");
                    if(mOnAutoRefreshNetworkListener != null)
                        mOnAutoRefreshNetworkListener.onConnected();
                }

                @Override
                public Context getContext() {
                    return appCompatActivity;
                }
            });

        /*mCheckNetwork.registerNetworkChangeListener(new OnNetworkConnectionChangeListener() {
                @Override
                public void onDisconnected() {
                    //Do your task on Network Disconnected!
                    Log.e(TAG, "2 onDisconnected");
                    if(mOnAutoRefreshNetworkListener != null)
                        mOnAutoRefreshNetworkListener.onDisconnected();
                }

                @Override
                public void onConnected() {
                    //Do your task on Network Connected!
                    Log.e(TAG, "2 onConnected");
                }

                @Override
                public Context getContext() {
                    return appCompatActivity;
                }
            });*/
        
    }
    
    public void removeAllRegisterNetworkListener(Activity a) {
        mCheckNetwork.unregisterNetworkChangeListener();
    }
    
    public void setOnAutoRefreshNetworkListener(OnAutoRefreshNetworkListener mOnAutoRefreshNetworkListener){
        this.mOnAutoRefreshNetworkListener = mOnAutoRefreshNetworkListener;
    }
    
    public interface OnAutoRefreshNetworkListener {
        void onConnected();
        void onDisconnected();
    }
}

