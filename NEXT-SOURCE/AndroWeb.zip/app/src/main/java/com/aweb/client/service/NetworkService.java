package com.aweb.client.service;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.widget.Toast;
import com.aweb.client.receiver.NetworkReceiver;
import com.aweb.client.engine.app.config.Constans;


@SuppressWarnings({"ConstantConditions", "ResultOfMethodCallIgnored"})
public class NetworkService extends Service{
    
    public static String TAG = NetworkService.class.getSimpleName();
    private NetworkReceiver mNetworkReceiver;
    private IntentFilter filter;
    
    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Let it continue running until it is stopped.
        mNetworkReceiver = new NetworkReceiver();
        filter = new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION);
        registerReceiver(mNetworkReceiver, filter);
        
        mNetworkReceiver.setOnNetworkListener(new NetworkReceiver.OnNetworkListener(){
                @Override
                public void onConnected() {
                    broadcastStatus("online", "http://www.youtube.com");           
                }

                @Override
                public void onDisconnected() {
                    broadcastStatus("offline", Constans.ASSET_URL_VIDEO_PLAYER);      
                }
            });
        Toast.makeText(this, "Service Started", Toast.LENGTH_SHORT).show();
        return START_STICKY;
    }

    public void broadcastStatus(String status) {
        //sendNotification(status, "");
        Intent localIntent = new Intent(Constans.PROCESS_BROADCAST_ACTION)
            .putExtra(Constans.PROCESS_STATUS_KEY, status);
        sendBroadcast(localIntent);
    }

    public void broadcastStatus(String statusKey, String statusData) {
        //sendNotification(statusKey, statusData);
        Intent localIntent = new Intent(Constans.PROCESS_BROADCAST_ACTION)
            .putExtra(Constans.PROCESS_STATUS_KEY, statusKey)
            .putExtra(Constans.PROCESS_STATUS_MESSAGE, statusData);
        sendBroadcast(localIntent);
    }

    public void broadcastStatusWithPackageInfo(String statusKey, String dir, String url) {
       // sendNotification(statusKey, "");
        Intent localIntent = new Intent(Constans.PROCESS_BROADCAST_ACTION)
            .putExtra(Constans.PROCESS_STATUS_KEY, statusKey)
            .putExtra(Constans.PROCESS_DIR, dir)
            .putExtra(Constans.PROCESS_EXTRA_URL, url);
        sendBroadcast(localIntent);
    }
    

    @Override
    public void onDestroy() {
        super.onDestroy();
        unregisterReceiver(mNetworkReceiver);
        mNetworkReceiver = null;
        Toast.makeText(this, "Service Destroyed", Toast.LENGTH_SHORT).show();
    }
}
