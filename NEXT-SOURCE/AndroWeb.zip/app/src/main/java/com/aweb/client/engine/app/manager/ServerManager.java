package com.aweb.client.engine.app.manager;

public class ServerManager {
    
    public static String TAG = ServerManager.class.getSimpleName();
    
}