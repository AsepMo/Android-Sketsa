package com.aweb.client.application;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.ActionBar;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.MotionEvent;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewPropertyAnimator;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;
import android.widget.RelativeLayout;
import android.widget.Toast;

import static android.view.ViewGroup.LayoutParams.MATCH_PARENT;
import static android.view.ViewGroup.LayoutParams.WRAP_CONTENT;

import com.google.android.youtube.player.YouTubePlayer.OnFullscreenListener;
import com.aweb.client.R;
import com.aweb.client.engine.app.fragments.VideoFragment;
import com.aweb.client.engine.app.tasks.YoutubeTask;
import com.aweb.client.engine.app.utils.CheckerUrl;

public class YouTubePreviewActivity extends Activity implements OnFullscreenListener {
    

    public static void start(Context c) {
        Intent intent = new Intent(c, YouTubePreviewActivity.class);
        c.startActivity(intent);
    }
    private String TAG = YouTubePreviewActivity.class.getSimpleName();
    public static final String TAG_URL = "videoId";
    
    private boolean isFullscreen;
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtube_player);
        RelativeLayout mVideoBoxLayout = (RelativeLayout)findViewById(R.id.video_box_iframe);  
        mVideoBoxLayout.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {                 
                    
                }
            });
    }
    
    public void getYoutubePlayer(String url)
    {
        final String videoId = CheckerUrl.getVideoIdFromYoutubeUrl(url);
        YoutubeTask task = new YoutubeTask(this, getFragmentManager(), videoId, findViewById(R.id.video_progress_container), findViewById(R.id.video_fragment_container));
        task.execute();
    }
 
    @Override
    protected void onResume() {
        super.onResume();
        Log.d("ON_RESUME", "ausgeführt!");
        
        String urlFromIntent = null;
        if (getIntent().getStringExtra(Intent.EXTRA_TEXT) != null && getIntent().getAction().equals(Intent.ACTION_SEND)) {
            Log.d("IntentText: ", getIntent().getStringExtra(Intent.EXTRA_TEXT));
            urlFromIntent = getIntent().getStringExtra(Intent.EXTRA_TEXT);
            
            getYoutubePlayer(urlFromIntent);
        }
        if (getIntent().getAction().equals(Intent.ACTION_VIEW)) {
            urlFromIntent = getIntent().getDataString();
            getYoutubePlayer(urlFromIntent);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        getIntent().removeExtra(Intent.EXTRA_TEXT);
    }
    
    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        layout();
    }

    @Override
    public void onFullscreen(boolean isFullscreen) {
        this.isFullscreen = isFullscreen;

        layout();
    }

    /**
     * Sets up the layout programatically for the three different states. Portrait, landscape or
     * fullscreen+landscape. This has to be done programmatically because we handle the orientation
     * changes ourselves in order to get fluent fullscreen transitions, so the xml layout resources
     * do not get reloaded.
     */
    private void layout() {
        boolean isLandscap = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;   
        if (isFullscreen && isLandscap) {          
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);                 
        } else {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);                  
        }
    }

    @Override
    public void onBackPressed() {
        boolean isLandscap = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        if (isLandscap) {
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);                  
        } else {
            super.onBackPressed();
        }
    }
}

