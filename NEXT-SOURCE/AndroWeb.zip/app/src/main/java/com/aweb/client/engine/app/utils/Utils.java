package com.aweb.client.engine.app.utils;

import com.aweb.client.engine.widget.HtmlBuilder;
import android.graphics.Color;
import android.text.Spanned;

public class Utils {
    
    public static Spanned buildDemoHtml() {
    HtmlBuilder html = new HtmlBuilder();
    html.h1("Example Usage");

    html.h3().font("cursive", "Code:").close();
    html.font(0xFFCAE682, "HtmlBuilder")
        .append(' ')
        .font(0xFFD4C4A9, "html")
        .append(' ')
        .font(0xFF888888, "=")
        .append(" ")
        .font(0xFF33B5E5, "new")
        .append(" ")
        .font(0xFFCAE682, "HtmlBuilder")
        .append("()")
        .br();
    html.font(0xFFD4C4A9, "html")
        .append(".strong(")
        .font(0xFF95E454, "\"Strong text\"")
        .append(").br();")
        .br();
    html.font(0xFFD4C4A9, "html")
        .append(".font(")
        .font(0xFFCAE682, "Color")
        .append('.')
        .font(0xFF53DCCD, "RED")
        .append(", ")
        .font(0xFF95E454, "\"This will be red text\"")
        .append(");")
        .br();
    html.font(0xFFCAE682, "textView")
        .append(".setText(")
        .font(0xFFD4C4A9, "html")
        .append(".build());")
        .close()
        .br();

    html.h3().font("cursive", "Result:").close();
    html.strong("Strong text").br().font(Color.RED, "This will be red text");

    html.h1("Supported Tags");
    html.append("&lt;a href=&quot;...&quot;&gt;").br();
    html.append("&lt;b&gt;").br();
    html.append("&lt;big&gt;").br();
    html.append("&lt;blockquote&gt;").br();
    html.append("&lt;br&gt;").br();
    html.append("&lt;cite&gt;").br();
    html.append("&lt;dfn&gt;").br();
    html.append("&lt;div align=&quot;...&quot;&gt;").br();
    html.append("&lt;em&gt;").br();
    html.append("&lt;font color=&quot;...&quot; face=&quot;...&quot;&gt;").br();
    html.append("&lt;h1&gt;").br();
    html.append("&lt;h2&gt;").br();
    html.append("&lt;h3&gt;").br();
    html.append("&lt;h4&gt;").br();
    html.append("&lt;h5&gt;").br();
    html.append("&lt;h6&gt;").br();
    html.append("&lt;i&gt;").br();
    html.append("&lt;img src=&quot;...&quot;&gt;").br();
    html.append("&lt;p&gt;").br();
    html.append("&lt;small&gt;").br();
    html.append("&lt;strike&gt;").br();
    html.append("&lt;strong&gt;").br();
    html.append("&lt;sub&gt;").br();
    html.append("&lt;sup&gt;").br();
    html.append("&lt;tt&gt;").br();
    html.append("&lt;u&gt;").br();
    html.append("&ul;u&gt;").br();
    html.append("&li;u&gt;").br();

    html.h1("Links");
    html.p()
        .strong().a("https://twitter.com/jaredrummler", "Twitter").close()
        .append("&nbsp;&nbsp;|&nbsp;&nbsp;")
        .strong().a("https://github.com/jaredrummler", "GitHub").close()
        .close();

    return html.build();
  }

}
