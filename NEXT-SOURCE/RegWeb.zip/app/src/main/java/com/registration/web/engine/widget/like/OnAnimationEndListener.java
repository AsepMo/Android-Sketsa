package com.registration.web.engine.widget.like;

public interface OnAnimationEndListener {
    void onAnimationEnd(LikeButton likeButton);
}
