package com.registration.web.engine.app.utils;

import com.registration.web.engine.app.model.VideoModel;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class VideoJsonResponseParser {

    public static VideoModel getParsedDataOf(JSONObject object) throws JSONException {
        VideoModel model = new VideoModel();

        if(object.has("id") && object.getJSONObject("id").has("videoId"))
            model.setVideoId(object.getJSONObject("id").getString("videoId"));
        else
            model.setVideoId("--");

        if(object.has("snippet"))
        {
            JSONObject snippet = object.getJSONObject("snippet");
            if(snippet.has("publishedAt"))
            {
                String timeStamp = snippet.getString("publishedAt");              
                model.setPublishedAt(timeStamp);
            }
            else
                model.setPublishedAt("--");

            if(snippet.has("channelId"))
                model.setChannelId(snippet.getString("channelId"));
            else
                model.setChannelId("--");

            if(snippet.has("title"))
                model.setTitle(snippet.getString("title"));
            else
                model.setTitle("--");

            if(snippet.has("description"))
                model.setDescription(snippet.getString("description"));
            else
                model.setDescription("--");

            if(snippet.has("thumbnails"))
                model.setThumbnail(snippet.getJSONObject("thumbnails").getJSONObject("high").getString("url"));
            else
                model.setThumbnail(" ");

            if(snippet.has("channelTitle"))
                model.setChannelId(snippet.getString("channelTitle"));
            else
                model.setChannelId("--");

        }

        return model;
    }
}
