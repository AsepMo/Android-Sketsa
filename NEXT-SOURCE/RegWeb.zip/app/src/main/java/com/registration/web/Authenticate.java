package com.registration.web;

import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.registration.web.engine.app.fragments.Login;
import com.registration.web.engine.app.fragments.Register;
import com.registration.web.engine.widget.smarttablayout.SmartTabLayout;
import com.registration.web.engine.widget.smarttablayout.v4.FragmentPagerItemAdapter;
import com.registration.web.engine.widget.smarttablayout.v4.FragmentPagerItems;

public class Authenticate extends AppCompatActivity {
    private SmartTabLayout viewPagerTab;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_authenticate);
        FragmentPagerItemAdapter adapter = new FragmentPagerItemAdapter(
                getSupportFragmentManager(), FragmentPagerItems.with(this)
                .add("Login", Login.class)
                .add("Register", Register.class)
                .create());
        ViewPager viewPager = (ViewPager) findViewById(R.id.container);
        viewPager.setAdapter(adapter);


        viewPagerTab = (SmartTabLayout) findViewById(R.id.viewPageTab);
        viewPagerTab.setViewPager(viewPager);
    }
}
