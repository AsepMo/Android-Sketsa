package social.chat.whatsapp.fb.messenger.messaging.Events;

/**
 * Created by mohak on 24/3/17.
 * Event for closing the chat head in case a url is clicked
 */

public class closeBubbleEvent {

    public closeBubbleEvent(){

        // empty constructor
    }
}
