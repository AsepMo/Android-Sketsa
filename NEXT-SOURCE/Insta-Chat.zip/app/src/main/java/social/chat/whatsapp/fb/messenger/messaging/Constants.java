package social.chat.whatsapp.fb.messenger.messaging;

/**
 * Created by mohak on 2/3/17.
 */

public class Constants {

    public static final String msgs = "msgs";

}
