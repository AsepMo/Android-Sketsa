package social.chat.whatsapp.fb.messenger.messaging.Events;

/**
 * Created by mohak on 24/3/17.
 * Event for clearing list when the service is destroyed
 */

public class clearListEvent {

    public clearListEvent(){

        // empty constructor
    }
}
