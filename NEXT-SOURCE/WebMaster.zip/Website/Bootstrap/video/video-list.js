function tampilkanVideoMenu() {
    $.getJSON('../../video_data.json', function (data) {
        let menu = data.menu;
        $.each(menu, function (i, data) {
            $('#daftar-menu').append('<div class="col-md-4"><div class="card mb-3"><img src="'  + data.video_thumbnail + '" class="card-img-top"><div class="card-body"><h5 class="card-title">' + data.video_title + '</h5><p class="card-text">' + data.video_duration + '</p><h5 class="card-title">Rp. ' + data.video_size + '</h5><a href="#" class="btn btn-primary">Pesan Sekarang</a></div></div></div>');
        });
    });
}

tampilkanVideoMenu();


$('.nav-link').on('click', function () {
    $('.nav-link').removeClass('active');
    $(this).addClass('active');

    let id = $(this).html();
    $('h1').html(id);

    if (id == 'All Menu') {
        tampilkanVideoMenu();
        return;
    }


    $.getJSON('../../video_data.json', function (data) {
        let menu = data.menu;
        let content = '';

        $.each(menu, function (i, data) {
            if (data.id == id.toLowerCase()) {
                content += '<div class="col-md-4"><div class="card mb-3"><img src="'  + data.video_thumbnail + '" class="card-img-top"><div class="card-body"><h5 class="card-title">' + data.video_title + '</h5><p class="card-text">' + data.video_duration + '</p><h5 class="card-title">Rp. ' + data.video_size + '</h5><a href="#" class="btn btn-primary">Pesan Sekarang</a></div></div></div>';
            }
        });

        $('#daftar-menu').html(content);
    });


});
