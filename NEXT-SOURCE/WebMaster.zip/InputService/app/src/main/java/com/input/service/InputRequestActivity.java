package com.input.service;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;

public class InputRequestActivity extends Activity {

    private static final String TAG = "InputRequestActivity";
    private static final int REQUEST_INPUT = 43;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if(!InputService.isEnabled()) {
            new AlertDialog.Builder(this)
                    .setCancelable(false)
                    .setTitle(R.string.input_a11y_title)
                    .setMessage(R.string.input_a11y_msg)
                    .setPositiveButton(R.string.yes, new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            Intent intent = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
                            if (intent.resolveActivity(getPackageManager()) != null)
                                startActivityForResult(intent, REQUEST_INPUT);
                            else
                                new AlertDialog.Builder(InputRequestActivity.this)
                                        .setTitle(R.string.error)
                                        .setMessage(R.string.input_a11y_act_not_found_msg)
                                        .show();
                        }
                    })
                    .setNegativeButton(getString(R.string.no), new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            postResultAndFinish(false);
                        }
                    })
                    .show();
        } else {
            postResultAndFinish(true);
        }

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_INPUT) {
            Log.d(TAG, "onActivityResult");
            postResultAndFinish(InputService.isEnabled());
        }
    }

    private void postResultAndFinish(boolean isA11yEnabled) {

        if (isA11yEnabled)
            Log.i(TAG, "a11y enabled");
        else
            Log.i(TAG, "a11y disabled");

        //Intent intent = new Intent(this, MainActivity.class);
        //startActivity(intent);
        finish();
    }

}
