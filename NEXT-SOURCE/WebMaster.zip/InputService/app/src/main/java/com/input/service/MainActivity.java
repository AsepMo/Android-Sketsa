package com.input.service;
 
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;

public class MainActivity extends Activity { 

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    
    public void startInputService(View v){
        Intent intent = new Intent(this, InputRequestActivity.class);
        startActivity(intent);
    }
    
    public static void togglePortraitInLandscapeWorkaround() {
        try {
            // set
          //  mHasPortraitInLandscapeWorkaroundSet = true;
           // mHasPortraitInLandscapeWorkaroundApplied = !instance.mHasPortraitInLandscapeWorkaroundApplied;
            // apply
           // startScreenCapture();
        }
        catch (NullPointerException e) {
            //unused
        }

    }
}
