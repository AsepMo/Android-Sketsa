package com.app.client.engine.app.settings;

public class Settings {
    public static final String KEY_PORT_PREF = "port";
    public static final String KEY_BITRATE_PREF = "bitrate";
    public static final String KEY_RESOLUTION_PREF = "resolution";
    public static final String KEY_LAYER_PREF = "layer";

    private static final String[] bitrateOptions = {"256 Kbps", "512 Kbps", "1 Mbps", "2 Mbps"};
    private static final String[] bitrateValues = {"0.25", "0.5", "1", "2"};
    
}
