package com.app.client;

import android.annotation.SuppressLint;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.graphics.Point;
import android.media.MediaCodec;
import android.media.MediaFormat;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.WindowManager;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.nio.ByteBuffer;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

import java.util.Timer;
import java.util.TimerTask;

import com.app.client.engine.app.utils.Utils;
import com.app.client.engine.app.utils.CodecUtils;
import com.app.client.engine.graphics.CircularEncoderBuffer;
import java.io.ByteArrayOutputStream;

@SuppressLint("NewApi")
public class ClientActivity extends AppCompatActivity implements SurfaceHolder.Callback, View.OnTouchListener {

    private static final String TAG = "omerjerk";

    SurfaceView surfaceView;

    MediaCodec decoder;
    boolean decoderConfigured = false;
    MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();

    CircularEncoderBuffer encBuffer = new CircularEncoderBuffer((int)(1024 * 1024 * 0.5), 30, 7);


    private ClientThread clientThread;
    
    String address;

    int deviceWidth;
    int deviceHeight;
    Point videoResolution = new Point();

    int i = -1;
    String[] infoStringParts;

    private boolean firstIFrameAdded;

    public static final String KEY_FINGER_DOWN = "fingerdown";
    public static final String KEY_FINGER_UP = "fingerup";
    public static final String KEY_FINGER_MOVE = "fingermove";
    public static final String KEY_EVENT_TYPE = "type";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);
        deviceWidth = dm.widthPixels;
        deviceHeight = dm.heightPixels;

        setContentView(R.layout.activity_client);
        Toolbar mToolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        address = Utils.getCurrentIP(this);

        surfaceView = (SurfaceView) findViewById(R.id.main_surface_view);
        surfaceView.getHolder().addCallback(this);
        surfaceView.setOnTouchListener(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    public void sendData(ByteBuffer b) {
        ++i;
        if (i % 2 == 0) {
            String temp = new String(b.array());
            infoStringParts = temp.split(",");
            info.set(Integer.parseInt(infoStringParts[0]), Integer.parseInt(infoStringParts[1]),
                     Long.parseLong(infoStringParts[2]), Integer.parseInt(infoStringParts[3]));
        } else {
            setData(b, info);
        }
    }

    public void onStringAvailable(String s) {
        String[] parts = s.split(",");
        try {
            info.set(Integer.parseInt(parts[0]),
                     Integer.parseInt(parts[1]),
                     Long.parseLong(parts[2]),
                     Integer.parseInt(parts[3]));
            if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
                videoResolution.x = Integer.parseInt(parts[4]);
                videoResolution.y = Integer.parseInt(parts[5]);
            }
        } catch (NumberFormatException e) {
            e.printStackTrace();
            Log.d(TAG, "===========Exception = " + e.getMessage() + " =================");
            //TODO: Need to stop the decoder or to skip the current decoder loop
            showToast(e.getMessage());
        }
    }

    /* clientThread class defined to run the client connection to the socket network using the server ip and port
     * and send message */
    class ClientThread implements Runnable {

        private Socket socket;
        private BufferedReader input;

        @Override
        public void run() {

            try {

                InetAddress serverAddr = InetAddress.getByName(Utils.getCurrentIP(AppController.getContext()));
                
                socket = new Socket(serverAddr, 8080);
                if (socket.isBound()) {

                 }
                while (!Thread.currentThread().isInterrupted()) {
                    this.input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String message = input.readLine();
                    if (null == message || "Disconnect".contentEquals(message)) {
                        Thread.interrupted();
                        message = "Server Disconnected...";                    
                        
                        break;
                    }
                    onStringAvailable(message);
                }

            } catch (UnknownHostException e1) {
                e1.printStackTrace();
            } catch (IOException e1) {
                Thread.interrupted();
                e1.printStackTrace();
            } catch (NullPointerException e3) {
                e3.printStackTrace();
            }

        }

        public void sendMessage(final String message) {
            new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            if (null != socket) {
                                PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);                                                               
                                out.println(message);
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
        }
    }

    public String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        return sdf.format(new Date());
    }


    @Override
    public void onDestroy() {
        super.onDestroy();
        if (null != clientThread) {
            clientThread.sendMessage("Disconnect");
            clientThread = null;
        }
    }
    /**
     * Main decoder function which reads the encoded frames from the CircularBuffer and renders them
     * on to the Surface
     */
    public void doDecoderThingie() {
        boolean outputDone = false;

        while (!decoderConfigured) {
        }

        if (MainActivity.DEBUG) Log.d(TAG, "Decoder Configured");

        while (!firstIFrameAdded) {}

        if (MainActivity.DEBUG) Log.d(TAG, "Main Body");

        int index = encBuffer.getFirstIndex();
        if (index < 0) {
            Log.e(TAG, "CircularBuffer Error");
            return;
        }
        ByteBuffer encodedFrames;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        while (!outputDone) {
            encodedFrames = encBuffer.getChunk(index, info);
            encodedFrames.limit(info.size + info.offset);
            encodedFrames.position(info.offset);

            try {
                index = encBuffer.getNextIntCustom(index);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }

            int inputBufIndex = decoder.dequeueInputBuffer(-1);
            if (inputBufIndex >= 0) {
                ByteBuffer inputBuf = decoder.getInputBuffer(inputBufIndex);
                inputBuf.clear();
                inputBuf.put(encodedFrames);
                decoder.queueInputBuffer(inputBufIndex, 0, info.size,
                                         info.presentationTimeUs, info.flags);
            }

            if (decoderConfigured) {
                int decoderStatus = decoder.dequeueOutputBuffer(info, CodecUtils.TIMEOUT_USEC);
                if (decoderStatus == MediaCodec.INFO_TRY_AGAIN_LATER) {
                    if (MainActivity.DEBUG) Log.d(TAG, "no output from decoder available");
                } else if (decoderStatus == MediaCodec.INFO_OUTPUT_BUFFERS_CHANGED) {
                    if (MainActivity.DEBUG) Log.d(TAG, "decoder output buffers changed");
                } else if (decoderStatus == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    // this happens before the first frame is returned
                    MediaFormat decoderOutputFormat = decoder.getOutputFormat();
                    Log.d(TAG, "decoder output format changed: " +
                          decoderOutputFormat);
                } else {
                    decoder.releaseOutputBuffer(decoderStatus, true);
                }
            }
        }
    }

    /**
     * Add a new frame to the CircularBuffer
     * @param encodedFrame The new frame to be added to the CircularBuffer
     * @param info The BufferInfo object for the encodedFrame
     */
    private void setData(ByteBuffer encodedFrame, MediaCodec.BufferInfo info) {
        if ((info.flags & MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) {
            Log.d(TAG, "Configuring Decoder");
            MediaFormat format =
                MediaFormat.createVideoFormat(CodecUtils.MIME_TYPE, CodecUtils.WIDTH, CodecUtils.HEIGHT);
            format.setByteBuffer("csd-0", encodedFrame);
            decoder.configure(format, surfaceView.getHolder().getSurface(),
                              null, 0);
            decoder.start();
            decoderConfigured = true;
            Log.d(TAG, "decoder configured (" + info.size + " bytes)");
            return;
        }

        encBuffer.add(encodedFrame, info.flags, info.presentationTimeUs);
        if (MainActivity.DEBUG) Log.d(TAG, "Adding frames to the Buffer");
        if ((info.flags & MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0) {
            firstIFrameAdded = true;
            if (MainActivity.DEBUG) Log.d(TAG, "First I-Frame added");
        }
    }

    private void showToast(final String message) {
        ClientActivity.this.runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(ClientActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            });
    }

    @Override
    public void surfaceCreated(SurfaceHolder surfaceHolder) {
        try {
            decoder = MediaCodec.createDecoderByType(CodecUtils.MIME_TYPE);
            new Thread(new Runnable() {
                    @Override
                    public void run() {
                        doDecoderThingie();
                    }
                }).start();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
    }

    @Override
    public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
    }

    @Override
    public boolean onTouch(View view, MotionEvent motionEvent) {
        JSONObject touchData = new JSONObject();
        try {
            switch (motionEvent.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    touchData.put("type", KEY_FINGER_DOWN);
                    break;
                case MotionEvent.ACTION_MOVE:
                    touchData.put(KEY_EVENT_TYPE, KEY_FINGER_MOVE);
                    break;
                case MotionEvent.ACTION_UP:
                    touchData.put(KEY_EVENT_TYPE, KEY_FINGER_UP);
                    break;
                default:
                    return true;
            }
            touchData.put("x", motionEvent.getX() / deviceWidth);
            touchData.put("y", motionEvent.getY() / deviceHeight);
            Log.d(TAG, "Sending = " + touchData.toString());
            if (clientThread != null) {
                clientThread.sendMessage(touchData.toString());
            } else {
                Log.e(TAG, "Can't send touch events. Socket is null.");
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return true;
    }

    /**
     * The server side websocket keeps going to sleep again and again and it's a very dirty hack to
     * make it keep running. I keep pinging the server from this client after every particular interval
     * of time as to keep it awake. HATE ME.
     */
    private void setTimer() {

        new Timer("keep_alive").scheduleAtFixedRate(new TimerTask() {
                @Override
                public void run() {
                    if (clientThread != null) {
                        clientThread.sendMessage("random,");
                    }
                }
            }, 2000, 1500);
    }


}

