package com.app.client;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.app.client.engine.app.debugkit.DevTool;
import com.app.client.engine.app.debugkit.DebugFunction;
import com.app.client.engine.app.debugkit.DevToolFragment;
import android.app.Activity;
import com.app.client.engine.app.fragments.CameraClientFragment;

public class MainActivity extends AppCompatActivity { 

    public static final boolean DEBUG = false;
    
    public static ServerFragment serverFragment;
    public static ClientFragment clientFragment;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme_NoActionBar);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar mToolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        
        clientFragment = ClientFragment.createFor("Client");
        switchFragment(clientFragment);
    }

    public void switchFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    } 

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Server")
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    serverFragment = ServerFragment.createFor("Server");
                    switchFragment(serverFragment);
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        menu.add("Client")
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    clientFragment = ClientFragment.createFor("Server");
                    switchFragment(clientFragment);
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);  
        menu.add("Video")
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    
                    switchFragment(new CameraClientFragment());
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);  
        return super.onCreateOptionsMenu(menu);
    }
    
}
