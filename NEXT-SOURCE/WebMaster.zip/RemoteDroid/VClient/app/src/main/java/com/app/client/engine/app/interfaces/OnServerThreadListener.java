package com.app.client.engine.app.interfaces;

public interface OnServerThreadListener {
    void onConnect(String connect);
    void onError(String msg);
}
