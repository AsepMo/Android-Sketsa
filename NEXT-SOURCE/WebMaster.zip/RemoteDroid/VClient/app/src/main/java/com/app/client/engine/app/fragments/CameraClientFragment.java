package com.app.client.engine.app.fragments;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.client.R;
import com.app.client.engine.app.utils.Utils;
import com.app.client.engine.widget.MjpegView;
import com.app.client.AppController;

public class CameraClientFragment extends Fragment implements View.OnClickListener {

    public static String TAG = CameraClientFragment.class.getSimpleName();
    private Context mContext;
    private MjpegView mJpegView;
    private String mVideo = "screen_stream.mjpeg";
    private String mVideoUrl = "http://" + Utils.getCurrentIP(AppController.getContext()) + ":8080/screen_stream.mjpeg";
    String VIDEO_URL = "http://201.166.63.44/axis-cgi/mjpg/video.cgi";
    
    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_camera_client, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        mContext = getActivity();
        mJpegView = (MjpegView)view.findViewById(R.id.surface);
        view.findViewById(R.id.connect_server).setOnClickListener(this);
        view.findViewById(R.id.send_data).setOnClickListener(this);
        
    }

     @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.connect_server:
                
                view.setVisibility(View.GONE);
                break;

            case R.id.send_data:
                startVideo();
                break;
        }
    }
    
    @Override
    public void onResume() {
        super.onResume();
        if (mVideoUrl.isEmpty()) {
            startVideo();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        mJpegView.stopPlayback();
    }

    
    private void startVideo() {
        mJpegView.stopPlayback();
        mJpegView.startPlayback(mVideoUrl);
        mJpegView.setOnMjpegCompletedListener(new MjpegView.OnMjpegCompletedListener() {
                @Override 
                public void onCompeleted() {
                    Toast.makeText(mContext, "OnCompleted.", Toast.LENGTH_LONG).show();
                    mJpegView.startPlayback(mVideoUrl);
                }

                @Override 
                public void onFailure(String error) {

                    Toast.makeText(mContext, error, Toast.LENGTH_LONG).show();
                }
            });
    }
}
