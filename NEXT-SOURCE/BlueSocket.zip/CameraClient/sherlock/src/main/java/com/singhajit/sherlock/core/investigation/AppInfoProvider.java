package com.singhajit.sherlock.core.investigation;

public interface AppInfoProvider {
  AppInfo getAppInfo();
}
