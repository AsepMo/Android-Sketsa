package com.camera.client.engine.app.fragments;

import android.util.Log;

public class FragmentFactory {

    public static BaseFragment getFragmentByTag(String tag) {
        Log.d("FragmentFactory", "new " + tag);
        if (tag.equals(CameraControllerFragment.FRAGMENT_TAG)) {
            return new CameraControllerFragment();
        }
        else if (tag.equals(CameraClientFragment.FRAGMENT_TAG)) {
            return new CameraClientFragment();
        }
        else if (tag.equals(CameraSettingFragment.FRAGMENT_TAG)) {
            return new CameraSettingFragment();
        }      
        else {
            return null;
        }
    }
}

