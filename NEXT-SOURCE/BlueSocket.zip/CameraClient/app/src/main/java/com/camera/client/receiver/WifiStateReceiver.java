package com.camera.client.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Parcelable;
import android.util.Log;

public class WifiStateReceiver extends BroadcastReceiver
{
    public static String TAG = WifiStateReceiver.class.getSimpleName();

    private BRInteraction brInteraction;
    
    @Override
    public void onReceive(Context context, Intent intent)
    {
        
        if (WifiManager.WIFI_STATE_CHANGED_ACTION.equals(intent.getAction()))
        {
            int wifiState = intent.getIntExtra(WifiManager.EXTRA_WIFI_STATE, 0);
            switch (wifiState)
            {
                case WifiManager.WIFI_STATE_ENABLED:
                    Log.e("APActivity", "WIFI_STATE_ENABLED");
                    break;
                case WifiManager.WIFI_STATE_ENABLING:
                    Log.e("APActivity", "WIFI_STATE_ENABLING");
                    break;
                case WifiManager.WIFI_STATE_DISABLED:
                    Log.e("APActivity", "WIFI_STATE_DISABLED");
                    break;
                case WifiManager.WIFI_STATE_DISABLING:
                    Log.e("APActivity", "WIFI_STATE_DISABLING");
                    break;
            }
        }
        
        if (WifiManager.NETWORK_STATE_CHANGED_ACTION.equals(intent.getAction()))
        {
            Parcelable parcelableExtra = intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
            if (null != parcelableExtra)
            {
                NetworkInfo networkInfo = (NetworkInfo) parcelableExtra;
                switch (networkInfo.getState())
                {
                    case CONNECTED:
                        Log.e("APActivity", "CONNECTED");
                        brInteraction.setText("Connected");
                        break;
                    case CONNECTING:
                        Log.e("APActivity", "CONNECTING");
                        break;
                    case DISCONNECTED:
                        Log.e("APActivity", "DISCONNECTED");
                        break;
                    case DISCONNECTING:
                        Log.e("APActivity", "DISCONNECTING");
                        break;
                    case SUSPENDED:
                        Log.e("APActivity", "SUSPENDED");
                        break;
                    case UNKNOWN:
                        Log.e("APActivity", "UNKNOWN");
                        break;
                    default:
                        break;
                }
            }
        }
       
        if (ConnectivityManager.CONNECTIVITY_ACTION.equals(intent.getAction()))
        {
            NetworkInfo info = intent.getParcelableExtra(ConnectivityManager.EXTRA_NETWORK_INFO);
            if (info != null)
            {
                StringBuilder sb = new StringBuilder();
                sb.append("info.getTypeName() : " + info.getTypeName() + "\n");
                sb.append("getSubtypeName() : " + info.getSubtypeName() + "\n");
                sb.append("getState() : " + info.getState() + "\n");
                sb.append("getDetailedState() : " + info.getDetailedState().name() + "\n");
                sb.append("getDetailedState() : " + info.getExtraInfo() + "\n");
                sb.append("getType() : " + info.getType());
                Log.e("APActivity", sb.toString());
            }
        }
    }
    
    
    public interface BRInteraction {
        public void setText(String content);
    }

    public void setBRInteractionListener(BRInteraction brInteraction) {
        this.brInteraction = brInteraction;
    }
}
