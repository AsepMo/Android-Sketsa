package com.camera.client.engine.app.fragments;

import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;

import com.camera.client.application.CameraClientActivity;
import com.camera.client.R;

import java.io.BufferedReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.ArrayList;

public class CameraControllerFragment extends BaseFragment implements OnClickListener{

    public static String FRAGMENT_TAG = CameraControllerFragment.class.getSimpleName();

    private Button button_play = null,button_buttoninit=null, button_play1 = null, button_pause = null;
    private Button button_buttonfocus, button_take_photo, button_button_flash;
    
    public static ArrayList<Socket> socketList = new ArrayList<Socket>();
    private SurfaceView mSurfaceview = null;
    private OutputStream out = null;
    private Handler handler = null;
    private Socket s = null;
    String tag = "chatRoom";
    private BufferedReader buRead = null;

    private String dest_ip = null;

    Thread clientThread, serverThread;
    boolean serverrun = true;

    CameraClientActivity activity;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_camera_controller, null);
        return v;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);
        activity = (CameraClientActivity) getActivity();
        dest_ip = activity.getIntent().getStringExtra("iptext");
        init();

    }

    public void init() {


        button_buttoninit = (Button) activity.findViewById(R.id.button_init);
        button_buttonfocus = (Button) activity.findViewById(R.id.button_focus);
        button_take_photo = (Button) activity.findViewById(R.id.button_takephoto);
        button_button_flash = (Button) activity.findViewById(R.id.button_flash);
        //car_stop = (Button) activity.findViewById(R.id.car_stop);

        button_buttoninit.setOnClickListener(this);
        button_buttonfocus.setOnClickListener(this);
        button_take_photo.setOnClickListener(this);
        button_button_flash.setOnClickListener(this);
        //car_stop.setOnClickListener(this);


        button_buttonfocus.setOnClickListener(this);
        button_take_photo.setOnClickListener(this);
        button_button_flash.setOnClickListener(this);
        button_play = (Button) activity.findViewById(R.id.button_playsong);
        button_play1 = (Button) activity.findViewById(R.id.button_playstory);
        button_pause = (Button) activity.findViewById(R.id.button_pause);
        button_play.setOnClickListener(this);
        button_play1.setOnClickListener(this);
        button_pause.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.button_playsong:
                activity.playSong();
                break;
            case R.id.button_pause:
                activity.playPause();
                break;
            case R.id.button_playstory:
                activity.playStory();
                break;
            case R.id.button_focus:
                activity.requestAutoFocus();

                break;
            case R.id.button_takephoto:
                activity.requestTakePhoto();
                break;
            case R.id.button_init:
                activity.requestInitCar();
                break;
            case R.id.button_flash:
//              activity.requstFlash();
                break;
        }
    }


    @Override
    public void onDestroy() {
        serverThread = null;
        serverrun = false;
        super.onDestroy();
//        try {
//            if (ss != null)
//                ss.close();
//        } catch (IOException e) {
//            // TODO Auto-generated catch block
//            e.printStackTrace();
//
//        }
//      clientStop();


    }
//
//    @Override
//    public void onJoyStickUp(int speed) {
//        activity.sendMovement(Command.FORWARD, speed);
//    }
//
//    @Override
//    public void onJoyStickUpRight(int speed) {
//        activity.sendMovement(Command.FORWARD_RIGHT, speed);
//    }
//
//    @Override
//    public void onJoyStickUpLeft(int speed) {
//        activity.sendMovement(Command.FORWARD_LEFT, speed);
//    }
//
//    @Override
//    public void onJoyStickDown(int speed) {
//        activity.sendMovement(Command.BACKWARD, speed);
//    }
//
//    @Override
//    public void onJoyStickDownRight(int speed) {
//        activity.sendMovement(Command.BACKWARD_RIGHT, speed);
//    }
//
//    @Override
//    public void onJoyStickDownLeft(int speed) {
//        activity.sendMovement(Command.BACKWARD_LEFT, speed);
//    }
//
//    @Override
//    public void onJoyStickRight(int speed) {
//        activity.sendMovement(Command.RIGHT, speed);
//    }
//
//    @Override
//    public void onJoyStickLeft(int speed) {
//        activity.sendMovement(Command.LEFT, speed);
//    }
//
//    @Override
//    public void onJoyStickNone() {
//        activity.sendStop();
//    }
}
