package com.camera.client.engine.app.fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.TextView;

import com.camera.client.R;

/**
 * 
 */
public class CameraSettingFragment extends BaseFragment implements OnClickListener {

    public static String FRAGMENT_TAG = CameraSettingFragment.class.getSimpleName();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View mRootView = inflater.inflate(R.layout.fragment_camera_settings, null);
        return mRootView;
    }

    @Override
    public void onClick(View v) {
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);

        View v = (View) getActivity().findViewById(R.id.fujin_search_imb);
        TextView bt = (TextView) getActivity().findViewById(R.id.fujin_usermain_map_bt);

        v.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });
        bt.setOnClickListener(new OnClickListener() {
                @Override
                public void onClick(View v) {

                }
            });

    }
}

