package com.web.server.application;

import android.os.Bundle;
import android.preference.PreferenceActivity;

import com.web.server.R;

public class SettingsActivity extends PreferenceActivity {
    public static String TAG = SettingsActivity.class.getSimpleName();
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.setting);
    }
}
