package com.ftp.client.application;

import android.Manifest;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import com.ftp.client.R;
import com.ftp.client.engine.app.fragments.FTPFilesFragment;

public class ApplicationActivity extends AppCompatActivity {
    
    public static String TAG = ApplicationActivity.class.getSimpleName();
    public static void start(Context c){
        Intent mApplication = new Intent(c, ApplicationActivity.class);
        c.startActivity(mApplication);
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme_NoActionBar);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);
        
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

       showFragment(FTPFilesFragment.newInstance(""));
   }
   
   public void showFragment(Fragment fragment){
       getSupportFragmentManager()
       .beginTransaction()
       .replace(R.id.content_frame, fragment)
       .commit();
   }
}
