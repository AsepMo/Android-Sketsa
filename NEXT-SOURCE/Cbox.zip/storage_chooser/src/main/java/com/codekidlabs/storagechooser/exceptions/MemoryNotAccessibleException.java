package com.codekidlabs.storagechooser.exceptions;


public class MemoryNotAccessibleException extends Exception {

    public MemoryNotAccessibleException(String message) {
        super(message);
    }
}
