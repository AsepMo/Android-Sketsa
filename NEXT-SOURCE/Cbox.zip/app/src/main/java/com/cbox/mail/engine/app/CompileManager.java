package com.cbox.mail.engine.app;

import android.app.Activity;
import android.content.Intent;

import java.io.File;

public class CompileManager
{
	public static final String FILE_PATH = "file_name";     // extras indicators
    public static final String IS_NEW = "is_new";
    public static final String INITIAL_POS = "initial_pos";
    public static final int ACTIVITY_EDITOR = 1001;
    public static final String MODE = "run_mode";

    public static final String PROJECT_FILE = "project_file";
    public static final String ACTION = "action";
    public static final String ARGS = "program_args";
    public static final String DEX_FILE = "dex_path";

    private final Activity mActivity;

    public CompileManager(Activity activity) {
        this.mActivity = activity;
    }



    public void debug(String name, Class classes) {
        Intent intent = new Intent(mActivity, classes);
        intent.putExtra(FILE_PATH, name);
        mActivity.startActivity(intent);
    }

    public void edit(String fileName, Boolean isNew, Class classes) {
        Intent intent = new Intent(mActivity, classes);
        intent.putExtra(FILE_PATH, fileName);
        intent.putExtra(IS_NEW, isNew);
        intent.putExtra(INITIAL_POS, 0);
        mActivity.startActivityForResult(intent, ACTIVITY_EDITOR);
    }


    /*public void executeDex(JavaProjectFolder projectFile, File dex) {
        Intent intent = new Intent(mActivity, ExecuteActivity.class);
        intent.putExtra(ACTION, CompileHelper.Action.RUN_DEX);
        intent.putExtra(PROJECT_FILE, projectFile);
        intent.putExtra(DEX_FILE, dex);
        mActivity.startActivity(intent);
    }*/

    public void buildApk() {

    }

    public interface ProcessCallback {
        void onFailed(String s);
    }
}
