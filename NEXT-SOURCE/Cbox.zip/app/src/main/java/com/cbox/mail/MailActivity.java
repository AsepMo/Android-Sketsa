package com.cbox.mail;

import android.support.design.widget.CoordinatorLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.support.v4.app.Fragment;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;

import com.cbox.mail.setting.PrefStore;
import com.cbox.mail.setting.SettingsActivity;
import com.cbox.mail.engine.app.AbstractAppCompatActivity;
import com.cbox.mail.engine.app.about.AboutActivity;
import com.cbox.mail.engine.app.busybox.BusyboxFragment;

public class MailActivity extends AbstractAppCompatActivity
{
	private int mTheme = -1;
    private String theme = "name_of_the_theme";
    public static final String THEME_PREFERENCES = "com.cbox.mail.themepref";
    public static final String RECREATE_ACTIVITY = "com.cbox.mail.recreateactivity";
    public static final String THEME_SAVED = "com.cbox.mail.savedtheme";
    public static final String DARKTHEME = "com.cbox.mail.darktheme";
    public static final String LIGHTTHEME = "com.cbox.mail.lighttheme";

	@Override
	protected void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		/*
		 We need to do this, as this activity's onCreate won't be called when coming back from SettingsActivity,
		 thus our changes to dark/light mode won't take place, as the setContentView() is not called again.
		 So, inside our SettingsFragment, whenever the checkbox's value is changed, in our shared preferences,
		 we mark our recreate_activity key as true.

		 Note: the recreate_key's value is changed to false before calling recreate(), or we woudl have ended up in an infinite loop,
		 as onResume() will be called on recreation, which will again call recreate() and so on....
		 and get an ANR

         */
        if(getSharedPreferences(THEME_PREFERENCES, MODE_PRIVATE).getBoolean(RECREATE_ACTIVITY, false)){
            SharedPreferences.Editor editor = getSharedPreferences(THEME_PREFERENCES, MODE_PRIVATE).edit();
            editor.putBoolean(RECREATE_ACTIVITY, false);
            editor.apply();
            recreate();
        }
	}
	
    @Override
    protected void onCreate(Bundle savedInstanceState)
    { //We recover the theme we've set and setTheme accordingly
        theme = getSharedPreferences(THEME_PREFERENCES, MODE_PRIVATE).getString(THEME_SAVED, LIGHTTHEME);

        if(theme.equals(LIGHTTHEME)){
            mTheme = R.style.AppThemeDark_NoActionBar;
        }
        else{
            mTheme = R.style.AppThemeLight_NoActionBar;
        }
        this.setTheme(mTheme);
	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cbox_mail);
		setupToolbar();
		showFragment(new MailFragment());
    }

	public void showFragment(Fragment fragment){
		getSupportFragmentManager()
			.beginTransaction()
			.replace(R.id.content_frame, fragment)
			.commit();
	}
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu)
	{
		// TODO: Implement this method
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		// TODO: Implement this method
		switch(item.getItemId()){
			
			case R.id.about_cbox_dev:
				Intent about = new Intent(this, AboutActivity.class);
                startActivity(about);
				return true;
			case R.id.preferences:
                Intent intent = new Intent(this, SettingsActivity.class);
                startActivity(intent);
                return true;
			case R.id.mailbox:
				showFragment(new MailFragment());
				break;	
			case R.id.busybox:
				showFragment(new BusyboxFragment());
				return true;
			case R.id.exit:
				MailActivity.this.finish();
				return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
	
}
