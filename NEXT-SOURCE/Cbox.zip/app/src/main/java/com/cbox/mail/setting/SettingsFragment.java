package com.cbox.mail.setting;

import android.support.v7.app.AlertDialog;
import android.net.Uri;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.Preference;
import android.preference.CheckBoxPreference;
import android.preference.PreferenceFragment;

import com.cbox.mail.R;
import com.cbox.mail.MailActivity;
import com.cbox.mail.engine.app.inbox.updater.AppUpdater;
import com.cbox.mail.engine.app.inbox.updater.UpdateListener;
import com.cbox.mail.engine.app.inbox.updater.UpdateModel;
import org.json.JSONObject;

public class SettingsFragment extends PreferenceFragment implements Preference.OnPreferenceClickListener,SharedPreferences.OnSharedPreferenceChangeListener{
    

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addPreferencesFromResource(R.xml.pref_settings);
		Preference prefCheckForUpdates = findPreference("prefCheckForUpdates");

        prefCheckForUpdates.setOnPreferenceClickListener(this);
   	}

	@Override
	public boolean onPreferenceClick(Preference preference)
	{
		// TODO: Implement this method
		new AppUpdater(getActivity(), "https://asepmo-story.000webhostapp.com/json/update.json", new UpdateListener() {
				@Override
				public void onJsonDataReceived(final UpdateModel updateModel, JSONObject jsonObject) {
					if (AppUpdater.getCurrentVersionCode(getActivity()) < updateModel.getVersionCode()) {
						new AlertDialog.Builder(getActivity())
                            .setTitle("Update available")
							.setMessage("Segera Update!Versi Terbaru Dilengkapi Featur Yang Lebih Lengkap.")
                            .setCancelable(updateModel.isCancellable())
                            .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(updateModel.getUrl()));
                                    startActivity(browserIntent);
                                }
                            })
                            .show();
					}
				}

				@Override
				public void onError(String error) {
					// Do something
				}
			}).execute();
    
		return true;
	}

    @Override
    public void onSharedPreferenceChanged(SharedPreferences sharedPreferences, String key) {
        PreferenceKeys preferenceKeys = new PreferenceKeys(getResources());
        if(key.equals(preferenceKeys.night_mode_pref_key)){
            SharedPreferences themePreferences = getActivity().getSharedPreferences(MailActivity.THEME_PREFERENCES, Context.MODE_PRIVATE);
            SharedPreferences.Editor themeEditor = themePreferences.edit();
            //We tell our MainLayout to recreate itself because mode has changed
            themeEditor.putBoolean(MailActivity.RECREATE_ACTIVITY, true);

            CheckBoxPreference checkBoxPreference = (CheckBoxPreference)findPreference(preferenceKeys.night_mode_pref_key);
		    if(checkBoxPreference.isChecked()){
                //Comment out this line if not using Google Analytics
                themeEditor.putString(MailActivity.THEME_SAVED, MailActivity.DARKTHEME);
            }
            else{
                themeEditor.putString(MailActivity.THEME_SAVED, MailActivity.LIGHTTHEME);
            }
            themeEditor.apply();

            getActivity().recreate();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        getPreferenceManager().getSharedPreferences().registerOnSharedPreferenceChangeListener(this);
    }

    @Override
    public void onPause() {
        super.onPause();
        getPreferenceManager().getSharedPreferences().unregisterOnSharedPreferenceChangeListener(this);
    }
}

