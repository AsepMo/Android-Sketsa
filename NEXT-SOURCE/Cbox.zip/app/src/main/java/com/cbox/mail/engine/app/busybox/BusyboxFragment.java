package com.cbox.mail.engine.app.busybox;

import com.cbox.mail.R;

import android.support.v7.app.AlertDialog;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.Manifest;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.util.TypedValue;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.Button;
import android.widget.Toast;

import com.cbox.mail.setting.PrefStore;

public class BusyboxFragment extends Fragment implements View.OnClickListener
{
	
    private static final int REQUEST_WRITE_STORAGE = 112;
    static TextView output;
    static ScrollView scroll;
	private Button btnInstall,btnRemove;
	private View rootView;
    /**
     * Show message in TextView, used from Logger
     *
     * @param log message
     */
    public static void showLog(final String log) {
        // show log in TextView
        output.post(new Runnable() {
            @Override
            public void run() {
                output.setText(log);
                // scroll TextView to bottom
                scroll.post(new Runnable() {
                    @Override
                    public void run() {
                        scroll.fullScroll(View.FOCUS_DOWN);
                        scroll.clearFocus();
                    }
                });
            }
        });
    }

	@Override
	public void onResume()
	{
		// TODO: Implement this method
		super.onResume();
		TextView outputView = (TextView)rootView.findViewById(R.id.outputView);
        // restore font size
        outputView.setTextSize(TypedValue.COMPLEX_UNIT_SP, PrefStore.getFontSize(getActivity()));
        // restore logs
        String log = Logger.get();
        if (log.length() == 0) {
            // show info if empty
            new ExecScript(getActivity(), "info").start();
        } else {
            showLog(log);
        }
	}

	
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		rootView = inflater.inflate(R.layout.fragment_busybox, container, false);
		return rootView;
	}

	@Override
	public void onViewCreated(View view, Bundle savedInstanceState)
	{
		// TODO: Implement this method
		super.onViewCreated(view, savedInstanceState);
		output = (TextView)view.findViewById(R.id.outputView);
        scroll = (ScrollView)view.findViewById(R.id.scrollView);
		btnInstall = (Button)view.findViewById(R.id.installBtn);
		btnInstall.setOnClickListener(this);
		btnRemove = (Button)view.findViewById(R.id.removeBtn);
		btnRemove.setOnClickListener(this);
        // enable context clickable
        output.setMovementMethod(LinkMovementMethod.getInstance());
	}

	@Override
	public void onClick(View v)
	{
		// TODO: Implement this method
		switch(v.getId()){
			case R.id.installBtn:
				installBtn();
				break;
			case R.id.removeBtn:
				removeBtn();
				break;
		}
	}

	private void installBtn(){
		new AlertDialog.Builder(getActivity())
			.setTitle(R.string.busybox_title_confirm_install_dialog)
			.setMessage(R.string.busybox_message_confirm_install_dialog)
			.setIcon(android.R.drawable.ic_dialog_alert)
			.setCancelable(false)
			.setPositiveButton(android.R.string.yes,
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int id) {
					new ExecScript(getActivity(), "install").start();
				}
			})
			.setNegativeButton(android.R.string.no,
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int id) {
					dialog.cancel();
				}
			}).show();
	}
	
	private void removeBtn(){
		new AlertDialog.Builder(getActivity())
			.setTitle(R.string.busybox_title_confirm_remove_dialog)
			.setMessage(R.string.busybox_message_confirm_remove_dialog)
			.setIcon(android.R.drawable.ic_dialog_alert)
			.setCancelable(false)
			.setPositiveButton(android.R.string.yes,
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int id) {
					new ExecScript(getActivity(), "remove").start();
				}
			})
			.setNegativeButton(android.R.string.no,
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int id) {
					dialog.cancel();
				}
			}).show();
	}
	
    private void makeZipArchiveDialog() {
        String archiveName = PrefStore.getStorage() + "/busybox-" + PrefStore.getArch() + ".zip";
        final EditText input = new EditText(getActivity());
        input.setText(archiveName);
        new AlertDialog.Builder(getActivity())
			.setTitle(R.string.busybox_title_export_dialog)
			.setCancelable(false)
			.setView(input, 16, 32, 16, 0)
			.setPositiveButton(android.R.string.yes,
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int id) {
					String archiveName = input.getText().toString();
					if (!archiveName.isEmpty()) {
						if (EnvUtils.makeZipArchive(getActivity(), archiveName)) {
							Toast toast = Toast.makeText(getActivity(),
														 getString(R.string.busybox_toast_export_success),
														 Toast.LENGTH_SHORT);
							toast.show();
						} else {
							Toast toast = Toast.makeText(getActivity(),
														 getString(R.string.busybox_toast_export_error),
														 Toast.LENGTH_SHORT);
							toast.show();
						}
					}
				}
			})
			.setNegativeButton(android.R.string.no,
			new DialogInterface.OnClickListener() {
				@Override
				public void onClick(DialogInterface dialog, int id) {
					dialog.cancel();
				}
			}).show();
    }

    /**
     * Request permission to write to storage.
     */
    private void requestWritePermissions() {
        boolean hasPermission = (ContextCompat.checkSelfPermission(getActivity(),
																   Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED);
        if (!hasPermission) {
            ActivityCompat.requestPermissions(getActivity(),
											  new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQUEST_WRITE_STORAGE);
        } else {
            makeZipArchiveDialog();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_WRITE_STORAGE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makeZipArchiveDialog();
            } else {
                Toast.makeText(getActivity(), getString(R.string.busybox_write_permissions_disallow), Toast.LENGTH_LONG).show();
            }
        }
    }
	
}
