package com.cbox.mail.setting;

import com.cbox.mail.R;
import android.content.res.Resources;

public class PreferenceKeys {
    final String night_mode_pref_key;

    public PreferenceKeys(Resources resources){
        night_mode_pref_key = resources.getString(R.string.night_mode_pref_key);
    }
}
