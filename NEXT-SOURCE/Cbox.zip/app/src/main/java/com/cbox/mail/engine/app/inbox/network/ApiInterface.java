package com.cbox.mail.engine.app.inbox.network;

import java.util.List;

import com.cbox.mail.engine.app.inbox.model.Message;
import retrofit2.Call;
import retrofit2.http.GET;


public interface ApiInterface {
    @GET("inbox.json")
    Call<List<Message>> getInbox();
}
