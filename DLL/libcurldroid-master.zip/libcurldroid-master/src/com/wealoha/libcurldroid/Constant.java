package com.wealoha.libcurldroid;

/**
 * 
 * 
 * @author javamonk
 * @createTime 2015-02-05 20:23:18
 */
public interface Constant {

	public String TAG = "libcurldroid";
}
