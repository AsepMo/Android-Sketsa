package toan.githubstar.common;

/**
 * Created by Toan Vu on 6/1/16.
 */
public class Constant {
    public static final String BASE_URL = "https://api.github.com/search/";
}
