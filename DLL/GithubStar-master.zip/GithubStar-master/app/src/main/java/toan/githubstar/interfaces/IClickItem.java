package toan.githubstar.interfaces;

import toan.githubstar.model.Contributor;

public interface IClickItem{
        void onClick(Contributor contributor);
    }