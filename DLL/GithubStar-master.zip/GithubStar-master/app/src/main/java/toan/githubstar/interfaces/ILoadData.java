package toan.githubstar.interfaces;

/**
 * Created by Toan Vu on 6/6/16.
 */
public interface ILoadData {
    void onLoadData();
}
