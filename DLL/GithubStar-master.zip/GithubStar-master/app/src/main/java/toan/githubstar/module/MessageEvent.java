package toan.githubstar.module;

import java.util.List;

import toan.githubstar.model.RepositoryItem;

/**
 * Created by Toan Vu on 6/6/16.
 */
public class MessageEvent {
    List<RepositoryItem> repositoryItems;


}
