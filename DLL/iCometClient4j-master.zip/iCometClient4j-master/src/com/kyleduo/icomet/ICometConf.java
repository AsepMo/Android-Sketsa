package com.kyleduo.icomet;


public class ICometConf {
	public String host;
	public String port;
	public String url;

	public ChannelAllocator channelAllocator;
	public ICometCallback iCometCallback;
	public IConnCallback iConnCallback;
}
