package com.kyleduo.icomet;

/**
 * 
 * used for authority of your business  
 * 
 * @author zhangduo
 *
 */
public class Channel {
	public String cname;
	public String token;
	public int seq;
}
