#version 2.0.2
* Make Content Object to implment Serializable interface, for more convient transfer by Intent in Android.

##version 2.0.0
>Update for iComet latest version.
* Change structure of Message class.