package com.app.client.application;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;

import com.app.client.R;
import com.app.client.engine.app.fragments.EditorClientFragment;

public class ApplicationActivity extends AppCompatActivity{
  
    public static String TAG = ApplicationActivity.class.getSimpleName();

    public static void start(Context c) {
        Intent mIntent = new Intent(c, ApplicationActivity.class);
        c.startActivity(mIntent);
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(R.string.app_name);
        
        switchFragment(EditorClientFragment.createFor("Editor Client"));
     }
     
    public void switchFragment(Fragment fragment){
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    } 
}
