package com.app.client.engine.app.tasks;

import android.support.v4.content.ContextCompat;
import android.graphics.Color;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ConnectException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.SocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.app.client.R;
import com.app.client.engine.app.config.Constants;
import com.app.client.engine.app.config.Command;

public class ClientThread extends AsyncTask<Void, Void, Void> {

    public static String TAG = ClientThread.class.getSimpleName();
    private Thread thread;
    private Socket socket;
    private BufferedReader input;

    private int greenColor;
    private int redColor;
    private int clientTextColor;
    private int yellowColor;

    private OnClientThreadListener mOnClientThreadListener;
    public void setOnServerThreadListener(OnClientThreadListener mOnClientThreadListener) {
        this.mOnClientThreadListener = mOnClientThreadListener;
    }

    public interface OnClientThreadListener {
        void onConnect(String connect, int color);
        void onDisConnect(String disconnect, int color);
        void onMessage(String message, int color);
        void onError(String msg, int color);
    }

    public ClientThread(Context context) {
        greenColor = ContextCompat.getColor(context, android.R.color.holo_green_dark);
        redColor = ContextCompat.getColor(context, android.R.color.holo_red_dark);
        clientTextColor = ContextCompat.getColor(context, android.R.color.holo_blue_dark); 
        yellowColor = ContextCompat.getColor(context, android.R.color.holo_orange_light); 
    }

    @Override
    protected Void doInBackground(Void... params) {
        Runnable run = new Runnable() {
            @Override
            public void run() {
                try {
                    InetAddress serverAddr = InetAddress.getByName(Constants.SERVER_IP);
                    //showMessage("Connecting to Server...", clientTextColor, true);
                    if(mOnClientThreadListener != null){
                        mOnClientThreadListener.onConnect("Mengubungkan Ke Server...", greenColor);
                    }
                    socket = new Socket(serverAddr, Constants.SERVER_PORT);
                    if (socket.isBound()) {

                        //showMessage("Connected to Server...", clientTextColor, true);
                    }

                    while (!Thread.currentThread().isInterrupted()) {
                        input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                        String message = input.readLine();
                        if (null == message || Command.MESSAGE_CLIENT_DISCONNECT.contentEquals(message)) {
                            Thread.interrupted();
                            message = "Hubungan Ke Server Terputus...";                    
                            //showMessage(message, Color.RED, false);
                            if(mOnClientThreadListener != null){
                                mOnClientThreadListener.onMessage(message, Color.BLACK);
                            }
                            break;
                        }
                        //showMessage("Server: " + message, clientTextColor, true);
                        if(mOnClientThreadListener != null){
                            mOnClientThreadListener.onMessage(message, Color.BLACK);
                        }
                    }

                } catch (UnknownHostException e1) {
                    e1.printStackTrace();
                } catch (IOException e1) {
                    //showMessage("Problem Connecting to server... Check your server IP and Port and try again", Color.RED, false);
                    if(mOnClientThreadListener != null){
                        mOnClientThreadListener.onError("Ada Masalah Saat Menghubungkan Ke Server... Cek IP Dan Port Server Kamu. Kemudian Coba Lagi", Color.RED);
                    }
                    Thread.interrupted();
                    e1.printStackTrace();
                } catch (NullPointerException e3) {
                    //showMessage("error returned", Color.RED, true);
                    if(mOnClientThreadListener != null){
                        mOnClientThreadListener.onMessage("error returned", Color.RED);
                    }
                }
            }
        };    
        new Thread(run).start();  
        Log.e(TAG, "Client was killed");
        return null;
    }


    public void sendMessage(final String message) {
        new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        if (null != socket) {
                            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);                                                               
                            out.println(message);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }).start();
    }
}

