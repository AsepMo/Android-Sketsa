package com.app.client;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.content.Intent;
import android.content.ComponentName;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.os.Bundle;
import android.os.AsyncTask;
import android.text.TextWatcher;
import android.text.Editable;
import android.text.format.DateUtils;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.Toast;

import com.app.client.engine.animation.Part1TransitionController;
import com.app.client.engine.app.tasks.LoadTextTask;
import com.app.client.engine.app.tasks.SaveTask;
import com.app.client.engine.widget.Speakerbox;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener 
{

    private TextView mText;
    private ScrollView scroll;
    private EditText mEditText;
    private Speakerbox speakerbox;
    private Spinner spinnercity;
    String[] cityname={"Client","Server"};


    
    private LoadTextTask loadTask = null;
    private boolean loaded = false;
    
    private static final String FILENAME = "test.txt";
    public static final String CALCULATOR_PACKAGE ="com.android.calculator2";
    public static final String CALCULATOR_CLASS ="com.android.calculator2.Calculator";

    
    private File file;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle(R.string.app_name);

        mEditText = (EditText)findViewById(R.id.input);
        View inputDone = findViewById(R.id.input_done);
        final View focusHolder = findViewById(R.id.focus_holder);
        mText = (TextView)findViewById(R.id.translation);
        mText.setMovementMethod(LinkMovementMethod.getInstance());
        scroll = (ScrollView)findViewById(R.id.scrollView);
        spinnercity = (Spinner)findViewById(R.id.language);
        spinnercity.setOnItemSelectedListener(this);
        
        ArrayAdapter adapterspinner=new ArrayAdapter(this, android.R.layout.simple_spinner_item,cityname);
        adapterspinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnercity.setAdapter(adapterspinner);

        speakerbox = new Speakerbox(getApplication());
        speakerbox.setQueueMode(TextToSpeech.QUEUE_ADD);
        
        mEditText.setOnFocusChangeListener(Part1TransitionController.newInstance(this));
        mEditText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    String str = mEditText.getText().toString();
                    
                }

                @Override
                public void afterTextChanged(Editable editable) {
                }
            });

        inputDone.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(@NonNull View v) {
                    focusHolder.requestFocus();
                    String text = mEditText.getText().toString().trim();            
                    showMessage(text);
                }
            });
          
        file = new File(getExternalFilesDir(null), FILENAME);
        if(!file.exists()){
            
        }
        if (!loaded) {
            loadTask = new LoadTextTask(mEditText, loaded);
            loadTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, file);
        }    
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position,long id) {
        Toast.makeText(getApplicationContext(), cityname[position], Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    private void processResult(String command)
    {
        command = command.toLowerCase();
        if (command.indexOf("what")!= -1)
        {
            if (command.indexOf("your name")!= -1)
            {
                speakerbox.play("my name is Alexa");
            }
            else if (command.indexOf("time")!= -1)
            {
                Date now = new Date();
                String time = DateUtils.formatDateTime(this,now.getTime(), DateUtils.FORMAT_SHOW_TIME);
                speakerbox.play("the time now is"+ time);
            }
            else if (command.indexOf("date")!= -1)
            {
                Date now = new Date();
                String date = DateUtils.formatDateTime(this,now.getDate(), DateUtils.FORMAT_SHOW_DATE);
                speakerbox.play("the date is"+ date);
            }
            
        } else if (command.indexOf("open")!= -1)
        {
            if (command.indexOf("browser")!= -1)
            {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=AnNJPf-4T70"));
                startActivity(intent);
            }
            if (command.indexOf("calculator")!= -1)
            {
                Intent intent= new Intent();
                intent.setAction(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);
                intent.setComponent(new ComponentName( CALCULATOR_PACKAGE, CALCULATOR_CLASS));
                try
                {
                    startActivity(intent);
                } catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        } 
        else if(command.equalsIgnoreCase("AsepMo")){
            speakerbox.play("Pria Tampan.Tajir.Dan Digemari Banyak Wanita Cantik");
        } else if(command.equalsIgnoreCase("Siapa AsepMo Itu")){
            speakerbox.play("AsepMo Itu Adalah Seorang Pria Tampan.Tajir.Dan Digemari Banyak Wanita Cantik");
        }
        else{
            speakerbox.play(command);
        }
    }
    
    @Override
    protected void onResume() {
        super.onResume();
     
    }

    @Override
    protected void onPause() {
        super.onPause();
           if (loaded) {
            new SaveTask(mEditText.getText().toString(), file).start();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (loadTask != null) {
            loadTask.cancel(false);
        }
    }
   
    
    public void showMessage(String message){
        final String text = message;
        if(null == message || message.trim().isEmpty()){
            message = "Tidak Ada Pesan.Tulis Pesannya Dulu Kales..";
        }
        mText.post(new Runnable() {
                @Override
                public void run() {
                    mText.setText(text);
                    new SaveTask(text, file).start();
                    
                    // scroll TextView to bottom
                    scroll.post(new Runnable() {
                            @Override
                            public void run() {
                                scroll.fullScroll(View.FOCUS_DOWN);
                                scroll.clearFocus();
                            }
						});
               }
        });
        processResult(text);
    }
}

