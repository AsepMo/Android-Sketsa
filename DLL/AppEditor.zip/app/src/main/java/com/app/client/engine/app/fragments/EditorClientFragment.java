package com.app.client.engine.app.fragments;

import android.support.annotation.Nullable;
import android.support.annotation.NonNull;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.content.Context;
import android.content.Intent;
import android.content.ComponentName;
import android.net.Uri;
import android.speech.tts.TextToSpeech;
import android.os.Bundle;
import android.os.AsyncTask;
import android.text.TextWatcher;
import android.text.Editable;
import android.text.format.DateUtils;
import android.text.method.LinkMovementMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.ScrollView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.ImageButton;
import android.widget.Toast;

import com.app.client.R;
import com.app.client.engine.animation.Part1TransitionController;
import com.app.client.engine.app.tasks.LoadTextTask;
import com.app.client.engine.app.tasks.SaveTask;
import com.app.client.engine.widget.Speakerbox;

import java.io.File;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import com.app.client.engine.app.tasks.ClientThread;
import android.view.MenuInflater;


public class EditorClientFragment extends Fragment implements AdapterView.OnItemSelectedListener {

    public static String TAG = EditorClientFragment.class.getSimpleName();
    private static final String EXTRA_TEXT = "text";

    private Context mContext;
    private View mRootView;
    private Toolbar mToolbar;
    private TextView mText;
    private ScrollView scroll;
    private EditText mEditText;
    private Speakerbox speakerbox;
    private Spinner spinnercity;
    private ImageButton mSendButton;
    String[] cityname={"Client","Server"};

    private Thread thread;
    private ClientThread mClientThread;
    private LoadTextTask loadTask = null;
    private boolean loaded = false;

    private static final String FILENAME = "test.txt";
    public static final String CALCULATOR_PACKAGE ="com.android.calculator2";
    public static final String CALCULATOR_CLASS ="com.android.calculator2.Calculator";


    private File file;

    public static EditorClientFragment createFor(String text) {
        EditorClientFragment fragment = new EditorClientFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.fragment_app_editor_client, container, false);
        return mRootView;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        final String text = getArguments().getString(EXTRA_TEXT);
        mContext = getActivity();
        mToolbar = (Toolbar) view.findViewById(R.id.toolbar_fragment);
        mToolbar.inflateMenu(R.menu.menu_editor_client);
        mToolbar.setOnMenuItemClickListener(new Toolbar.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    return(onOptionsItemSelected(item));
                }
            });
        mEditText = (EditText)view.findViewById(R.id.input);
        View inputDone = view.findViewById(R.id.input_done);
        final View focusHolder = view.findViewById(R.id.focus_holder);
        mText = (TextView)view.findViewById(R.id.translation);
        mText.setMovementMethod(LinkMovementMethod.getInstance());
        scroll = (ScrollView)view.findViewById(R.id.scrollView);
        spinnercity = (Spinner)view.findViewById(R.id.language);
        spinnercity.setOnItemSelectedListener(this);
        mSendButton = (ImageButton)view.findViewById(R.id.send);

        ArrayAdapter adapterspinner = new ArrayAdapter(mContext, android.R.layout.simple_spinner_item, cityname);
        adapterspinner.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnercity.setAdapter(adapterspinner);

        speakerbox = new Speakerbox(getActivity().getApplication());
        speakerbox.setQueueMode(TextToSpeech.QUEUE_ADD);


        mEditText.setOnFocusChangeListener(Part1TransitionController.newInstance(getActivity()));
        mEditText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                }

                @Override
                public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                    String str = mEditText.getText().toString();
                    mText.setText(str);
                }

                @Override
                public void afterTextChanged(Editable editable) {
                }
            });

        inputDone.setOnClickListener(
            new View.OnClickListener() {
                @Override
                public void onClick(@NonNull View v) {
                    focusHolder.requestFocus();
                    String text = mEditText.getText().toString().trim();            
                    showMessage(text);
                }
            });
        mSendButton.setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    String message = mEditText.getText().toString();
                    
                    speakerbox.play("Mengirim Text Ke Server");   
                    mClientThread.sendMessage(message);
                }
            });
        file = new File(mContext.getExternalFilesDir(null), FILENAME);
        if (!file.exists()) {

        }
        if (!loaded) {
            loadTask = new LoadTextTask(mEditText, loaded);
            loadTask.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, file);
        }   

        mClientThread = new ClientThread(getActivity());
        mClientThread.setOnServerThreadListener(new ClientThread.OnClientThreadListener(){
                @Override
                public void onConnect(String message, int color) {
                    if (null == message || message.trim().isEmpty()) {
                        message = "<Empty Message>";
                    }  
                    speakerbox.play(message);
                }

                @Override
                public void onDisConnect(String message, int color) {                 
                    if (null == message || message.trim().isEmpty()) {
                        message = "<Empty Message>";
                    }  
                    speakerbox.play(message);      
                }

                @Override
                public void onMessage(String message, int color) {               
                    if (null == message || message.trim().isEmpty()) {
                        message = "<Empty Message>";
                    }  
                    speakerbox.play(message);
                } 

                @Override
                public void onError(String message, int color) {
                    if (null == message || message.trim().isEmpty()) {
                        message = "<Empty Message>";
                    }  
                    speakerbox.play(message);    
                }   
            });
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater); 
        inflater.inflate(R.menu.menu_editor_client, menu);
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.action_connect:
                //this initiates the serverthread defined later and starts the thread
                if (mClientThread != null)
                    mClientThread.execute();      
                return(true);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
        
        //Toast.makeText(mContext, cityname[position], Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> arg0) {
        // TODO Auto-generated method stub

    }

    private void processResult(String command) {
        command = command.toLowerCase();
        if (command.indexOf("what") != -1) {
            if (command.indexOf("your name") != -1) {
                speakerbox.play("Namaku klaudia");
            } else if (command.indexOf("time") != -1) {
                Date now = new Date();
                String time = DateUtils.formatDateTime(mContext, now.getTime(), DateUtils.FORMAT_SHOW_TIME);
                speakerbox.play("sekarang pukul" + time);
            } else if (command.indexOf("date") != -1) {
                Date now = new Date();
                String date = DateUtils.formatDateTime(mContext, now.getDate(), DateUtils.FORMAT_SHOW_DATE);
                speakerbox.play("Sekarang Tanggal" + date);
            } else if (command.indexOf("open") != -1) {
                if (command.indexOf("browser") != -1) {
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=AnNJPf-4T70"));
                    startActivity(intent);
                }
                if (command.indexOf("calculator") != -1) {
                    Intent intent= new Intent();
                    intent.setAction(Intent.ACTION_MAIN);
                    intent.addCategory(Intent.CATEGORY_LAUNCHER);
                    intent.setComponent(new ComponentName(CALCULATOR_PACKAGE, CALCULATOR_CLASS));
                    try {
                        startActivity(intent);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            } 
        } else if (command.equalsIgnoreCase("AsepMo")) {
            speakerbox.play("Pria Tampan.Tajir.Dan Digemari Banyak Wanita Cantik");
        } else if (command.equalsIgnoreCase("Siapa AsepMo Itu")) {
            speakerbox.play("AsepMo Itu Adalah Seorang Pria Tampan.Tajir.Dan Digemari Banyak Wanita Cantik");
        } else {
            speakerbox.play(command);        
        }
    }


    @Override
    public void onResume() {
        super.onResume();

    }

    @Override
    public void onPause() {
        super.onPause();
        if (loaded) {
            new SaveTask(mEditText.getText().toString(), file).start();
        }
    }

    @Override
    public void onStop() {
        super.onStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (loadTask != null) {
            loadTask.cancel(false);
        }
        speakerbox.stop();
    }


    public void sendMessage(String message) {
        if (null == message || message.trim().isEmpty()) {
            message = "Tidak Ada Pesan.Tulis Pesannya Dulu Kales..";
        }
        mText.setText(message);
        new SaveTask(message, file).start();
        processResult(message);
    }

    public void showMessage(final String message) {
        mText.post(new Runnable() {
                @Override
                public void run() {
                    sendMessage(message);
                    // scroll TextView to bottom
                    scroll.post(new Runnable() {
                            @Override
                            public void run() {
                                scroll.fullScroll(View.FOCUS_DOWN);
                                scroll.clearFocus();
                            }
                        });
                }
            });
    }
}
