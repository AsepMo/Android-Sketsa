package com.vitamin.complex.engine.widget;

import android.view.MenuItem;

public interface OptionsMenuListener {
    void onOptionsItemSelected(MenuItem item);
}
