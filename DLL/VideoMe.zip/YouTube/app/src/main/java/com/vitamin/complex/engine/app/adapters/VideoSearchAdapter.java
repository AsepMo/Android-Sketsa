package com.vitamin.complex.engine.app.adapters;

public class VideoSearchAdapter {
    
}