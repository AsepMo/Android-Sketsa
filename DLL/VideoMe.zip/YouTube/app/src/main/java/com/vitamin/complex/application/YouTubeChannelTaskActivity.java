package com.vitamin.complex.application;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.FrameLayout;

import java.io.File;
import com.vitamin.complex.R;

public class YouTubeChannelTaskActivity extends AppCompatActivity{
    
    public static String TAG = YouTubeChannelTaskActivity.class.getSimpleName();
    public static void start(Context c) {
        Intent mIntent = new Intent(c, YouTubeChannelTaskActivity.class);
        c.startActivity(mIntent);
    }
    
    public static String ACTION_ADD_PLAYLIST = "addPlaylist";
    public static String ADD_PLAYLIST = "playlistId";
    
    
    public static FrameLayout mProgress;
    
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_youtube_task);
        
        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        
       // YouTubeFolder.initYouTubeFolder();
        
        mProgress = (FrameLayout)findViewById(R.id.progress_bar_layout);
        mProgress.setVisibility(View.VISIBLE);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
    }

}
