package com.vitamin.complex.engine.app.fragments;

import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Environment;
import android.util.Log;
import android.speech.RecognizerIntent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.PopupMenu;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.Toast;

import java.util.List;
import java.util.ArrayList;

import com.vitamin.complex.engine.app.models.VideoSearch;
import com.vitamin.complex.engine.app.adapters.VideoListAdapter;
import com.vitamin.complex.engine.app.db.DatabaseHandler;
import com.vitamin.complex.engine.app.tasks.SearchVideoTask;
import com.vitamin.complex.engine.widget.SearchBox;
import com.vitamin.complex.engine.widget.SearchBox.MenuListener;
import com.vitamin.complex.engine.widget.SearchBox.SearchListener;
import com.vitamin.complex.engine.widget.SearchResult;

import java.util.ArrayList;

import com.vitamin.complex.R;
import com.vitamin.complex.application.ApplicationActivity;
import java.util.concurrent.ExecutionException;

public class YouTubeSearchFragment extends Fragment {


    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_POSITION = "message";
    private static final String TAG = YouTubeSearchFragment.class.getSimpleName();

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    public static YouTubeSearchFragment newInstance(int position) {
        YouTubeSearchFragment f = new YouTubeSearchFragment();
        Bundle b = new Bundle();
        b.putInt(ARG_POSITION, position);
        f.setArguments(b);

        return f;
    }

    public YouTubeSearchFragment() {
    }
    
    private static final String EXTRA_TEXT = "text";
    private String message;
    private Context mContext;
    Boolean isSearch;
	private SearchBox search;
    private ListView videosFound;
    private List<VideoSearch> searchResults;
    private LayoutInflater mInflater;
    public static VideoListAdapter adapter;
    public static int activeVideoIndex = 0;
    public static DatabaseHandler db;
    public static YouTubeSearchFragment createFor(String text) {
        YouTubeSearchFragment fragment = new YouTubeSearchFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        message = getArguments().getString(ARG_POSITION);

              
        /* ActionBar actionBar = mActivity.getSupportActionBar();
         actionBar.setDisplayShowCustomEnabled(true);

         SearchView searchView = new SearchView(actionBar.getThemedContext());
         searchView.setOnQueryTextListener(this);
         ActionBar.LayoutParams layoutParams = new ActionBar.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,                                                                         ViewGroup.LayoutParams.MATCH_PARENT);
         actionBar.setCustomView(searchView, layoutParams);*/

        setHasOptionsMenu(true);
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater,  ViewGroup container, Bundle savedInstanceState) {
        
        return inflater.inflate(R.layout.fragment_youtube_search, container, false);
    }

    @Override
    public void onViewCreated(View view,  Bundle savedInstanceState) {

        final String text = getArguments().getString(EXTRA_TEXT);
        mContext = getActivity();

        search = (SearchBox) view.findViewById(R.id.searchbox);
        search.enableVoiceRecognition(this);
        /* for(int x = 0; x < 10; x++){
         SearchResult option = new SearchResult("Result " + Integer.toString(x), getResources().getDrawable(R.drawable.ic_history));
         search.addSearchable(option);
         }*/
        search.setMenuListener(new MenuListener(){

                @Override
                public void onMenuClick() {
                    //Hamburger has been clicked
                    Toast.makeText(mContext, "Menu click", Toast.LENGTH_LONG).show();              
                }

            });
        search.setSearchListener(new SearchListener(){

                @Override
                public void onSearchOpened() {
                    //Use this to tint the screen
                }

                @Override
                public void onSearchClosed() {
                    //Use this to un-tint the screen
                }

                @Override
                public void onSearchTermChanged(String term) {
                    //React to the search term changing
                    //Called after it has updated results
                    SearchResult option = new SearchResult(term, getResources().getDrawable(R.drawable.ic_history));
                    search.addSearchable(option);                  
                }

                @Override
                public void onSearch(String searchTerm) {
                    searchKey(searchTerm);
                    
                    Toast.makeText(mContext, searchTerm + " Searched", Toast.LENGTH_LONG).show();
                }

                @Override
                public void onResultClick(SearchResult result) {
                    //React to a result being clicked
                    searchKey(result.toString());  
                }

                @Override
                public void onSearchCleared() {
                    //Called when the clear button is clicked
                }

            });
        search.setOverflowMenu(R.menu.overflow_menu);
        search.setOverflowMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.test_menu_item:
                            Toast.makeText(mContext, "Clicked!", Toast.LENGTH_SHORT).show();
                            return true;
                    }
                    return false;
                }
            });
        db = new DatabaseHandler(getActivity());    
        videosFound = (ListView) view.findViewById(R.id.list_found);
        searchResults = new ArrayList<VideoSearch>();
        mInflater = getLayoutInflater();
        adapter = new VideoListAdapter(getActivity(), R.layout.video_item, searchResults, mInflater, VideoListAdapter.SEARCH_ITEM_LAYOUT, -1);
        videosFound.setAdapter(adapter);
      
    }

    public void searchKey(String keyword) {         
        Log.i("keyword", keyword);
        SearchVideoTask searchVideoTask = new SearchVideoTask(getActivity());
        try {
            adapter.clear();
            searchResults = searchVideoTask.execute(keyword).get();
            for (int i = 0; i < searchResults.size(); ++i) {
                adapter.add(searchResults.get(i));        
            }

            Log.i("result", Integer.toString(searchResults.size()));
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (ExecutionException e) {
            e.printStackTrace();
        }

        Log.i("info", "ending search");
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == 1234 && resultCode == Activity.RESULT_OK) {
            ArrayList<String> matches = data
                .getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            search.populateEditText(matches.get(0));
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

}
