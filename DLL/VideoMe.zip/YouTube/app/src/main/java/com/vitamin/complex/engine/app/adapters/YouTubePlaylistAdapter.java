package com.vitamin.complex.engine.app.adapters;

public class YouTubePlaylistAdapter {
    
}