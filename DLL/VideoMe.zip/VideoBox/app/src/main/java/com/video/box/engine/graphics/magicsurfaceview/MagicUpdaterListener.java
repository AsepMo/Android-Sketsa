package com.video.box.engine.graphics.magicsurfaceview;

public interface MagicUpdaterListener {
    void onStart();
    void onStop();
}
