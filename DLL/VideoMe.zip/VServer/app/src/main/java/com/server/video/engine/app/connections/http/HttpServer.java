package com.server.video.engine.app.connections.http;

import android.content.Context;

import com.server.video.AppController;
import com.server.video.engine.app.utils.Utils;

public class HttpServer {

    public static String TAG = HttpServer.class.getSimpleName();
    private Context mContext;
    private final static int SERVER_PORT = 0;
    private static HttpServer mHttpServer;
    private int mPort;
    private HttpServiceThread mServiceThread;
    private ThreadGroup mThreadGroup;
    public static HttpServer getInstance() {
        if (null == mHttpServer) {
            mHttpServer = new HttpServer(AppController.getContext());
        }
        return mHttpServer;
    }

    private HttpServer(Context c) {
        this.mContext = c;
        mThreadGroup = new ThreadGroup(HttpServer.class.getName());
    }

    public boolean start(IHttpStream stream, int port) {
        if (0 == port)
            port = SERVER_PORT;
        mPort = port;
        try {
            if (null != mServiceThread) {
                if (mServiceThread.isBound()) {
                    mPort = mServiceThread.getPort();
                    mServiceThread.setStream(stream);
                    return true;
                }
                mServiceThread.close();
            }
            mServiceThread = new HttpServiceThread(stream, mThreadGroup, port);
            mPort = mServiceThread.getPort();
            mServiceThread.start();
            return true;
        } catch (Exception e) {
            mServiceThread = null;
            e.printStackTrace();
        }
        return false;
    }

    public void stop() {
        if (null != mServiceThread) {
            mServiceThread.close();
            mServiceThread = null;
        }
    }


    public String getHttpAddr() {
        return "http://" + AppController.getServerIP() + ":" + mPort;
    }

    @Override
    protected void finalize() throws Throwable {
        stop();
    }
}

