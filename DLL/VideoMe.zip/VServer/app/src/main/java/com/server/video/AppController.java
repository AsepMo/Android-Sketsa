package com.server.video;

import android.app.Application;
import android.content.Context;
import android.content.Intent;
import android.graphics.Point;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.wifi.WifiManager;
import android.support.annotation.Nullable;
import android.util.DisplayMetrics;
import android.view.WindowManager;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Locale;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.LinkedTransferQueue;

import com.server.video.application.ApplicationSettings;
import com.server.video.engine.app.utils.Utils;

public class AppController extends Application {
    
    private static AppController isInstance;
    private static Context mContext;
    private volatile boolean isStreamRunning;
    private volatile boolean isForegroundServiceRunning;
    private ApplicationSettings applicationSettings;
    private WindowManager windowManager;
    private int densityDPI;
    private String indexHtmlPage;
    private byte[] iconBytes;

    
    @Override
    public void onCreate() {
        super.onCreate();
        
        isInstance = this;
        mContext = this;
        applicationSettings = new ApplicationSettings(this);
        windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        
    }
    
    public static synchronized AppController getInstance() {
        return isInstance;
    }

    public static Context getContext() {
        return mContext;
    }
    
    public static ApplicationSettings getApplicationSettings() {
        return isInstance.applicationSettings;
    }
    
    public static WindowManager getWindowsManager() {
        return isInstance.windowManager;
    }
    
    public static int getScreenDensity() {
        return isInstance.densityDPI;
    }

    public static float getScale() {
        return isInstance.getResources().getDisplayMetrics().density;
    }

    public static Point getScreenSize() {
        final Point screenSize = new Point();
        isInstance.windowManager.getDefaultDisplay().getRealSize(screenSize);
        return screenSize;
    }
    
    public static String getServerIP() {
        return Utils.getCurrentIP(mContext);
    }
    
    public static boolean isStreamRunning() {
        return isInstance.isStreamRunning;
    }

    public static void setIsStreamRunning(final boolean isRunning) {
        isInstance.isStreamRunning = isRunning;
    }

    public static boolean isForegroundServiceRunning() {
        return isInstance.isForegroundServiceRunning;
    }

    public static void setIsForegroundServiceRunning(final boolean isRunning) {
        isInstance.isForegroundServiceRunning = isRunning;
    }
}
