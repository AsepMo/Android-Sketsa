package com.server.video.service;

import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.ContextCompat;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Process;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;

import com.server.video.R;
import com.server.video.AppController;
import com.server.video.MainActivity;
import com.server.video.engine.app.connections.http.HttpServer;
import com.server.video.engine.app.connections.http.IHttpStream;
import com.server.video.engine.app.connections.http.HttpConnection;
import com.server.video.engine.app.tasks.ForegroundTaskHandler;

public class VideoService extends Service {
    
    public static String TAG = VideoService.class.getSimpleName();
    private static VideoService foregroundService;
    private ForegroundTaskHandler foregroundServiceTaskHandler;
    private HttpServer httpServer;
    
    // Fields for broadcast
    public static final String SERVICE_ACTION = "com.server.video.service.VideoService.SERVICE_ACTION";

    public static final String SERVICE_PERMISSION = "com.server.video.RECEIVE_BROADCAST";
    public static final String SERVICE_MESSAGE = "SERVICE_MESSAGE";
    public static final int SERVICE_MESSAGE_GET_STATUS = 1000;
    public static final int SERVICE_MESSAGE_UPDATE_STATUS = 1005;
    public static final int SERVICE_MESSAGE_PREPARE_STREAMING = 1010;
    public static final int SERVICE_MESSAGE_START_STREAMING = 1020;
    public static final int SERVICE_MESSAGE_STOP_STREAMING = 1030;
    public static final int SERVICE_MESSAGE_RESTART_HTTP = 1040;
    public static final int SERVICE_MESSAGE_HTTP_PORT_IN_USE = 1050;
    public static final int SERVICE_MESSAGE_HTTP_OK = 1060;
    public static final int SERVICE_MESSAGE_EXIT = 1100;

    public static final String SERVICE_MESSAGE_CLIENTS_COUNT = "SERVICE_MESSAGE_CLIENTS_COUNT";
    public static final int SERVICE_MESSAGE_GET_CLIENT_COUNT = 1110;
    public static final String SERVICE_MESSAGE_SERVER_ADDRESS = "SERVICE_MESSAGE_SERVER_ADDRESS";
    public static final int SERVICE_MESSAGE_GET_SERVER_ADDRESS = 1120;

    private int currentServiceMessage;

    // Fields for notifications
    private Notification startNotification;
    private BroadcastReceiver localNotificationReceiver;
    private final String KEY_START = "com.server.video.service.VideoService.startStream";
    private final Intent startStreamIntent = new Intent(KEY_START);
    private final String KEY_STOP = "com.server.video.service.VideoService.stopStream";
    private final Intent stopStreamIntent = new Intent(KEY_STOP);
    private final String KEY_CLOSE = "com.server.video.service.VideoService.closeService";
    private final Intent closeIntent = new Intent(KEY_CLOSE);

    private BroadcastReceiver broadcastReceiver;
    private String video = "/sdcard/DCIM/my_video.mp4";
    
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


    @Override
    public void onCreate() {
        super.onCreate();
        foregroundService = this;

        // Starting thread Handler
        final HandlerThread looperThread = new HandlerThread("ForegroundServiceHandlerThread", Process.THREAD_PRIORITY_MORE_FAVORABLE);
        looperThread.start();
        foregroundServiceTaskHandler = new ForegroundTaskHandler(looperThread.getLooper());
        httpServer = HttpServer.getInstance();
        //Local notifications
        startNotification = getNotificationStart();

        final IntentFilter localNotificationIntentFilter = new IntentFilter();
        localNotificationIntentFilter.addAction(KEY_START);
        localNotificationIntentFilter.addAction(KEY_STOP);
        localNotificationIntentFilter.addAction(KEY_CLOSE);

        localNotificationReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (intent.getAction().equals(KEY_START)) {
                    currentServiceMessage = SERVICE_MESSAGE_START_STREAMING;
                    relayMessageViaActivity();
                }

                if (intent.getAction().equals(KEY_STOP)) {
                    currentServiceMessage = SERVICE_MESSAGE_STOP_STREAMING;
                    relayMessageViaActivity();
                }

                if (intent.getAction().equals(KEY_CLOSE)) {
                    currentServiceMessage = SERVICE_MESSAGE_EXIT;
                    relayMessageViaActivity();
                }
            }
        };

        registerReceiver(localNotificationReceiver, localNotificationIntentFilter);

        // Registering receiver for screen off messages
        final IntentFilter screenOnOffFilter = new IntentFilter();
        screenOnOffFilter.addAction(Intent.ACTION_SCREEN_OFF);
        screenOnOffFilter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);

        broadcastReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                if (AppController.getApplicationSettings().isPauseOnSleep())
                    if (intent.getAction().equals(Intent.ACTION_SCREEN_OFF))
                        if (AppController.isStreamRunning()) {
                            currentServiceMessage = SERVICE_MESSAGE_STOP_STREAMING;
                            relayMessageViaActivity();
                        }

                if (intent.getAction().equals(WifiManager.NETWORK_STATE_CHANGED_ACTION)) {
                    currentServiceMessage = SERVICE_MESSAGE_GET_STATUS;
                    sendBroadcast(new Intent(SERVICE_ACTION).putExtra(SERVICE_MESSAGE, SERVICE_MESSAGE_UPDATE_STATUS), SERVICE_PERMISSION);
                }
            }
        };

        registerReceiver(broadcastReceiver, screenOnOffFilter);

        sendBroadcast(new Intent(SERVICE_ACTION).putExtra(SERVICE_MESSAGE, SERVICE_MESSAGE_UPDATE_STATUS), SERVICE_PERMISSION); 
    }


    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        final int messageFromActivity = intent.getIntExtra(SERVICE_MESSAGE, 0);
        if (messageFromActivity == 0) return START_NOT_STICKY;

        if (messageFromActivity == SERVICE_MESSAGE_PREPARE_STREAMING) {
            startForeground(110, startNotification);
            AppController.setIsForegroundServiceRunning(true);
        }

        if (messageFromActivity == SERVICE_MESSAGE_GET_STATUS) {
            sendCurrentServiceMessage();
            sendServerAddress();
            sendClientCount();
        }

        if (messageFromActivity == SERVICE_MESSAGE_START_STREAMING) {
            stopForeground(true);
            foregroundServiceTaskHandler.obtainMessage(ForegroundTaskHandler.HANDLER_START_STREAMING).sendToTarget();
            startForeground(120, getNotificationStop());
            initServer(video);
        }

        if (messageFromActivity == SERVICE_MESSAGE_STOP_STREAMING) {
            stopForeground(true);
            foregroundServiceTaskHandler.obtainMessage(ForegroundTaskHandler.HANDLER_STOP_STREAMING).sendToTarget();
            startForeground(110, startNotification);

            
        }

        if (messageFromActivity == SERVICE_MESSAGE_RESTART_HTTP) {
            
        }

        return START_NOT_STICKY;
    }
    
    void initServer(final String filePath) {
        File file = new File(filePath);
        if (!file.exists()) {
            Toast.makeText(this, "文件不存在", Toast.LENGTH_LONG).show();
            return;
        }
        
        httpServer.start(new IHttpStream() {
            @Override
            public boolean writeStream(OutputStream out, String path, int rangS, int rangE) throws IOException {
                int streamLen;
                int readLen;
                int leftLen;
                Uri uri = Uri.parse(path);
                String pathString = uri.getQueryParameter("path");
                if (pathString == null || pathString.equals("")) {
                    HttpConnection.send404Response(out, path);
                } else {
                    String type = HttpConnection.getContentType(pathString);
                    byte[] buffer = new byte[1024 * 10];
                    InputStream mMediaInputStream = new FileInputStream(filePath);
                    if (isEncrypted(filePath, "547fedc3a4bff6c8758987daa2a1cb84")) {
                        mMediaInputStream.skip(32);
                    }
                    streamLen = mMediaInputStream.available();
                    if (rangS >= 0) {
                        mMediaInputStream.skip(rangS);
                        rangE = rangE > streamLen ? streamLen : rangE;
                        HttpConnection.sendOkResponse(out, rangE - rangS, type, rangS, rangE, mMediaInputStream.available());
                        leftLen = rangE - rangS;
                        while (leftLen > 0) {
                            readLen = mMediaInputStream.read(buffer);
                            out.write(buffer, 0, readLen);
                            leftLen -= readLen;
                        }
                        out.flush();
                        out.close();
                    } else {
                        HttpConnection.sendOkResponse(out, mMediaInputStream.available(), type);
                        while (true) {
                            readLen = mMediaInputStream.read(buffer);
                            if (readLen <= 0) break;
                            out.write(buffer, 0, readLen);
                        }
                        out.flush();
                        out.close();
                    }
                }
                return false;
            }

            @Override
            public boolean isOpen() {
                return true;
            }

            @Override
            public boolean acceptRange() {
                return true;
            }
        }, 8080);
        Uri uri = Uri.parse(httpServer.getHttpAddr() + "/?path=" + URLEncoder.encode(filePath));
        Log.i("Sunmeng",uri.getPath());
    }

    private boolean isEncrypted(String filePath, String key) {
        try {
            InputStream encrypted = new FileInputStream(filePath);
            byte[] b = new byte[32];
            encrypted.read(b);
            if (!key.equals(new String(b, "UTF-8"))) {
                encrypted.close();
                return false;
            } else if (key.equals(new String(b, "UTF-8"))) {
                encrypted.close();
                return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void onDestroy() {
        
        stopForeground(true);
        unregisterReceiver(broadcastReceiver);
        unregisterReceiver(localNotificationReceiver);
        if (httpServer != null)
            httpServer.stop();
        foregroundServiceTaskHandler.getLooper().quit();
    }

    private void relayMessageViaActivity() {
        startActivity(new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        sendBroadcast(new Intent(SERVICE_ACTION).putExtra(SERVICE_MESSAGE, SERVICE_MESSAGE_UPDATE_STATUS), SERVICE_PERMISSION);
    }
    
    // Private methods
    private Notification getNotificationStart() {
        final Intent mainActivityIntent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        final PendingIntent pendingMainActivityIntent = PendingIntent.getActivity(this, 0, mainActivityIntent, 0);
        final NotificationCompat.Builder startNotificationBuilder = new NotificationCompat.Builder(this);
        startNotificationBuilder.setSmallIcon(R.drawable.ic_cast_http_24dp);
        startNotificationBuilder.setColor(ContextCompat.getColor(this, R.color.colorPrimaryDark));
        startNotificationBuilder.setContentTitle(getResources().getString(R.string.server_ready_to_stream));
        startNotificationBuilder.setContentText(getResources().getString(R.string.server_press_start));
        startNotificationBuilder.setContentIntent(pendingMainActivityIntent);
        startNotificationBuilder.addAction(R.drawable.ic_play_arrow_24dp, getResources().getString(R.string.server_start), PendingIntent.getBroadcast(this, 0, startStreamIntent, 0));
        startNotificationBuilder.addAction(R.drawable.ic_clear_24dp, getResources().getString(R.string.server_close), PendingIntent.getBroadcast(this, 0, closeIntent, 0));
        startNotificationBuilder.setPriority(NotificationCompat.PRIORITY_MAX);
        return startNotificationBuilder.build();
    }

    private Notification getNotificationStop() {
        final Intent mainActivityIntent = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        final PendingIntent pendingMainActivityIntent = PendingIntent.getActivity(this, 0, mainActivityIntent, 0);
        Uri uri = Uri.parse(httpServer.getHttpAddr() + "/?path=" + URLEncoder.encode(video));
        
        final NotificationCompat.Builder stopNotificationBuilder = new NotificationCompat.Builder(this);
        stopNotificationBuilder.setSmallIcon(R.drawable.ic_cast_http_24dp);
        stopNotificationBuilder.setColor(ContextCompat.getColor(this, R.color.colorPrimaryDark));
        stopNotificationBuilder.setContentTitle(getResources().getString(R.string.server_stream));
        stopNotificationBuilder.setContentText(getResources().getString(R.string.server_go_to) + uri.getPath());
        stopNotificationBuilder.setContentIntent(pendingMainActivityIntent);
        stopNotificationBuilder.addAction(R.drawable.ic_stop_24dp, getResources().getString(R.string.server_stop), PendingIntent.getBroadcast(this, 0, stopStreamIntent, 0));
        stopNotificationBuilder.setPriority(NotificationCompat.PRIORITY_MAX);
        return stopNotificationBuilder.build();
    }

    private void sendCurrentServiceMessage() {
        sendBroadcast(new Intent(SERVICE_ACTION).putExtra(SERVICE_MESSAGE, currentServiceMessage),
                      SERVICE_PERMISSION);
        currentServiceMessage = 0;
    }

    private void sendClientCount() {
       /* sendBroadcast(new Intent(SERVICE_ACTION)
                      .putExtra(SERVICE_MESSAGE, SERVICE_MESSAGE_GET_CLIENT_COUNT)
                      .putExtra(SERVICE_MESSAGE_CLIENTS_COUNT, AppController.getClientQueue().size()),
                      SERVICE_PERMISSION);*/
    }

    private void sendServerAddress() {
        sendBroadcast(new Intent(SERVICE_ACTION)
                      .putExtra(SERVICE_MESSAGE, SERVICE_MESSAGE_GET_SERVER_ADDRESS)
                      .putExtra(SERVICE_MESSAGE_SERVER_ADDRESS, AppController.getServerIP()),
                      SERVICE_PERMISSION);
    }
    
    @Override
    public boolean onUnbind(Intent intent) {
        return super.onUnbind(intent);
    }
}
