package com.server.video.engine.app.connections.http;

import java.io.IOException;
import java.io.OutputStream;

public interface IHttpStream {

    boolean writeStream(OutputStream out, String path, int rangeStart, int rangeEnd) throws IOException;
    boolean isOpen();
    boolean acceptRange();

}

