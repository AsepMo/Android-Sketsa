package com.github.video.player.adapters;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import java.util.List;

import com.bumptech.glide.Glide;

import com.github.video.player.R;
import com.github.video.player.VideoPlayerActivity;
import com.github.video.player.models.VideoModel;
import com.github.video.player.widget.ParallaxImageView;
import android.widget.TextView;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoViewHolder> {

    private List<VideoModel> videoList;

    public VideoAdapter(List<VideoModel> videoList) {
        this.videoList = videoList;
    }

    public class VideoViewHolder extends RecyclerView.ViewHolder {
        public ImageView imageViewThumbnail;
        public ImageView btnShare;
        public ImageView btnEdit;
        public TextView videoTitle;
        VideoViewHolder(View view) {
            super(view);
           // videoTitle = (TextView)view.findViewById(R.id.name);
            imageViewThumbnail = (ImageView)view.findViewById(R.id.image);
            btnShare = (ImageView)view.findViewById(R.id.action_share);
            btnEdit = (ImageView)view.findViewById(R.id.action_edit);
            
        }
    }


    @Override
    public VideoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.album_cover_card, parent, false);

        return new VideoViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final VideoViewHolder holder, int position) {
        final VideoModel mVideo = videoList.get(position);
     //   holder.videoTitle.setText(mVideo.getVideoDuration());
        Glide.with(holder.itemView.getContext()).load(mVideo.getVideoThumb()).placeholder(R.drawable.video_placeholder).into(holder.imageViewThumbnail);
   //     holder.imageViewThumbnail.setParallaxTranslation();
        holder.imageViewThumbnail.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(holder.itemView.getContext(), mVideo.getFilePath(), Toast.LENGTH_SHORT).show();
                    Intent mPlayerIntent = VideoPlayerActivity.getStartIntent(holder.itemView.getContext(),mVideo.getFileName(), mVideo.getFilePath());
                    holder.itemView.getContext().startActivity(mPlayerIntent);
                }
            });
        holder.btnShare.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(holder.itemView.getContext(),"Action Share " , Toast.LENGTH_SHORT).show();
                }
            });
        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(holder.itemView.getContext(), "Action Edit", Toast.LENGTH_SHORT).show();
                }
            });    
    }

    @Override
    public int getItemCount() {
        return videoList.size();
    }
}



