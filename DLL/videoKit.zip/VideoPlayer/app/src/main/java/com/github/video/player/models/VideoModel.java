package com.github.video.player.models;

public class VideoModel {
    private String mFilePath;
    private String mFileName;
    
    private String mVideoThumb;
    private String mVideoDuration;
    private boolean isSelected;

    public String getFilePath() {
        return mFilePath;
    }

    public void setFilePath(String mFilePath) {
        this.mFilePath = mFilePath;
    }

    public String getFileName() {
        return mFileName;
    }

    public void setFileName(String mFileName) {
        this.mFileName = mFileName;
    }
    
    public String getVideoThumb() {
        return mVideoThumb;
    }

    public void setVideoThumb(String mVideoThumb) {
        this.mVideoThumb = mVideoThumb;
    }

    public String getVideoDuration() {
        return mVideoDuration;
    }

    public void setVideoDuration(String mVideoDuration) {
        this.mVideoDuration = mVideoDuration;
    }

    public boolean isSelected() {
        return isSelected;
    }

    public void setSelected(boolean selected) {
        isSelected = selected;
    }
}


