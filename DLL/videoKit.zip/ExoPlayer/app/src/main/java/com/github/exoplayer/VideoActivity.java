package com.github.exoplayer;

import android.Manifest;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.SharedElementCallback;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SimpleItemAnimator;
import android.support.v7.widget.Toolbar;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.transition.Fade;
import android.transition.Slide;
import android.transition.TransitionSet;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.WindowInsets;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.Toast;

import java.util.ArrayList;

import com.github.exoplayer.models.VideoModel;
import com.github.exoplayer.adapters.VideoAdapter;
import com.github.exoplayer.tasks.VideoTask;
import com.github.exoplayer.widget.FastScrollerRecyclerView;
import com.github.exoplayer.widget.GridMarginDecoration;
import com.github.exoplayer.widget.ParallaxImageView;
import com.github.exoplayer.utils.VideoUtils;

public class VideoActivity extends AppCompatActivity 
{

    public static final String RECYCLER_VIEW_SCROLL_STATE = "RECYCLER_VIEW_STATE";
    private static final int REQUEST_PERMISSIONS = 101;
    
    private Toolbar toolbar;
    public static ArrayList<VideoModel> mVideoList;
    public static VideoAdapter mAdapter;
    public static RecyclerView mRecyclerView;
    private GridLayoutManager recyclerViewLayoutManager;
    
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);
        
        
        toolbar = (Toolbar)findViewById(R.id.toolbar);
        toolbar.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
        toolbar.setTitleTextColor(getResources().getColor(R.color.white));
                            
        setSupportActionBar(toolbar);
        
        mRecyclerView = (RecyclerView)findViewById(R.id.recyclerViewGallery);
        recyclerViewLayoutManager = new GridLayoutManager(getApplicationContext(), 2);
        mRecyclerView.setLayoutManager(recyclerViewLayoutManager);
        
        float albumGridSpacing = getResources().getDimension(R.dimen.album_grid_spacing);
        ((FastScrollerRecyclerView) mRecyclerView).addOuterGridSpacing((int) (albumGridSpacing / 2));
        mRecyclerView.addItemDecoration(new GridMarginDecoration((int) albumGridSpacing));
        if (savedInstanceState != null && savedInstanceState.containsKey(RECYCLER_VIEW_SCROLL_STATE)) {
            mRecyclerView.getLayoutManager().onRestoreInstanceState(savedInstanceState.getParcelable(RECYCLER_VIEW_SCROLL_STATE));
        }

        //mRecyclerView.setTag(ParallaxImageView.RECYCLER_VIEW_TAG);
        
        //disable default change animation
        ((SimpleItemAnimator) mRecyclerView.getItemAnimator()).setSupportsChangeAnimations(false);

        mRecyclerView.addOnScrollListener(new RecyclerView.OnScrollListener() {
                //private float scrollY = 0.0f;

                @Override
                public void onScrolled(RecyclerView recyclerView, int dx, int dy) {
                    super.onScrolled(recyclerView, dx, dy);
                    

                    float translationY = toolbar.getTranslationY() - dy;
                    if (-translationY > toolbar.getHeight()) {
                        translationY = -toolbar.getHeight();
                        
                    } else if (translationY > 0) {
                        translationY = 0;
                        if (!scrollToTheTop()) {
                            toolbar.setActivated(false);
                        }else{
                            toolbar.setActivated(true);
                            toolbar.setBackgroundColor(getResources().getColor(R.color.colorPrimary));
                            toolbar.setTitleTextColor(getResources().getColor(R.color.white));             
                        }
                    }
                    toolbar.setTranslationY(translationY);
                }
            });

        //setting window insets manually
        final ViewGroup rootView = findViewById(R.id.root_view);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            rootView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
                    @Override
                    @RequiresApi(api = Build.VERSION_CODES.KITKAT_WATCH)
                    public WindowInsets onApplyWindowInsets(View view, WindowInsets insets) {
                        // clear this listener so insets aren't re-applied
                        rootView.setOnApplyWindowInsetsListener(null);
                        Log.d("MainActivity", "onApplyWindowInsets()"
                              + "[" + insets.getSystemWindowInsetLeft() + ", " +
                              insets.getSystemWindowInsetTop() + ", " +
                              insets.getSystemWindowInsetRight() + ", " +
                              insets.getSystemWindowInsetBottom() + "]");

                        toolbar.setPadding(toolbar.getPaddingStart(),
                                           toolbar.getPaddingTop() + insets.getSystemWindowInsetTop(),
                                           toolbar.getPaddingEnd(),
                                           toolbar.getPaddingBottom());

                        ViewGroup.MarginLayoutParams toolbarParams
                            = (ViewGroup.MarginLayoutParams) toolbar.getLayoutParams();
                        toolbarParams.leftMargin = insets.getSystemWindowInsetLeft();
                        toolbarParams.rightMargin = insets.getSystemWindowInsetRight();
                        toolbar.setLayoutParams(toolbarParams);

                        mRecyclerView.setPadding(mRecyclerView.getPaddingStart() + insets.getSystemWindowInsetLeft(),
                                                 mRecyclerView.getPaddingTop() + insets.getSystemWindowInsetTop(),
                                                 mRecyclerView.getPaddingEnd() + insets.getSystemWindowInsetRight(),
                                                 mRecyclerView.getPaddingBottom() + insets.getSystemWindowInsetBottom());

                        //fab.setTranslationY(-insets.getSystemWindowInsetBottom());
                        //fab.setTranslationX(-insets.getSystemWindowInsetRight());

                        return insets.consumeSystemWindowInsets();
                    }
                });
        } else {
            rootView.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                    @Override
                    public void onGlobalLayout() {
                        rootView.getViewTreeObserver().removeOnGlobalLayoutListener(this);
                        // hacky way of getting window insets on pre-Lollipop
                        // somewhat works...
                        int[] screenSize = VideoUtils.getScreenSize(VideoActivity.this);

                        int[] windowInsets = new int[]{
                            Math.abs(screenSize[0] - rootView.getLeft()),
                            Math.abs(screenSize[1] - rootView.getTop()),
                            Math.abs(screenSize[2] - rootView.getRight()),
                            Math.abs(screenSize[3] - rootView.getBottom())};

                        toolbar.setPadding(toolbar.getPaddingStart(),
                                           toolbar.getPaddingTop() + windowInsets[1],
                                           toolbar.getPaddingEnd(),
                                           toolbar.getPaddingBottom());

                        ViewGroup.MarginLayoutParams toolbarParams
                            = (ViewGroup.MarginLayoutParams) toolbar.getLayoutParams();
                        toolbarParams.leftMargin += windowInsets[0];
                        toolbarParams.rightMargin += windowInsets[2];
                        toolbar.setLayoutParams(toolbarParams);

                        mRecyclerView.setPadding(mRecyclerView.getPaddingStart() + windowInsets[0],
                                                 mRecyclerView.getPaddingTop() + windowInsets[1],
                                                 mRecyclerView.getPaddingEnd() + windowInsets[2],
                                                 mRecyclerView.getPaddingBottom() + windowInsets[3]);

                        //fab.setTranslationX(-windowInsets[2]);
                        //fab.setTranslationY(-windowInsets[3]);
                    }
                });
        }
        
        //mVideoList = new ArrayList<>();
        checkPermission();
        setSystemUiFlags();
    }

    //systemUiFlags need to be reset to achieve transparent status- and NavigationBar
    void setSystemUiFlags() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
            | View.SYSTEM_UI_FLAG_IMMERSIVE);
    }
    
    private boolean scrollToTheTop() {
        return mRecyclerView.canScrollVertically(-1);
    }
    
    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        //outState.putParcelable(ALBUM, album);
        if (mRecyclerView != null) {
            outState.putParcelable(RECYCLER_VIEW_SCROLL_STATE, mRecyclerView.getLayoutManager().onSaveInstanceState());
            //mAdapter.saveInstanceState(outState);
        }
    }
    
    private void checkPermission() {
        if ((ContextCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(getApplicationContext(),
                Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
            if ((ActivityCompat.shouldShowRequestPermissionRationale(VideoActivity.this,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE)) && (ActivityCompat.shouldShowRequestPermissionRationale(VideoActivity.this,
                    Manifest.permission.READ_EXTERNAL_STORAGE))) {

            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    ActivityCompat.requestPermissions(VideoActivity.this,
                            new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE},
                            REQUEST_PERMISSIONS);
                }
            }
        } else {
            // all permission granted
            getAllVideoFromGallery();

        }
    }
    
    public void getAllVideoFromGallery() {
        VideoTask video = new VideoTask(VideoActivity.this);
        video.execute();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case REQUEST_PERMISSIONS: {
                for (int i = 0; i < grantResults.length; i++) {
                    if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                        getAllVideoFromGallery();
                    } else {
                        Toast.makeText(VideoActivity.this, "The app was not allowed to read or write to your storage. Hence, it cannot function properly. Please consider granting it this permission", Toast.LENGTH_LONG).show();
                    }
                }
            }
        }
    }
}

