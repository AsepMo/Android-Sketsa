package com.github.exoplayer.adapters;

import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import java.util.List;

import com.bumptech.glide.Glide;

import com.github.exoplayer.R;
import com.github.exoplayer.VideoPlayerActivity;
import com.github.exoplayer.models.VideoModel;
import com.github.exoplayer.widget.ParallaxImageView;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.VideoViewHolder> {

    private List<VideoModel> videoList;

    public VideoAdapter(List<VideoModel> videoList) {
        this.videoList = videoList;
    }

    public class VideoViewHolder extends RecyclerView.ViewHolder {
        public ParallaxImageView imageViewThumbnail;

        VideoViewHolder(View view) {
            super(view);
            imageViewThumbnail = (ParallaxImageView)view.findViewById(R.id.imageViewThumbnail);

        }
    }


    @Override
    public VideoViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.video_list_row, parent, false);

        return new VideoViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final VideoViewHolder holder, int position) {
        final VideoModel mVideo = videoList.get(position);
        Glide.with(holder.itemView.getContext()).load(mVideo.getVideoThumb()).placeholder(R.drawable.video_placeholder).into(holder.imageViewThumbnail);
        holder.imageViewThumbnail.setParallaxTranslation();
        holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                   Intent mPlayerIntent = VideoPlayerActivity.getStartIntent(holder.itemView.getContext(), mVideo.getFilePath());
                   holder.itemView.getContext().startActivity(mPlayerIntent);
                }
            });

    }

    @Override
    public int getItemCount() {
        return videoList.size();
    }
}


