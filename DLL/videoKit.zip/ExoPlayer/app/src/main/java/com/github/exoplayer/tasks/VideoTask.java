package com.github.exoplayer.tasks;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.Context;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.media.MediaScannerConnection;
import android.provider.MediaStore;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;
import java.lang.ref.WeakReference;

import com.github.exoplayer.models.VideoModel;
import com.github.exoplayer.VideoActivity;
import com.github.exoplayer.adapters.VideoAdapter;

public class VideoTask extends AsyncTask<String, String, List<VideoModel>> {

    private ProgressDialog mDialog;
    private Uri uri;
    private Cursor mCursor;
    private int COLUMN_INDEX_DATA, COLUMN_INDEX_NAME, COLUMN_ID, COLUMN_THUMB, COLUMN_DURATION;
    private String absolutePathOfFile = null; 
    private String[] projection = {MediaStore.MediaColumns.DATA, MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media._ID, MediaStore.Video.Thumbnails.DATA, MediaStore.Video.Media.DURATION};
    private final WeakReference<Activity> activity;
    private boolean success = false;


    public VideoTask(Activity context) {
        this.activity = new WeakReference<>(context); 
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        final Activity activity = this.activity.get();

        if (activity != null) {
            this.mDialog = new ProgressDialog(activity);
            this.mDialog.setMessage("Please wait..");
            this.mDialog.setCancelable(true);
            /*this.mDialog.setOnCancelListener(new DialogInterface.OnCancelListener() {
             @Override
             public void onCancel(DialogInterface dialog) {
             cancel(false);
             }
             });*/
            if (!activity.isFinishing()) {
                this.mDialog.show();
            }
        }
    }

    @Override
    protected void onCancelled(List<VideoModel> result) {
        super.onCancelled(result);
        this.finish(result);
    }

    @Override
    protected void onCancelled() {
        super.onCancelled();
    }

    @Override
    protected void onProgressUpdate(String[] values) {
        super.onProgressUpdate(values);
    }

    @Override
    protected List<VideoModel> doInBackground(String[] video) {

        List<VideoModel> mVideoList = new ArrayList<VideoModel>();
        final Activity mContext = this.activity.get();

        try {
            uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

            final String orderBy = MediaStore.Images.Media.DATE_TAKEN;
            mCursor = mContext.getContentResolver().query(uri, projection, null, null, orderBy + " DESC");
            COLUMN_INDEX_DATA = mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
            COLUMN_INDEX_NAME = mCursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME);
            COLUMN_ID = mCursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
            COLUMN_THUMB = mCursor.getColumnIndexOrThrow(MediaStore.Video.Thumbnails.DATA);
            COLUMN_DURATION = mCursor.getColumnIndexOrThrow(MediaStore.Video.Media.DURATION);

            while (mCursor.moveToNext()) {
                absolutePathOfFile = mCursor.getString(COLUMN_INDEX_DATA);
                Log.e("Column", absolutePathOfFile);
                Log.e("Folder", mCursor.getString(COLUMN_INDEX_NAME));
                Log.e("column_id", mCursor.getString(COLUMN_ID));
                Log.e("thum", mCursor.getString(COLUMN_THUMB));
                VideoModel mVideo = new VideoModel();
                mVideo.setSelected(false);
                mVideo.setFilePath(absolutePathOfFile);
                mVideo.setVideoThumb(mCursor.getString(COLUMN_THUMB));
                mVideo.setVideoDuration(mCursor.getString(COLUMN_DURATION));
                mVideoList.add(mVideo);
                success = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            //mVideoList.add();
            success = false;
        }
        return mVideoList;
    }

    @Override
    protected void onPostExecute(List<VideoModel> result) {
        super.onPostExecute(result);
        this.finish(result);
    }

    private void finish(final List<VideoModel> video) {
        final Activity activity = this.activity.get();

        if (this.mDialog != null) {
            this.mDialog.dismiss();
        }
        if (video.size() < 1) {
            Toast.makeText(activity, "Video Is Empty", Toast.LENGTH_LONG).show();
        } else {
            
            VideoActivity.mAdapter = new VideoAdapter(video);
            VideoActivity.mRecyclerView.setAdapter(VideoActivity.mAdapter);
        }

        if (success) {
            Toast.makeText(activity, "Video Is Ready..", Toast.LENGTH_LONG).show();
        }
        if (activity != null && !video.isEmpty()) {
            //Toast.makeText(activity, "", Toast.LENGTH_SHORT).show();
            if (!activity.isFinishing()) {
                //mDialog.show();
            }
        }
    }

}
