package com.video.application.models;

import org.apache.commons.io.FileUtils;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;

public class VideoInfo {
    
    public String videoTitle = "";
    public String videoSize = "";
    public String videoThumb = "";
    public boolean hasVideo;
    
    public String getVideoTitle() {
        return videoTitle;
    }
    
    public String getVideoSize() {
        return videoSize;
    }

    public String getThumbnail() {
        return videoThumb;
    }
    
    public boolean hasVideo() {
        return hasVideo;
    }
}
