package com.video.application.tasks;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import uk.co.halfninja.videokit.Videokit;

import com.video.application.utils.Prefs;
import com.video.application.utils.ConvertUtils;
import com.video.application.utils.FolderMe;
import com.video.application.utils.VideoUtils;
import com.video.application.tasks.ConvertTask;
import com.video.application.ConvertService;
import com.video.application.ConvertProgressActivity;

public class ConvertTask extends AsyncTask<Void, Integer, String> {

    public static String TAG = ConvertTask.class.getSimpleName();

    private String video;
    private String videoPath;
    private Context mActivity;

    public ConvertTask(Context c, String tips) {
        video = tips;
        mActivity = c;
    }

    @Override
    protected void onPreExecute() {

    }

    @Override
    protected void onProgressUpdate(Integer... values) {
        //bar.setProgress(values[0]);
        //updateFrame();

        Log.d(TAG, "Gif save progress: " + values[0]);
    }

    @Override
    protected String doInBackground(Void... params) {
        videoPath = getVideoFilePath();
        File outFile = new File(videoPath);
        android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
        File folder = new File(Prefs.DEFAULT_WORK_FOLDER);
        folder.mkdirs();

        Videokit vk = new Videokit();
        //boolean success = false;
        Log.i(Prefs.TAG, "RemoteService: FFMPEG start.");

        try {
            Log.e(Prefs.TAG, "FFMPEG running");
            //String FN = video;
            String[] cmd = new String[] { "ffmpeg", "-i", video, outFile.getAbsolutePath()};
            ConvertUtils.deleteFile(Prefs.VK_LOG);
            ConvertUtils.deleteFile(Prefs.VIDEOKIT_LOG_FILE_PATH);
            ConvertUtils.deleteFile(videoPath);
            vk.run(cmd); 
            
            vk.fexit();

            //success = true;
            Log.e(Prefs.TAG, "FFMPEG finished");

            return outFile.getAbsolutePath();
        } catch (Exception e) {
            vk.fexit();
            Log.e(Prefs.TAG, "FFMPEG finished with errors..");
            return e.getMessage();
        }
    }
    @Override
    protected void onPostExecute(String result) {

        //Toast.makeText(mActivity, result, Toast.LENGTH_LONG).show();
        new ConvertService().sendBroadcast(result.toString());
        Log.i(Prefs.TAG, "RemoteService: FFMPEG finished.");

    }

    public File getAndroidMoviesFolder() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
    }

    public String getVideoFilePath() {
        return getAndroidMoviesFolder().getAbsolutePath() + "/Recorder/" + new SimpleDateFormat("yyyyMM_dd-HHmmss").format(new Date()) + "_convert.mp3";
    }


}

