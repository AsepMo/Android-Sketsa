package com.video.application.fragments;

import android.app.DialogFragment;
import android.support.v4.app.Fragment;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.Toolbar;
import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.Context;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.media.MediaScannerConnection;
import android.provider.MediaStore;
import android.graphics.Color;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import static android.provider.MediaStore.Images.Thumbnails.MICRO_KIND;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.google.android.youtube.player.YouTubeIntents;

import com.video.application.R;
import com.video.application.models.VideoInfo;
import com.video.application.utils.FolderMe;
import com.video.application.utils.VideoUtils;
import com.video.engine.graphics.Thumbnail;
import com.video.application.TrimmerActivity;
import com.video.application.ConvertActivity;
import com.video.application.ComposeActivity;
import com.video.application.VideoPlayerActivity;
import com.video.engine.graphics.encoder.Mp4toGIFConverter;
import com.video.engine.app.dialog.RenameDialog;
import com.video.application.VideoRecordActivity;

@SuppressWarnings("unused")
public class MediaStroreFragment extends Fragment {

    public static String TAG = MediaStroreFragment.class.getSimpleName();
	public static final String EXTRA_URL = "playlist";
    private LinearLayout welcomeLayout;
    private ListView listView;
    private String playlistId;

    public static MediaStroreFragment createFor(String playlistId) {
        MediaStroreFragment fragment = new MediaStroreFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_URL, playlistId);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // TODO: Implement this method
        // setHasOptionsMenu(true);
        return inflater.inflate(R.layout.fragment_video_history_record, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        // TODO: Implement this method
        super.onViewCreated(view, savedInstanceState);

        listView = (ListView)view.findViewById(R.id.history_list);
        View header = getLayoutInflater().inflate(R.layout.history_header_view, listView, false);
        listView.addHeaderView(header, null, false);

        welcomeLayout = (LinearLayout)view.findViewById(R.id.welcome_layout);
        playlistId = getArguments().getString(EXTRA_URL);


        HistoryLoader historyLoader = new HistoryLoader(getActivity(), listView, new String[]{playlistId});
        historyLoader.execute();
    }

    /*@Override
     public void onCreateOptionsMenu(Menu menu, MenuInflater inflater)
     {
     // TODO: Implement this method
     menu.add("Explore")
     .setIcon(R.drawable.icon_archive_explore)
     .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
     @Override
     public boolean onMenuItemClick(MenuItem item)
     {
     FolderMeActivity.start(getActivity());
     return true;
     }
     }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
     super.onCreateOptionsMenu(menu, inflater);
     }*/


    private void cleanOldSources() {
        File dir = new File(FolderMe.ZFOLDER_YOUTUBE);
        if (dir.exists()) {
            File[] files = dir.listFiles();
            for (File file : files) {
                if (!file.getName().equalsIgnoreCase("Download")) {
                    try {
                        FileUtils.cleanDirectory(file);
                        file.delete();
                    } catch (Exception e) {
                        Log.d("", e.getMessage());
                    }
                }
            }
        } else {
            dir.mkdirs();
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        rerunHistoryLoader();
    }

    private void rerunHistoryLoader() {
        HistoryLoader historyLoaderTwo = new HistoryLoader(getActivity(), listView, new String[]{playlistId});
        historyLoaderTwo.execute();
    }

    private static class ViewHolder {
        TextView videoTitle;
        TextView videoSize;
        ImageView thumbnail;
        int position;
    }

    private class HistoryLoader extends AsyncTask<String, String, List<VideoInfo>> {

        private ListView listView;
        private List<VideoInfo> historyItems;
        private String[] extensions;
        private Context mContext;

        public HistoryLoader(Context context, ListView listView, String[] extensions) {
            this.mContext = context;
            this.listView = listView;
            this.extensions = extensions;
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(String... text) {

        }

        @Override
        protected List<VideoInfo> doInBackground(String... params) {

            historyItems = new ArrayList<>();
            File MP4 = new File(FolderMe.ZFOLDER_VIDEO_SCREEN_RECORDER);
            if (MP4.exists()) {
                listOfFile(MP4);
            }


            return historyItems;
        }

        private void listOfFile(File dir) {
            File[] list = dir.listFiles();

            for (File file : list) {
                if (file.isDirectory()) {
                    if (!new File(file, ".nomedia").exists() && !file.getName().startsWith(".")) {
                        //Log.w("LOG", "IS DIR " + file);
                        listOfFile(file);
                    }
                } else {
                    String path = file.getAbsolutePath();
                    //String[] extensions = new String[]{".mp4"};
                    for (String ext : extensions) {
                        if (path.endsWith(ext)) {
                            VideoInfo videoInfo = new VideoInfo();

                            videoInfo.videoTitle = path;
                            String[] split = path.split("/");
                            videoInfo.videoTitle = split[split.length - 1];
                            videoInfo.videoThumb = path;
                            videoInfo.videoSize = VideoUtils.formatVideoSize(file);
                            historyItems.add(videoInfo);
                            //Log.i("LOG", "ADD " + videoInfo.path + " " + videoInfo.name);
                        }
                    }
                }
            }
            //Log.d("LOG", historyItems.size() + " DONE");
        }

        @Override
        protected void onPostExecute(final List<VideoInfo> AllVideo) {
            if (AllVideo.size() < 1) {
                listView.setVisibility(View.GONE);
                welcomeLayout.setVisibility(View.VISIBLE);
            } else {
                welcomeLayout.setVisibility(View.INVISIBLE);

                final ArrayAdapter<VideoInfo> videoAdapter = new ArrayAdapter<VideoInfo>(getActivity(), R.layout.history_list_item, AllVideo) {
                    @SuppressLint("InflateParams")
                    @Override
                    public View getView(final int position, View convertView, ViewGroup parent) {
                        if (convertView == null) {
                            convertView = getLayoutInflater().inflate(R.layout.history_list_item, null);
                        }

                        final VideoInfo pkg = getItem(position);
                        ViewHolder holder = new ViewHolder();

                        holder.videoTitle = (TextView) convertView.findViewById(R.id.history_item_label);
                        holder.videoSize = (TextView) convertView.findViewById(R.id.history_item_package);
                        holder.thumbnail = (ImageView) convertView.findViewById(R.id.history_item_icon);

                        convertView.setTag(holder);

                        holder.videoTitle.setText(pkg.getVideoTitle());
                        holder.videoSize.setText(pkg.getVideoSize());
                        //addFileToMediaStore(pkg.videoThumb);
                        Thumbnail.setThumbnail(pkg.videoThumb, MICRO_KIND, holder.thumbnail, false);
                        convertView.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    final VideoInfo video = AllVideo.get(position);
                                    new AlertDialog.Builder(getActivity())
                                        .setItems(new CharSequence[]{"Rename","Play", "Delete",  "Trimmer", "Compose", "Convert To Mp3", "Convert To Gif", "Upload"}, new DialogInterface.OnClickListener(){
                                            @Override
                                            public void onClick(DialogInterface  dialog, int which) {
                                                File file = new File(video.videoThumb);
                                                switch (which) {
                                                    case 0:                                               
                                                        VideoRecordActivity activity = (VideoRecordActivity)getActivity();
                                                        renamed(activity, file);
                                                        break;
                                                    case 1:
                                                        VideoPlayerActivity.startTrimActivity(getActivity(), file.getAbsolutePath());
                                                        break;   
                                                    case 2:                                                    
                                                        removed(file.getAbsolutePath());
                                                        break;
                                                    case 3:
                                                        TrimmerActivity.startTrimActivity(getActivity(), file.getAbsolutePath());
                                                        break;  
                                                    case 4:
                                                        ComposeActivity.startTrimActivity(getActivity(), file.getAbsolutePath());
                                                        break;  
                                                    case 5:
                                                        ConvertActivity.startTrimActivity(getActivity(), file.getAbsolutePath());
                                                        break;       
                                                    case 6:
                                                        Mp4toGIFConverter gif = new Mp4toGIFConverter(getActivity());
                                                        gif.setVideoUri(Uri.fromFile(file.getAbsoluteFile()));
                                                        gif.convertToGif();
                                                        break;        
                                                    case 7:
                                                        Intent intent = YouTubeIntents.createUploadIntent(getActivity(), Uri.parse(video.videoThumb));
                                                        startActivity(intent);
                                                        break;                               
                                                }
                                                dialog.dismiss();
                                            }
                                        })
                                        .show();
                                }
                            });
                        return convertView;
                    }
                };
                listView.setAdapter(videoAdapter);
                listView.setVisibility(View.VISIBLE);
            }
        }

    }

    public void renamed(VideoRecordActivity activity, File video) {
        DialogFragment rename = RenameDialog.instantiate(video.getAbsolutePath());
        rename.show(activity.getFragmentManager(), "dialog");
    }

    private void removed(String video) {
        String path =  video;
        String result;
        File file = new File(path);
        try {
            removeFile(file);
            result = "removed: " +  video;
        } catch (Exception e) {
            result = e.getMessage();
        }

        rerunHistoryLoader();
        Toast.makeText(getActivity(), result, Toast.LENGTH_SHORT).show();
    }

    private void removeFile(File file) throws IOException {
        if (file != null && file.exists()) {
            if (file.isDirectory()) {
                for (File sub : file.listFiles()) {
                    removeFile(sub);
                }
            }
            file.delete();
        }
    }

    private void addFileToMediaStore(String filepath) {
        ContentValues thumbnailValues = new ContentValues();
        thumbnailValues.put(MediaStore.Video.Media.DATE_TAKEN, System.currentTimeMillis());
        thumbnailValues.put(MediaStore.MediaColumns.DATA, filepath);
        ContentResolver contentResolver = getActivity().getContentResolver();
        contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, thumbnailValues);
    }
}

