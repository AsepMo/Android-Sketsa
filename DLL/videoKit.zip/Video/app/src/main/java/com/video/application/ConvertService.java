package com.video.application;

import android.app.IntentService;
import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Environment;
import android.util.Log;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import uk.co.halfninja.videokit.Videokit;

import com.video.application.utils.Prefs;
import com.video.application.utils.ConvertUtils;
import com.video.application.utils.FolderMe;
import com.video.application.utils.VideoUtils;
import com.video.application.tasks.ConvertTask;

public class ConvertService extends IntentService {
    public static final String ACTION_CONVERT = "ACTION_CONVERT";
    public static final String EXTRA_CONVERT = "EXTRA_CONVERT";
    public static final String ACTION_UPDATE = "com.video.application.background.ACTION_UPDATE";
    public static final String ACTION_PROGRESS = "com.video.application.background.ACTION_PROGRESS";

    public static final String EXTRA_UPDATE_TEXT = "UPDATE_TEXT";
    public static final String EXTRA_PROGRESS = "PROGRESS";
    public static final String EXTRA_MAX = "MAX";

    private boolean isPlaying = false;
    
    public ConvertService() {
        super("ConvertService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent.getAction().equals(ACTION_CONVERT)) {
            String video = intent.getStringExtra(EXTRA_CONVERT);

            play(video);     
		}
    }

    @Override
    public void onDestroy() {
        stop();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return(null);
    }

    private void play(final String video) {
        Log.i(Prefs.TAG, "Converter Run called.");
        Intent progressIntent = new Intent(ConvertService.ACTION_PROGRESS);
        progressIntent.putExtra(ConvertService.EXTRA_PROGRESS, ConvertUtils.readLastSizeInKBFromFFmpegLogFile());
        progressIntent.putExtra(ConvertService.EXTRA_MAX, ConvertUtils.readLastTimeFromFFmpegLogFileUsingRandomAccess());
        sendBroadcast(progressIntent);
        
       ConvertTask convert = new ConvertTask(getApplicationContext(), video);
       convert.execute();
    }

    public void sendBroadcast(String result)
    {
        Intent updateIntent = new Intent(ConvertService.ACTION_UPDATE);
        updateIntent.putExtra(ConvertService.EXTRA_UPDATE_TEXT, result);
        sendBroadcast(updateIntent);
    }
    
    public File getAndroidMoviesFolder() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
    }

    public String getVideoFilePath() {
        return getAndroidMoviesFolder().getAbsolutePath() + "/Recorder/" + new SimpleDateFormat("yyyyMM_dd-HHmmss").format(new Date()) + "_convert.mp3";
    }

    private void stop() {
        if (isPlaying) {
            Log.w(getClass().getName(), "Got to stop()!");
            Videokit vk = new Videokit();
            vk.fexit();
            isPlaying = false;
        }
    }
}

