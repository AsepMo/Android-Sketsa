package com.video.application;
 
import android.Manifest;
import android.app.Activity;
import android.support.v7.app.AppCompatActivity;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ListView;
import android.widget.VideoView;
import android.widget.MediaController;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;

import com.video.application.models.VideoModel;
import com.video.application.adapters.VideoRecyclerAdapter;
import com.video.application.utils.FolderMe;
import com.video.application.utils.VideoUtils;

public class MainActivity extends AppCompatActivity { 

    private static final int REQUEST_PERMISSIONS = 101;
    private ArrayList<VideoModel> mVideoList;
    private VideoRecyclerAdapter mVideoAdapter;
    private ListView mVideo;
    
    private VideoView myVideoView;
    private int position = 0;
    private MediaController mediaControls;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        
        //getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setTheme(R.style.AppTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mVideo = (ListView)findViewById(R.id.video_list);
        mVideoList = new ArrayList<VideoModel>();
        mVideoAdapter = new VideoRecyclerAdapter(this, mVideoList);
        View header = getLayoutInflater().inflate(R.layout.header_video_layout, mVideo, false);
        mVideo.addHeaderView(header, null, false);
     
        
        // Find your VideoView in your video_main.xml layout
        myVideoView = (VideoView) header.findViewById(R.id.video);
        try
        {
           // myVideoView.setMediaController(mediaControls);
            //myVideoView.setVideoURI(Uri.parse("https://cldup.com/smVYfhBfim.mp4"));
            myVideoView.setVideoPath(mVideoList.get(0).getVideoPath());
            
        }
        catch (Exception e)
        {
            Log.e("Error", e.getMessage());
            e.printStackTrace();
        }
        
        myVideoView.requestFocus();
        myVideoView.setOnPreparedListener(new OnPreparedListener() {
                // Close the progress bar and play the video
                public void onPrepared(MediaPlayer mp)
                {
                    //progressDialog.dismiss();

                    if (position == 0)
                    {
                        myVideoView.start();
                    }
                    else
                    {
                        myVideoView.pause();
                    }
                }
            });

        myVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
                @Override
                public void onCompletion(MediaPlayer mp)
                {

                }
            });
        checkPermission();
        
    }

    public void onPrepared(String videoPath)
    {
        try
        {
            myVideoView.setMediaController(mediaControls);
            //myVideoView.setVideoURI(Uri.parse("https://cldup.com/smVYfhBfim.mp4"));
            myVideoView.setVideoURI(Uri.parse(videoPath));
        }
        catch (Exception e)
        {
            Log.e("Error", e.getMessage());
            e.printStackTrace();
        }

        myVideoView.requestFocus();
        myVideoView.setOnPreparedListener(new OnPreparedListener() {
                // Close the progress bar and play the video
                public void onPrepared(MediaPlayer mp)
                {
                    //progressDialog.dismiss();

                    if (position == 0)
                    {
                        myVideoView.start();
                    }
                    else
                    {
                        myVideoView.pause();
                    }
                }
            });

        myVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
                @Override
                public void onCompletion(MediaPlayer mp)
                {

                }
            });
    }
    
    private void checkPermission() {
        if ((ContextCompat.checkSelfPermission(getApplicationContext(),
                                               Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) && (ContextCompat.checkSelfPermission(getApplicationContext(),
                                                                                                                                                                       Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)) {
            if ((ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                                                                     Manifest.permission.WRITE_EXTERNAL_STORAGE)) && (ActivityCompat.shouldShowRequestPermissionRationale(MainActivity.this,
                                                                                                                                                                          Manifest.permission.READ_EXTERNAL_STORAGE))) {

            } else {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                    ActivityCompat.requestPermissions(MainActivity.this,
                                                      new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE},
                                                      REQUEST_PERMISSIONS);
                }
            }
        } else {
            // all permission granted
            getAllVideoFromGallery();
            
            new FolderMe.Builder(this)
                .setDefaultDir(true)
                .setFolderApk(true)
                .setFolderImage(true)
                .setFolderAudio(true)
                .setFolderYoutube(true)
                .setFolderYoutube_Analytics(true)
                .setFolderYoutube_Download(true)
                .setFolderVideo(true)
                .setFolderVideoRecorder(true)
                .setFolderScriptMe(true)
                .setFolderEbook(true)
                .setExternalFileDir(this, "Youtube")
                .setInternalCacheDir(this)
                .build();
        }
    }

    public void getAllVideoFromGallery() {
        Uri uri;
        Cursor mCursor;
        int COLUMN_INDEX_DATA, COLUMN_INDEX_NAME, COLUMN_ID, COLUMN_THUMB;
        String absoluteNameOfFile = null;
        String absolutePathOfFile = null;
        uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {MediaStore.MediaColumns.DATA, MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media._ID, MediaStore.Video.Thumbnails.DATA};

        final String orderBy = MediaStore.Images.Media.DATE_TAKEN;
        mCursor = getApplicationContext().getContentResolver().query(uri, projection, null, null, orderBy + " DESC");
        COLUMN_INDEX_DATA = mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        COLUMN_INDEX_NAME = mCursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME);
        COLUMN_ID = mCursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
        COLUMN_THUMB = mCursor.getColumnIndexOrThrow(MediaStore.Video.Thumbnails.DATA);

        while (mCursor.moveToNext()) {
            absoluteNameOfFile = mCursor.getString(COLUMN_INDEX_NAME);        
            absolutePathOfFile = mCursor.getString(COLUMN_INDEX_DATA);
            File videoTitle = new File(absolutePathOfFile);
            Log.e("Column", absolutePathOfFile);
            Log.e("Folder", mCursor.getString(COLUMN_INDEX_NAME));
            Log.e("column_id", mCursor.getString(COLUMN_ID));
            Log.e("thum", mCursor.getString(COLUMN_THUMB));
            VideoModel mVideo = new VideoModel();
            mVideo.setSelected(false);
            mVideo.setVideoTitle(videoTitle.getName());
            mVideo.setVideoPath(absolutePathOfFile);
            mVideo.setVideoThumb(mCursor.getString(COLUMN_THUMB));
            mVideo.setVideoSize(VideoUtils.formatVideoSize(videoTitle));
            mVideo.setPathName(absoluteNameOfFile);
            mVideoList.add(mVideo);

        }

        mVideoAdapter = new VideoRecyclerAdapter(MainActivity.this, mVideoList);
        mVideo.setAdapter(mVideoAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Explore")
            .setIcon(android.R.drawable.ic_input_add)
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item)
                {

                         Intent videoIntent = new Intent(MainActivity.this, VideoRecordActivity.class);
                         //videoIntent.putExtra(VideoPlayerActivity.TAG_URL, video.getVideoPath());
                         startActivity(videoIntent);
                        
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        
        return super.onCreateOptionsMenu(menu);
    }

    
    
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case REQUEST_PERMISSIONS: {
                    for (int i = 0; i < grantResults.length; i++) {
                        if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                            getAllVideoFromGallery();
                        } else {
                            Toast.makeText(MainActivity.this, "The app was not allowed to read or write to your storage. Hence, it cannot function properly. Please consider granting it this permission", Toast.LENGTH_LONG).show();
                        }
                    }
                }
        }
    }
    
     @Override
    public void onSaveInstanceState(Bundle savedInstanceState)
    {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("Position", myVideoView.getCurrentPosition());
        myVideoView.pause();
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState)
    {
        super.onRestoreInstanceState(savedInstanceState);
        position = savedInstanceState.getInt("Position");
        myVideoView.seekTo(position);
    }
    
    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if(myVideoView.isPlaying()){
            myVideoView.stopPlayback();
            myVideoView.pause();
            finish();
        }

    }
    
}
