package com.video.application;

import android.support.v7.app.AppCompatActivity;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.AsyncTask;
import android.os.Environment;
import android.util.Log;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import uk.co.halfninja.videokit.Videokit;

import com.video.application.utils.Prefs;
import com.video.application.utils.ConvertUtils;
import com.video.application.utils.FolderMe;
import com.video.application.utils.VideoUtils;


public class ConvertProgressActivity extends AppCompatActivity {

    public static String vConvert = "convert";

    public static void start(Context c, String vFile) {
        Intent mConvert = new Intent(c, ConvertProgressActivity.class);
        mConvert.putExtra(vConvert, vFile);
        c.startActivity(mConvert);
    }

    private TextView vName;
    private TextView vStatus;
    private TextView vOutput;

    private String mVideo;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_convert_progress);


        vName = (TextView) findViewById(R.id.current_package_name);
        vName.setSingleLine(false);
        vName.setEllipsize(TextUtils.TruncateAt.END);
        vName.setLines(1);

        mVideo = getIntent().getStringExtra(vConvert);

        vName.setText(new File(mVideo).getName());

        boolean isRunning = VideoUtils.isServiceRunning(this);
        if(isRunning) {
            VideoUtils.killRecorderServices(this);
        }
        ConvertTask convert = new ConvertTask(this, mVideo);
        convert.execute();

        vStatus = (TextView) findViewById(R.id.current_status);
        vStatus.setText("Convert To Mp3");
        vStatus.setSingleLine(false);
        vStatus.setEllipsize(TextUtils.TruncateAt.END);
        vStatus.setLines(1);

        vOutput = (TextView) findViewById(R.id.current_line);
        vOutput.setText("Please wait..");
        
        File file = new File(FolderMe.ZFOLDER_AUDIO_Convert);
        if (file.exists())file.mkdirs();
        
        /* Gear Progress */
        final ImageView GearProgressLeft = (ImageView) findViewById(R.id.gear_progress_left);
        final ImageView GearProgressRight = (ImageView) findViewById(R.id.gear_progress_right);

        final RotateAnimation GearProgressLeftAnim = new RotateAnimation(0.0f, 360.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        GearProgressLeftAnim.setRepeatCount(Animation.INFINITE);
        GearProgressLeftAnim.setDuration((long) 2 * 1500);
        GearProgressLeftAnim.setInterpolator(new LinearInterpolator());

        final RotateAnimation GearProgressRightAnim = new RotateAnimation(360.0f, 0.0f, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        GearProgressRightAnim.setRepeatCount(Animation.INFINITE);
        GearProgressRightAnim.setDuration((long) 1500);
        GearProgressRightAnim.setInterpolator(new LinearInterpolator());

        GearProgressLeft.post(new Runnable() {
                @Override
                public void run() {
                    GearProgressLeft.setAnimation(GearProgressLeftAnim);
                }
            });
        GearProgressLeft.post(new Runnable() {
                @Override
                public void run() {
                    GearProgressRight.setAnimation(GearProgressRightAnim);
                }
            });

    }

    public class ConvertTask extends AsyncTask<Void, Integer, String> {

        public String TAG = ConvertTask.class.getSimpleName();

        private String video;
        private String videoPath;
        private Context mActivity;

        public ConvertTask(Context c, String tips) {
            video = tips;
            mActivity = c;
        }

        @Override
        protected void onPreExecute() {

        }

        @Override
        protected void onProgressUpdate(Integer... values) {
            //bar.setProgress(values[0]);
            //updateFrame();

            Log.d(TAG, "Gif save progress: " + values[0]);
        }

        @Override
        protected String doInBackground(Void... params) {
            videoPath = getVideoFilePath();
            File outFile = new File(videoPath);
            android.os.Process.setThreadPriority(android.os.Process.THREAD_PRIORITY_BACKGROUND);
            File folder = new File(Prefs.DEFAULT_WORK_FOLDER);
            folder.mkdirs();

            Videokit vk = new Videokit();
            //boolean success = false;
            Log.i(Prefs.TAG, "RemoteService: FFMPEG start.");

            try {
                Log.e(Prefs.TAG, "FFMPEG running");
                //String FN = video;
                String[] cmd = new String[] { "ffmpeg", "-i", video, outFile.getAbsolutePath()};
                ConvertUtils.deleteFile(Prefs.VK_LOG);
                ConvertUtils.deleteFile(Prefs.VIDEOKIT_LOG_FILE_PATH);
                ConvertUtils.deleteFile(videoPath);
                vk.run(cmd); 

                
                vk.fexit();

                //success = true;
                Log.e(Prefs.TAG, "FFMPEG finished");

                return outFile.getAbsolutePath();
            } catch (Exception e) {
                vk.fexit();
                Log.e(Prefs.TAG, "FFMPEG finished with errors..");
                return e.getMessage();
            }
        }
        @Override
        protected void onPostExecute(String result) {

            //Toast.makeText(mActivity, result, Toast.LENGTH_LONG).show();
            finish();
            Log.i(Prefs.TAG, "RemoteService: FFMPEG finished.");

        }

        public File getAndroidMoviesFolder() {
            return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
        }

        public String getVideoFilePath() {
            return getAndroidMoviesFolder().getAbsolutePath() + "/Recorder/" + new SimpleDateFormat("yyyyMM_dd-HHmmss").format(new Date()) + "_convert.mp3";
        }


    }
    
}

