package com.video.application.tasks;

import android.support.v4.provider.DocumentFile;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.media.MediaScannerConnection;
import android.provider.MediaStore;
import android.net.Uri;
import android.os.Build;
import android.os.AsyncTask;
import android.widget.Toast;

import com.video.application.R;

import java.lang.ref.WeakReference;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public final class RenameTask extends AsyncTask<String, Void, List<String>> {

    private final WeakReference<Activity> activity;

    private ProgressDialog dialog;
    private boolean succes = false;
    
    public RenameTask(final Activity activity) {
        this.activity = new WeakReference<>(activity);
    }

    @Override
    protected void onPreExecute() {
        final Activity activity = this.activity.get();

        if (activity != null) {
            this.dialog = new ProgressDialog(activity);
            this.dialog.setMessage(activity.getString(R.string.rename));
            this.dialog.setCancelable(true);
            this.dialog
                    .setOnCancelListener(new DialogInterface.OnCancelListener() {
                        @Override
                        public void onCancel(DialogInterface dialog) {
                            cancel(false);
                        }
                    });
            if (!activity.isFinishing()) {
                this.dialog.show();
            }
        }
    }

    @Override
    protected List<String> doInBackground(String... files) {
        final List<String> failed = new ArrayList<>();
        final Activity acti= this.activity.get();
        
        File file = new File(files[0]);
       // File videoFile = new File(files[1]);
        try {
            if (renameTarget(file.getAbsolutePath(), files[1])) {
                
                succes = true;
            } else {
                
            }
            
       /* if (videoFile.canRead()) {
            for (File video : videoFile.listFiles())
                addFileToMediaStore(acti, video.getPath());
        }*/
        } catch (Exception e) {
            failed.add(files[1]);
            succes = false;
        }
        return failed;
    }

    @Override
    protected void onPostExecute(final List<String> failed) {
        super.onPostExecute(failed);
        this.finish(failed);
    }

    @Override
    protected void onCancelled(final List<String> failed) {
        super.onCancelled(failed);
        this.finish(failed);
    }

    private void finish(final List<String> failed) {
        if (this.dialog != null) {
            this.dialog.dismiss();
        }

        final Activity activity = this.activity.get();

        if (succes){
            Toast.makeText(activity, activity.getString(R.string.filewasrenamed), Toast.LENGTH_LONG).show();
                
        }
        if (activity != null && !failed.isEmpty()) {
            Toast.makeText(activity, activity.getString(R.string.cantopenfile),
                    Toast.LENGTH_SHORT).show();
            if (!activity.isFinishing()) {
                dialog.show();
            }
        }
    }
    
    // filePath = currentDir + "/" + item
    // newName = new name
    public static boolean renameTarget(String filePath, String newName) {
        File src = new File(filePath);

        String temp = filePath.substring(0, filePath.lastIndexOf("/"));
        File dest = new File(temp + "/" + newName);

        if (src.renameTo(dest)) {
            return true;
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                DocumentFile document = DocumentFile.fromFile(src);

                if (document.renameTo(dest.getAbsolutePath())) {
                    return true;
                }
            }
        }
        return false;
    }
    
    private void addFileToMediaStore(Activity c, String filepath){
        ContentValues thumbnailValues = new ContentValues();
        thumbnailValues.put(MediaStore.Video.Media.DATE_TAKEN, System.currentTimeMillis());
        thumbnailValues.put(MediaStore.MediaColumns.DATA, filepath);
        ContentResolver contentResolver = c.getContentResolver();
        contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, thumbnailValues);
    }
}
