package com.video.application;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.annotation.SuppressLint;
import android.support.annotation.NonNull;
import android.support.v4.content.ContextCompat;
import android.support.v4.app.ActivityCompat;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.database.Cursor;
import android.net.Uri;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.AdapterView;
import android.widget.Gallery;
import android.widget.MediaController;
import android.widget.VideoView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.lang.ref.WeakReference;

import com.video.application.models.VideoModel;
import com.video.application.adapters.VideoAdapter;
import com.video.application.utils.VideoUtils;
import com.video.engine.app.dialog.MessageDialogFragment;
import com.video.engine.app.service.ScreenRecorderService;
import com.video.engine.app.utils.BuildCheck;
import com.video.engine.app.utils.PermissionCheck;

public class GalleryActivity extends Activity implements MessageDialogFragment.MessageDialogListener {

    private static final boolean DEBUG = false;
    private static final String TAG = GalleryActivity.class.getSimpleName();

    private static final int REQUEST_CODE_SCREEN_CAPTURE = 1;
    private static final int REQUEST_PERMISSIONS = 101;
    
    private MyBroadcastReceiver mReceiver;
    private ArrayList<VideoModel> mVideoList;
    private VideoAdapter mVideoAdapter;
    private Gallery mVideo;
    private VideoView myVideoView;
    private int position = 0;
    private int post;
    private MediaController mediaControls;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setTheme(R.style.AppTheme);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);
        mVideo = (Gallery)findViewById(R.id.gallery);
        mVideo.setSpacing(1);
        mVideo.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                    // show the selected Image
                    post = position;
                    try {
                        //myVideoView.setMediaController(mediaControls);
                        //myVideoView.setVideoURI(Uri.parse("https://cldup.com/smVYfhBfim.mp4"));
                        myVideoView.setVideoURI(Uri.parse(mVideoList.get(position).getVideoPath()));
                        if (!myVideoView.isPlaying()) {
                            myVideoView.start();

                        }
                    } catch (Exception e) {
                        Log.e("Error", e.getMessage());
                        e.printStackTrace();
                    }
                }
            });
        mVideoList = new ArrayList<VideoModel>();
        mVideoAdapter = new VideoAdapter(this, mVideoList);
        getAllVideoFromGallery();
        // Find your VideoView in your video_main.xml layout
        myVideoView = (VideoView) findViewById(R.id.video);

        findViewById(R.id.layout_video).setOnClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    Intent videoIntent = new Intent(GalleryActivity.this, VideoPlayerActivity.class);
                    videoIntent.putExtra(VideoPlayerActivity.TAG_URL, mVideoList.get(post).getVideoPath());
                    startActivity(videoIntent);
                    if (myVideoView.isPlaying()) {
                        myVideoView.stopPlayback();
                        myVideoView.pause();

                    }
                }
            });
        /*if (mediaControls == null)
         {
         mediaControls = new MediaController(GalleryActivity.this);
         }*/

        try {
            //myVideoView.setMediaController(mediaControls);
            //myVideoView.setVideoURI(Uri.parse("https://cldup.com/smVYfhBfim.mp4"));
            myVideoView.setVideoURI(Uri.parse(mVideoList.get(0).getVideoPath()));
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
            e.printStackTrace();
        }

        myVideoView.requestFocus();
        myVideoView.setOnPreparedListener(new OnPreparedListener() {
                // Close the progress bar and play the video
                public void onPrepared(MediaPlayer mp) {
                    //progressDialog.dismiss();
                    myVideoView.seekTo(position);
                    if (position == 0) {
                        myVideoView.start();
                        //VideoUtils.killRecorderServices(GalleryActivity.this);
                        if (checkPermissionWriteExternalStorage() && checkPermissionAudio()) {

                            final MediaProjectionManager manager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                            final Intent permissionIntent = manager.createScreenCaptureIntent();
                            startActivityForResult(permissionIntent, REQUEST_CODE_SCREEN_CAPTURE);
                        }

                    } else {
                        myVideoView.pause();
                        if (checkPermissionWriteExternalStorage() && checkPermissionAudio()) {

                            final Intent intent = new Intent(GalleryActivity.this, ScreenRecorderService.class);
                            intent.setAction(ScreenRecorderService.ACTION_STOP);
                            startService(intent);
                        }
                    }
                }
            });

        myVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
                @Override
                public void onCompletion(MediaPlayer mp) {

                }
            });

        if (mReceiver == null) {
            mReceiver = new MyBroadcastReceiver(this);
		}
       
    }

    
    /**
     * Method to check if the {@link RecorderService} is running
     * @param serviceClass Collection containing the {@link RecorderService} class
     * @return boolean value representing if the {@link RecorderService} is running
     * @exception NullPointerException May throw NullPointerException
     */
    private boolean isServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    public void getAllVideoFromGallery() {
        Uri uri;
        Cursor mCursor;
        int COLUMN_INDEX_DATA, COLUMN_INDEX_NAME, COLUMN_ID, COLUMN_THUMB;
        String absoluteNameOfFile = null;
        String absolutePathOfFile = null;
        uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {MediaStore.MediaColumns.DATA, MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media._ID, MediaStore.Video.Thumbnails.DATA};

        final String orderBy = MediaStore.Images.Media.DATE_TAKEN;
        mCursor = getApplicationContext().getContentResolver().query(uri, projection, null, null, orderBy + " DESC");
        COLUMN_INDEX_DATA = mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        COLUMN_INDEX_NAME = mCursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME);
        COLUMN_ID = mCursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
        COLUMN_THUMB = mCursor.getColumnIndexOrThrow(MediaStore.Video.Thumbnails.DATA);

        while (mCursor.moveToNext()) {
            absoluteNameOfFile = mCursor.getString(COLUMN_INDEX_NAME);        
            absolutePathOfFile = mCursor.getString(COLUMN_INDEX_DATA);
            File videoTitle = new File(absolutePathOfFile);
            Log.e("Column", absolutePathOfFile);
            Log.e("Folder", mCursor.getString(COLUMN_INDEX_NAME));
            Log.e("column_id", mCursor.getString(COLUMN_ID));
            Log.e("thum", mCursor.getString(COLUMN_THUMB));
            VideoModel mVideo = new VideoModel();
            mVideo.setSelected(false);
            mVideo.setVideoTitle(videoTitle.getName());
            mVideo.setVideoPath(absolutePathOfFile);
            mVideo.setVideoThumb(mCursor.getString(COLUMN_THUMB));
            mVideo.setVideoSize(VideoUtils.formatVideoSize(videoTitle));
            mVideoList.add(mVideo);

        }

        mVideoAdapter = new VideoAdapter(GalleryActivity.this, mVideoList);
        mVideo.setAdapter(mVideoAdapter);
    }



    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("Position", myVideoView.getCurrentPosition());
        myVideoView.pause();
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        position = savedInstanceState.getInt("Position");
        myVideoView.seekTo(position);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (myVideoView.isPlaying()) {
            myVideoView.stopPlayback();
            myVideoView.pause();
            finish();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (DEBUG) Log.v(TAG, "onResume:");
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ScreenRecorderService.ACTION_QUERY_STATUS_RESULT);
        registerReceiver(mReceiver, intentFilter);
        queryRecordingStatus();
    }

    @Override
    protected void onPause() {
        if (DEBUG) Log.v(TAG, "onPause:");
        unregisterReceiver(mReceiver);
        
        if (checkPermissionWriteExternalStorage() && checkPermissionAudio()) {

            final Intent intent = new Intent(GalleryActivity.this, ScreenRecorderService.class);
            intent.setAction(ScreenRecorderService.ACTION_STOP);
            startService(intent);
        }
        super.onPause();
    }

    @Override
    protected void onActivityResult(final int requestCode, final int resultCode, final Intent data) {
        if (DEBUG) Log.v(TAG, "onActivityResult:resultCode=" + resultCode + ",data=" + data);
        super.onActivityResult(requestCode, resultCode, data);
        if (REQUEST_CODE_SCREEN_CAPTURE == requestCode) {
            if (resultCode != Activity.RESULT_OK) {
                // when no permission
                Toast.makeText(this, "permission denied", Toast.LENGTH_LONG).show();
                return;
            }
            startScreenRecorder(resultCode, data);
        }
    }

    /*private final OnCheckedChangeListener mOnCheckedChangeListener = new OnCheckedChangeListener() {
        @Override
        public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked) {
            switch (buttonView.getId()) {
                case R.id.record_button:
                    if (checkPermissionWriteExternalStorage() && checkPermissionAudio()) {
                        if (isChecked) {
                            final MediaProjectionManager manager = (MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
                            final Intent permissionIntent = manager.createScreenCaptureIntent();
                            startActivityForResult(permissionIntent, REQUEST_CODE_SCREEN_CAPTURE);
                        } else {
                            final Intent intent = new Intent(GalleryActivity.this, ScreenRecorderService.class);
                            intent.setAction(ScreenRecorderService.ACTION_STOP);
                            startService(intent);
                        }
                    } else {
                        mRecordButton.setOnCheckedChangeListener(null);
                        try {
                            mRecordButton.setChecked(false);
                        } finally {
                            mRecordButton.setOnCheckedChangeListener(mOnCheckedChangeListener);
                        }
                    }
                    break;
                case R.id.pause_button:
                    if (isChecked) {
                        final Intent intent = new Intent(MainActivity.this, ScreenRecorderService.class);
                        intent.setAction(ScreenRecorderService.ACTION_PAUSE);
                        startService(intent);
                    } else {
                        final Intent intent = new Intent(MainActivity.this, ScreenRecorderService.class);
                        intent.setAction(ScreenRecorderService.ACTION_RESUME);
                        startService(intent);
                    }
                    break;
            }
        }
    };*/

    private void queryRecordingStatus() {
        if (DEBUG) Log.v(TAG, "queryRecording:");
        final Intent intent = new Intent(this, ScreenRecorderService.class);
        intent.setAction(ScreenRecorderService.ACTION_QUERY_STATUS);
        startService(intent);
    }

    private void startScreenRecorder(final int resultCode, final Intent data) {
        final Intent intent = new Intent(this, ScreenRecorderService.class);
        intent.setAction(ScreenRecorderService.ACTION_START);
        intent.putExtra(ScreenRecorderService.EXTRA_RESULT_CODE, resultCode);
        intent.putExtras(data);
        startService(intent);
    }

    private static final class MyBroadcastReceiver extends BroadcastReceiver {
        private final WeakReference<GalleryActivity> mWeakParent;
        public MyBroadcastReceiver(final GalleryActivity parent) {
            mWeakParent = new WeakReference<GalleryActivity>(parent);
        }

        @Override
        public void onReceive(final Context context, final Intent intent) {
            if (DEBUG) Log.v(TAG, "onReceive:" + intent);
            final String action = intent.getAction();
            if (ScreenRecorderService.ACTION_QUERY_STATUS_RESULT.equals(action)) {
                final boolean isRecording = intent.getBooleanExtra(ScreenRecorderService.EXTRA_QUERY_RESULT_RECORDING, false);
                final boolean isPausing = intent.getBooleanExtra(ScreenRecorderService.EXTRA_QUERY_RESULT_PAUSING, false);
                final GalleryActivity parent = mWeakParent.get();
                /*if (parent != null) {
                 parent.updateRecording(isRecording, isPausing);
                 }*/
            }
        }
    }

//================================================================================
// methods related to new permission model on Android 6 and later
//================================================================================
    /**
     * Callback listener from MessageDialogFragmentV4
     * @param dialog
     * @param requestCode
     * @param permissions
     * @param result
     */
    @SuppressLint("NewApi")
    @Override
    public void onMessageDialogResult(final MessageDialogFragment dialog, final int requestCode, final String[] permissions, final boolean result) {
        if (result) {
            // request permission(s) when user touched/clicked OK
            if (BuildCheck.isMarshmallow()) {
                requestPermissions(permissions, requestCode);
                return;
            }
        }
        // check permission and call #checkPermissionResult when user canceled or not Android6(and later)
        for (final String permission: permissions) {
            checkPermissionResult(requestCode, permission, PermissionCheck.hasPermission(this, permission));
        }
    }

    /**
     * callback method when app(Fragment) receive the result of permission result from ANdroid system
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(final int requestCode, @NonNull final String[] permissions, @NonNull final int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);   // 何もしてないけど一応呼んどく
        final int n = Math.min(permissions.length, grantResults.length);
        for (int i = 0; i < n; i++) {
            if (grantResults[i] == PackageManager.PERMISSION_GRANTED) {
                getAllVideoFromGallery();
            } else {
                Toast.makeText(GalleryActivity.this, "The app was not allowed to read or write to your storage. Hence, it cannot function properly. Please consider granting it this permission", Toast.LENGTH_LONG).show();
            }
            checkPermissionResult(requestCode, permissions[i], grantResults[i] == PackageManager.PERMISSION_GRANTED);
        }
    }

    /**
     * check the result of permission request
     * if app still has no permission, just show Toast
     * @param requestCode
     * @param permission
     * @param result
     */
    protected void checkPermissionResult(final int requestCode, final String permission, final boolean result) {
        // show Toast when there is no permission
        if (Manifest.permission.RECORD_AUDIO.equals(permission)) {
            onUpdateAudioPermission(result);
            if (!result) {
                Toast.makeText(this, R.string.permission_audio, Toast.LENGTH_SHORT).show();
            }
        }
        if (Manifest.permission.WRITE_EXTERNAL_STORAGE.equals(permission)) {
            onUpdateExternalStoragePermission(result);
            if (!result) {
                Toast.makeText(this, R.string.permission_ext_storage, Toast.LENGTH_SHORT).show();
            }
        }
        if (Manifest.permission.INTERNET.equals(permission)) {
            onUpdateNetworkPermission(result);
            if (!result) {
                Toast.makeText(this, R.string.permission_network, Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * called when user give permission for audio recording or canceled
     * @param hasPermission
     */
    protected void onUpdateAudioPermission(final boolean hasPermission) {
    }

    /**
     * called when user give permission for accessing external storage or canceled
     * @param hasPermission
     */
    protected void onUpdateExternalStoragePermission(final boolean hasPermission) {
    }

    /**
     * called when user give permission for accessing network or canceled
     * this will not be called
     * @param hasPermission
     */
    protected void onUpdateNetworkPermission(final boolean hasPermission) {
    }

    protected static final int REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE = 0x01;
    protected static final int REQUEST_PERMISSION_AUDIO_RECORDING = 0x02;
    protected static final int REQUEST_PERMISSION_NETWORK = 0x03;

    /**
     * check whether this app has write external storage
     * if this app has no permission, show dialog
     * @return true this app has permission
     */
    protected boolean checkPermissionWriteExternalStorage() {
        if (!PermissionCheck.hasWriteExternalStorage(this)) {
            MessageDialogFragment.showDialog(this, REQUEST_PERMISSION_WRITE_EXTERNAL_STORAGE,
                                             R.string.permission_title, R.string.permission_ext_storage_request,
                                             new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE});
            return false;
        }
        return true;
    }

    /**
     * check whether this app has permission of audio recording
     * if this app has no permission, show dialog
     * @return true this app has permission
     */
    protected boolean checkPermissionAudio() {
        if (!PermissionCheck.hasAudio(this)) {
            MessageDialogFragment.showDialog(this, REQUEST_PERMISSION_AUDIO_RECORDING,
                                             R.string.permission_title, R.string.permission_audio_recording_request,
                                             new String[]{Manifest.permission.RECORD_AUDIO});
            return false;
        }
        return true;
    }

    /**
     * check whether permission of network access
     * if this app has no permission, show dialog
     * @return true this app has permission
     */
    protected boolean checkPermissionNetwork() {
        if (!PermissionCheck.hasNetwork(this)) {
            MessageDialogFragment.showDialog(this, REQUEST_PERMISSION_NETWORK,
                                             R.string.permission_title, R.string.permission_network_request,
                                             new String[]{Manifest.permission.INTERNET});
            return false;
        }
        return true;
	}
}
