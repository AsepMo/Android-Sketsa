package com.video.application;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.video.application.fragments.MediaStroreFragment;
import com.video.application.utils.VideoUtils;

public class VideoRecordActivity extends AppCompatActivity {
   
    
    public static void start(Context c) {
        Intent mConvert = new Intent(c, VideoRecordActivity.class);
        c.startActivity(mConvert);
    }
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_history_recorder);

        //Toolbar toolbar=(Toolbar)findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);

        showFragment(MediaStroreFragment.createFor(VideoUtils.MP4));
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // TODO: Implement this method
        menu.add("Video")
            .setIcon(R.drawable.ic_library_video)
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener()
            {
                @Override
                public boolean onMenuItemClick(MenuItem item)
                {
                    showFragment(MediaStroreFragment.createFor(VideoUtils.MP4));                          
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
            
        menu.add("Audio")
            .setIcon(R.drawable.ic_audiobook)
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener()
            {
                @Override
                public boolean onMenuItemClick(MenuItem item)
                {
                    showFragment(MediaStroreFragment.createFor(VideoUtils.MP3));            
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        
        return super.onCreateOptionsMenu(menu);
    }
    
    public void showFragment(Fragment developert)
    {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, developert)
            .commit();
	}
}

