package com.video.application.adapters;

import android.app.Activity;
import android.app.DialogFragment;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.media.MediaScannerConnection;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

import com.video.application.R;
import com.video.application.models.VideoModel;
import com.video.application.MainActivity;
import com.video.application.RecorderActivity;
import com.video.application.VideoPlayerActivity;
import com.video.application.VideoRecordActivity;
import com.video.application.TrimmerActivity;
import com.video.application.ConvertActivity;
import com.video.application.ComposeActivity;

import com.video.engine.app.dialog.RenameDialog;
import com.video.engine.graphics.encoder.Mp4toGIFConverter;
import android.text.TextUtils;

public class VideoRecyclerAdapter extends ArrayAdapter<VideoModel> {


    private ArrayList<VideoModel> videoList;
    // Layout Inflater
    private final LayoutInflater inflater;

    private Activity activity;
    //private int REQ_PLAYER_CODE  = 1;

    public VideoRecyclerAdapter(Activity activity, ArrayList<VideoModel> videoList) {
        super(activity, R.layout.video_list_row, videoList);
        this.activity  = activity;
        this.inflater = LayoutInflater.from(activity);
        this.videoList = videoList;

	}

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

        VideoModel video = videoList.get(position);
        if (convertView == null) {
            convertView = this.inflater.inflate(R.layout.video_list_row, parent, false);
        }

        ImageView thumbnail = (ImageView)convertView.findViewById(R.id.video_thumbnail_image_view);

        ImageView icon = (ImageView) convertView.findViewById(R.id.imgFileIcon);

        TextView name = (TextView) convertView.findViewById(R.id.video_title_label);
        name.setText(video.getVideoTitle()); 
        //name.setTextColor(textColor);

        TextView size = (TextView) convertView.findViewById(R.id.video_duration_label);   

        if (video.getVideoTitle().contains("Recorder")) {
            thumbnail.setImageResource(R.drawable.ic_youtube_wall);
            icon.setImageResource(R.mipmap.ic_folder_gray_48dp);
            size.setText("Folder Video Record");
        } else {
            Glide.with(activity)
                .load(video.getVideoThumb())
                .placeholder(R.drawable.video_placeholder)
                .into(thumbnail);

            Glide.with(activity)
                .load(video.getVideoThumb())
                .placeholder(R.drawable.video_placeholder)
                .into(icon);
            StringBuilder sb = new StringBuilder();
            sb.append(video.getVideoSize());
            size.setText(sb.toString());  
        }

        convertView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final VideoModel video = videoList.get(position);
                    if (video.getPathName().contains("Camera")) {
                        MainActivity main = (MainActivity)activity;
                        main.onPrepared(video.getVideoPath());


                        Toast.makeText(activity, video.getPathName(), Toast.LENGTH_SHORT).show();
                    } else if (video.getVideoTitle().contains("Recorder")) {
                        Intent videoIntent = new Intent(activity, VideoRecordActivity.class);
                        activity.startActivity(videoIntent);

                        Toast.makeText(activity, video.getPathName(), Toast.LENGTH_SHORT).show();
                    } else {                
                        /*Intent videoIntent = new Intent(activity, VideoPlayerActivity.class);
                         videoIntent.putExtra(VideoPlayerActivity.TAG_URL, video.getVideoPath());
                         activity.startActivity(videoIntent);*/
                        MainActivity main = (MainActivity)activity;
                        main.onPrepared(video.getVideoPath());



                        Toast.makeText(activity, video.getPathName(), Toast.LENGTH_SHORT).show();
                    }

                }

			});
        convertView.setOnLongClickListener(new View.OnLongClickListener(){
                @Override
                public boolean onLongClick(View v) {
                    final VideoModel video = videoList.get(position);
                    if (video.getPathName().contains("Camera")) {
                        MainActivity main = (MainActivity)activity;
                        main.onPrepared(video.getVideoPath());


                        Toast.makeText(activity, video.getPathName(), Toast.LENGTH_SHORT).show();
                    } else if (video.getVideoTitle().contains("Recorder")) {
                        Intent videoIntent = new Intent(activity, VideoRecordActivity.class);
                        activity.startActivity(videoIntent);

                        Toast.makeText(activity, video.getPathName(), Toast.LENGTH_SHORT).show();
                    } else {    
                        new AlertDialog.Builder(activity)
                            .setItems(new CharSequence[]{"Play", "Delete", "Record", "Trimmer", "Composer", "Convert To Mp3", "Convert To Gif", "Share"}, new DialogInterface.OnClickListener(){
                                @Override
                                public void onClick(DialogInterface  dialog, int which) {
                                    switch (which) {
                                        case 0:
                                            VideoPlayerActivity.startTrimActivity(activity, video.getVideoPath());
                                            break;
                                        case 1:
                                            confirmDelete(video.getVideoPath(), getPosition(videoList.get(position)));

                                            /*ArrayList<VideoModel> deleteFiles = new ArrayList<>();
                                             for (VideoModel video : videoList) {
                                             if (video.isSelected()) {
                                             //deleFiles.add(new File(videos.get(videos.indexOf(video)).getFile().getPath()));
                                             deleteFiles.add(video);
                                             }
                                             }
                                             if (!deleteFiles.isEmpty())
                                             confirmDelete(deleteFiles);*/

                                            break;
                                        
                                        case 2:
                                            Intent videoIntent = new Intent(activity, RecorderActivity.class);
                                            videoIntent.putExtra(RecorderActivity.TAG_URL, video.getVideoPath());          
                                            videoIntent.putExtra(RecorderActivity.TAG_THUMBNAILS, video.getVideoThumb());
                                            activity.startActivity(videoIntent);                                       
                                            break;  
                                        case 3:
                                            TrimmerActivity.startTrimActivity(activity, video.getVideoPath());
                                            break;  
                                        case 4:
                                            ComposeActivity.startTrimActivity(activity, video.getVideoPath());
                                            break; 
                                        case 5:
                                            ConvertActivity.startTrimActivity(activity, video.getVideoPath());
                                            break;     
                                        case 6:
                                            File file = new File(video.getVideoPath());
                                            Mp4toGIFConverter gif = new Mp4toGIFConverter(activity);
                                            gif.setVideoUri(Uri.fromFile(file.getAbsoluteFile()));
                                            gif.convertToGif();
                                            break;    
                                        case 7:
                                            shareVideo(video);
                                            break;  


                                    }
                                    dialog.dismiss();
                                }
                            })
                            .show();
                    }
                    return true;   
                }
            });
        return convertView;
    }



    /**
     * Share the videos selected
     *
     * @param position Integer value representing the position of the video to be shared
     * @see #shareVideos(ArrayList positions)
     */
    private void shareVideo(VideoModel video) {
        File file = new File(video.getVideoPath());
        Uri fileUri = FileProvider.getUriForFile(activity, activity.getPackageName() + ".provider", file.getAbsoluteFile());

        Intent Shareintent = new Intent()
            .setAction(Intent.ACTION_SEND)
            .setType("video/*")
            .setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .putExtra(Intent.EXTRA_STREAM, fileUri);
        activity.startActivity(Intent.createChooser(Shareintent, activity.getString(R.string.share_intent_notification_title)));
    }

    /**
     * Share the videos selected
     *
     * @param positions Integer ArrayList containing the positions of the videos to be shared
     *
     * @see #shareVideo(int postion)
     */
    private void shareVideos(ArrayList<Integer> positions) {
        ArrayList<Uri> video = new ArrayList<>();
        for (int position : positions) {
            File file = new File(videoList.get(position).getVideoPath());

            video.add(FileProvider.getUriForFile(activity, activity.getPackageName() + ".provider", file.getAbsoluteFile()));
        }
        Intent Shareintent = new Intent()
            .setAction(Intent.ACTION_SEND_MULTIPLE)
            .setType("video/*")
            .setFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            .putParcelableArrayListExtra(Intent.EXTRA_STREAM, video);
        activity.startActivity(Intent.createChooser(Shareintent, activity.getString(R.string.share_intent_notification_title)));
    }

    /**
     * Delete the videos selected
     *
     * @param position integer value representing the position of the video to be deleted
     *
     * @see #deleteVideo(int position)
     */
    private void deleteVideo(String video, int position) {
        Log.d("Videos List", "delete position clicked: " + position);

        String path =  video;
        String result;
        File file = new File(path);
        try {
            removeFile(file);
            result = "removed: " +  video;
        } catch (Exception e) {
            result = e.getMessage();
        }
        videoList.remove(position);

        notifyDataSetChanged();
        //rerunHistoryLoader();
        Toast.makeText(activity, result, Toast.LENGTH_SHORT).show();

    }

    private void removeFile(File file) throws IOException {
        if (file != null && file.exists()) {
            if (file.isDirectory()) {
                for (File sub : file.listFiles()) {
                    removeFile(sub);
                }
            }
            file.delete();
        }
    }
    /**
     * Delete the videos selected
     *
     * @param deleteVideos ArrayList of integers containing the position of the videos to be deleted
     *
     * @see #deleteVideo(int position)
     */
    private void deleteVideos(ArrayList<VideoModel> deleteVideos) {
        for (VideoModel video : deleteVideos) {
            File file = new File(video.getVideoPath());
            if (file.getAbsoluteFile().delete()) {
                notifyDataSetChanged();
                videoList.remove(videoList.indexOf(video));
            }
        }
        notifyDataSetChanged();
    }

    private void delete(String video, int position) {
        deleteVideo(video, position);
        indexFile(video);
    }
    /**
     * Show confirmation dialog before the video is deleted
     *
     * @param position integer representing the postion of the video in the dataset to delete
     */
    private void confirmDelete(final String video, final int position) {
        new AlertDialog.Builder(activity)
            .setTitle(activity.getResources().getQuantityString(R.plurals.delete_alert_title, 1))
            .setMessage(activity.getResources().getQuantityString(R.plurals.delete_alert_message, 1))
            .setCancelable(false)
            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    deleteVideo(video, position);
                    indexFile(video);
                }
            })
            .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            })
            .show();
    }

    /**
     * Show confirmation dialog before the video is deleted
     *
     * @param deleteVideos Array list of integer containing the positions of the videos in the dataset to delete
     */
    private void confirmDelete(final ArrayList<VideoModel> deleteVideos) {
        final int count = deleteVideos.size();
        new AlertDialog.Builder(activity)
            .setTitle(activity.getResources().getQuantityString(R.plurals.delete_alert_title, count))
            .setMessage(activity.getResources().getQuantityString(R.plurals.delete_alert_message,
                                                                  count, count))
            .setCancelable(false)
            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    deleteVideos(deleteVideos);          
                }
            })
            .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {

                }
            })
            .show();
    }

    private void indexFile(String SAVEPATH) {
        //Create a new ArrayList and add the newly created video file path to it
        ArrayList<String> toBeScanned = new ArrayList<>();
        toBeScanned.add(SAVEPATH);
        String[] toBeScannedStr = new String[toBeScanned.size()];
        toBeScannedStr = toBeScanned.toArray(toBeScannedStr);

        //Request MediaScannerConnection to scan the new file and index it
        MediaScannerConnection.scanFile(activity, toBeScannedStr, null, new MediaScannerConnection.OnScanCompletedListener() {

                @Override
                public void onScanCompleted(String path, Uri uri) {
                    //Log.i(TAG, "SCAN COMPLETED: " + path);
                    notifyDataSetChanged();
                    activity.setResult(TrimmerActivity.VIDEO_EDIT_RESULT_CODE);

                }
            });
    }
}


