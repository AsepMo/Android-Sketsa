package com.video.application.adapters;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import java.util.List;
import java.util.ArrayList;

import com.video.application.R;
import com.video.application.models.VideoModel;
import com.video.application.VideoPlayerActivity;

public class VideoAdapter extends ArrayAdapter<VideoModel> {

   // private List<VideoModel> videoList;
    private ArrayList<VideoModel> videoList;
    // Layout Inflater
    private final LayoutInflater inflater;
    
    private Activity activity;
    //private int REQ_PLAYER_CODE  = 1;
    
    public VideoAdapter(Activity activity, ArrayList<VideoModel> videoList)
    {
        super(activity, R.layout.video_row, videoList);
        this.activity  = activity;
        this.inflater = LayoutInflater.from(activity);
        this.videoList = videoList;
    
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        
        VideoModel video = videoList.get(position);
        if (convertView == null)
        {
            convertView = this.inflater.inflate(R.layout.video_row, parent, false);
        }

        ImageView thumbnail = (ImageView)convertView.findViewById(R.id.video_thumbnail_image_view);
        Glide.with(activity)
            .load(video.getVideoThumb())
            .placeholder(R.drawable.video_placeholder)
            .into(thumbnail);

        
        return convertView;
    }
    
}


