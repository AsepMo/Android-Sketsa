package com.video.application;

import android.support.v7.app.AppCompatActivity;
import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnPreparedListener;
import android.provider.MediaStore;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.MediaController;
import android.widget.VideoView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import com.daasuu.mp4compose.FillMode;
import com.daasuu.mp4compose.composer.Mp4Composer;
import com.daasuu.mp4compose.filter.GlFilter;
import com.daasuu.mp4compose.filter.GlFilterGroup;
import com.daasuu.mp4compose.filter.GlMonochromeFilter;
import com.daasuu.mp4compose.filter.GlVignetteFilter;
import com.video.engine.app.composer.FilterType;
import com.video.application.VideoPlayerActivity;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class ComposeActivity extends AppCompatActivity implements View.OnClickListener {
    private VideoView myVideoView;
    private int position = 0;
    private ProgressDialog progressDialog;
    private MediaController mediaControls;
    public static final String TAG_URL = "video";
    private static final String TAG = "SAMPLE";
    private static final int PERMISSION_REQUEST_CODE = 88888;

    private Mp4Composer mp4Composer;
    private Bitmap bitmap;

    private CheckBox muteCheckBox;
    private CheckBox flipVerticalCheckBox;
    private CheckBox flipHorizontalCheckBox;

    private String videoPath;
    private String mVideo;

    private AlertDialog filterDialog;
    private GlFilter glFilter = new GlFilterGroup(new GlMonochromeFilter(), new GlVignetteFilter());

    public static void startTrimActivity(Context c, String uri) {
        Intent intent = new Intent(c, ComposeActivity.class);
        intent.putExtra(TAG_URL, uri);
        c.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        supportRequestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                             WindowManager.LayoutParams.FLAG_FULLSCREEN);

        // Get the layout from video_main.xml
        setContentView(R.layout.activity_video_compose);
        mVideo = getIntent().getStringExtra(TAG_URL);

        if (mediaControls == null) {
            mediaControls = new MediaController(ComposeActivity.this);
        }

        // Find your VideoView in your video_main.xml layout
        myVideoView = (VideoView) findViewById(R.id.video);


        // Create a progressbar
        progressDialog = new ProgressDialog(ComposeActivity.this);
        // Set progressbar title
        //progressDialog.setTitle("Youtube Present");
        // Set progressbar message
        progressDialog.setMessage("Please wait..");

        progressDialog.setCancelable(false);
        // Show progressbar
        progressDialog.show();

        try {
            myVideoView.setMediaController(mediaControls);
            //myVideoView.setVideoURI(Uri.parse("https://cldup.com/smVYfhBfim.mp4"));
            myVideoView.setVideoURI(Uri.parse(mVideo));
        } catch (Exception e) {
            Log.e("Error", e.getMessage());
            e.printStackTrace();
        }

        myVideoView.requestFocus();
        myVideoView.setOnPreparedListener(new OnPreparedListener() {
                // Close the progress bar and play the video
                public void onPrepared(MediaPlayer mp) {
                    progressDialog.dismiss();

                    if (position == 0) {
                        myVideoView.start();
                    } else {
                        myVideoView.pause();
                    }
                }
            });

        myVideoView.setOnCompletionListener(new MediaPlayer.OnCompletionListener(){
                @Override
                public void onCompletion(MediaPlayer mp) {
                    if (myVideoView.isPlaying()) {
                        myVideoView.stopPlayback();
                        myVideoView.pause();
                    }
                }
            });
        muteCheckBox = findViewById(R.id.mute_check_box);
        flipVerticalCheckBox = findViewById(R.id.flip_vertical_check_box);
        flipHorizontalCheckBox = findViewById(R.id.flip_horizontal_check_box);

        Button start = (Button)findViewById(R.id.start_codec_button);
        start.setEnabled(true);
        start.setOnClickListener(this);

        findViewById(R.id.cancel_button).setOnClickListener(this);

        findViewById(R.id.start_play_movie).setOnClickListener(this);

        findViewById(R.id.btn_filter).setOnClickListener(this);



        bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.lookup_sample);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.start_codec_button:
                v.setEnabled(false);
                startCodec();
                break;
            case R.id.cancel_button:
                if (mp4Composer != null) {
                    mp4Composer.cancel();
                }
                break;
            case R.id.start_play_movie:
                /*Uri uri = Uri.parse(videoPath);
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                intent.setDataAndType(uri, "video/mp4");
                startActivity(intent);*/
                VideoPlayerActivity.startTrimActivity(ComposeActivity.this, videoPath);
                break;  
            case R.id.btn_filter:
                if (filterDialog == null) {

                    AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                    builder.setTitle("Choose a filter");
                    builder.setOnDismissListener(new DialogInterface.OnDismissListener() {
                            @Override
                            public void onDismiss(DialogInterface dialog) {
                                filterDialog = null;
                            }

                        });

                    final FilterType[] filters = FilterType.values();
                    CharSequence[] charList = new CharSequence[filters.length];
                    for (int i = 0, n = filters.length; i < n; i++) {
                        charList[i] = filters[i].name();
                    }
                    builder.setItems(charList, new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int item) {

                                changeFilter(filters[item]);
                            }
                        });
                    filterDialog = builder.show();
                } else {
                    filterDialog.dismiss();
                }
                break;  
        }
    }

    private void changeFilter(FilterType filter) {
        glFilter = null;
        glFilter = FilterType.createGlFilter(filter, this);
        Button button = findViewById(R.id.btn_filter);
        button.setText("Filter : " + filter.name());
    }


    private void startCodec() {
        videoPath = getVideoFilePath();

        final ProgressBar progressBar = findViewById(R.id.progress_bar);
        progressBar.setMax(100);


        mp4Composer = null;
        mp4Composer = new Mp4Composer(mVideo, videoPath)
            // .rotation(Rotation.ROTATION_270)
            //.size(720, 1280)
            .fillMode(FillMode.PRESERVE_ASPECT_FIT)
            .filter(glFilter)
            .mute(muteCheckBox.isChecked())
            .flipHorizontal(flipHorizontalCheckBox.isChecked())
            .flipVertical(flipVerticalCheckBox.isChecked())
            .listener(new Mp4Composer.Listener() {
                @Override
                public void onProgress(final double progress) {
                    Log.d(TAG, "onProgress = " + progress);
                    runOnUiThread(new Runnable()
                        {
                            @Override
                            public void run() {
                                progressBar.setProgress((int) (progress * 100));
                            }
                        });
                }

                @Override
                public void onCompleted() {
                    Log.d(TAG, "onCompleted()");
                    exportMp4ToGallery(getApplicationContext(), videoPath);
                    runOnUiThread(new Runnable()
                        {
                            @Override
                            public void run() {
                                progressBar.setProgress(100);
                                findViewById(R.id.start_codec_button).setEnabled(true);
                                findViewById(R.id.start_play_movie).setEnabled(true);                    
                                Toast.makeText(ComposeActivity.this, "codec complete path =" + videoPath, Toast.LENGTH_SHORT).show();
                            }
                        });
                }

                @Override
                public void onCanceled() {

                }

                @Override
                public void onFailed(Exception exception) {
                    Log.d(TAG, "onFailed()");
                }
            })
            .start();


    }


    public File getAndroidMoviesFolder() {
        return Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES);
    }

    public String getVideoFilePath() {
        return getAndroidMoviesFolder().getAbsolutePath() + "/Recorder/" + new SimpleDateFormat("yyyyMM_dd-HHmmss").format(new Date()) + "filter_apply.mp4";
    }

    /**
     * ギャラリーにエクスポート
     *
     * @param filePath
     * @return The video MediaStore URI
     */
    public static void exportMp4ToGallery(Context context, String filePath) {
        // ビデオのメタデータを作成する
        final ContentValues values = new ContentValues(2);
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.DATA, filePath);
        // MediaStoreに登録
        context.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                                            values);
        context.sendBroadcast(new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE,
                                         Uri.parse("file://" + filePath)));
    }


    private boolean checkPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) {
            return true;
        }
        // request permission if it has not been grunted.
        if (checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, PERMISSION_REQUEST_CODE);
            return false;
        }

        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case PERMISSION_REQUEST_CODE:
                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(ComposeActivity.this, "permission has been grunted.", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(ComposeActivity.this, "[WARN] permission is not grunted.", Toast.LENGTH_SHORT).show();
                }
                break;
        }
    }
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("Position", myVideoView.getCurrentPosition());
        myVideoView.pause();
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        position = savedInstanceState.getInt("Position");
        myVideoView.seekTo(position);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        if (myVideoView.isPlaying()) {
            myVideoView.stopPlayback();
            myVideoView.pause();
            finish();
        }

    }

}


