package com.video.application;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.Context;
import android.media.MediaMetadataRetriever;
import android.media.MediaScannerConnection;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;


import com.video.application.utils.VideoUtils;
import life.knowledge4.videotrimmer.K4LVideoTrimmer;
import life.knowledge4.videotrimmer.utils.FileUtils;
import life.knowledge4.videotrimmer.interfaces.OnK4LVideoListener;
import life.knowledge4.videotrimmer.interfaces.OnTrimVideoListener;
import com.video.application.utils.FolderMe;

public class TrimmerActivity extends AppCompatActivity implements OnTrimVideoListener, OnK4LVideoListener {

    public static final String TAG = TrimmerActivity.class.getSimpleName();
    public static final String EXTRA_VIDEO_PATH = "video";
    public static final int VIDEO_EDIT_RESULT_CODE = 10005;
    
    private K4LVideoTrimmer mVideoTrimmer;
    private ProgressDialog mProgressDialog;
    public static void startTrimActivity(Context c, String uri) {
        Intent intent = new Intent(c, TrimmerActivity.class);
        intent.putExtra(EXTRA_VIDEO_PATH, uri);
        c.startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_trimmer);

        if(!getIntent().hasExtra(EXTRA_VIDEO_PATH)) {
            Toast.makeText(this, getResources().getString(R.string.video_not_found), Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        Uri videoUri = Uri.parse(getIntent().getStringExtra(EXTRA_VIDEO_PATH));

        if (!new File(videoUri.getPath()).exists()) {
            Toast.makeText(this, getResources().getString(R.string.video_not_found), Toast.LENGTH_SHORT).show();
            finish();
            return;
        }

        //setting progressbar
        mProgressDialog = new ProgressDialog(this);
        mProgressDialog.setCancelable(false);
        mProgressDialog.setMessage(getString(R.string.trimming_progress));

        mVideoTrimmer = ((K4LVideoTrimmer) findViewById(R.id.timeLine));
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        //use one of overloaded setDataSource() functions to set your data source
        retriever.setDataSource(this, videoUri);
        String time = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
        int timeInMins = (((int)Long.parseLong(time)) / 1000)+1000;
        //Log.d(Const.TAG, timeInMins+"");

        //File video = new File(path);


        if (mVideoTrimmer != null) {
            mVideoTrimmer.setMaxDuration(timeInMins);
            mVideoTrimmer.setOnTrimVideoListener(this);
            mVideoTrimmer.setOnK4LVideoListener(this);
            mVideoTrimmer.setDestinationPath(FolderMe.ZFOLDER_VIDEO_SCREEN_RECORDER + "/");
            mVideoTrimmer.setVideoURI(videoUri);
            mVideoTrimmer.setVideoInformationVisibility(true);
        }
    }

    @Override
    public void onTrimStarted() {
        mProgressDialog.show();
    }

    @Override
    public void getResult(final Uri uri) {
        mProgressDialog.cancel();
        indexFile(uri.getPath());


        runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(TrimmerActivity.this, getString(R.string.video_saved_at, uri.getPath()), Toast.LENGTH_SHORT).show();
                }
            });
        //Intent intent = new Intent(Intent.ACTION_VIEW);
        //intent.setDataAndType(uri, "video/*");
        //startActivity(intent);
        File video = new File(uri.getPath());
        VideoUtils.openFile(TrimmerActivity.this, video.getAbsoluteFile());
        //addFileToMediaStore(video.getAbsolutePath());
        finish();
    }

    @Override
    public void cancelAction() {
        mProgressDialog.cancel();
        mVideoTrimmer.destroy();
        finish();
    }

    @Override
    public void onError(final String message) {
        mProgressDialog.cancel();

        runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(TrimmerActivity.this, message, Toast.LENGTH_SHORT).show();
                }
            });
    }

    @Override
    public void onVideoPrepared() {
        runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    Toast.makeText(TrimmerActivity.this, "onVideoPrepared", Toast.LENGTH_SHORT).show();
                }
            });
    }
    
    private void indexFile(String SAVEPATH) {
        //Create a new ArrayList and add the newly created video file path to it
        ArrayList<String> toBeScanned = new ArrayList<>();
        toBeScanned.add(SAVEPATH);
        String[] toBeScannedStr = new String[toBeScanned.size()];
        toBeScannedStr = toBeScanned.toArray(toBeScannedStr);

        //Request MediaScannerConnection to scan the new file and index it
        MediaScannerConnection.scanFile(this, toBeScannedStr, null, new MediaScannerConnection.OnScanCompletedListener() {

                @Override
                public void onScanCompleted(String path, Uri uri) {
                    Log.i(TAG, "SCAN COMPLETED: " + path);
                    mProgressDialog.cancel();
                    setResult(VIDEO_EDIT_RESULT_CODE);
                    finish();
                }
            });
    }

    
}
