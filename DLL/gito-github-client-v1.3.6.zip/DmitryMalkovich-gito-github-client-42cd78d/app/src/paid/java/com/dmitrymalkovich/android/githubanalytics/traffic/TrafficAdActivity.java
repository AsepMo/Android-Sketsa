package com.dmitrymalkovich.android.githubanalytics.traffic;

public class TrafficAdActivity extends TrafficActivity {
}
