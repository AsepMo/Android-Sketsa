package com.web.client.application;

import android.annotation.TargetApi;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.design.widget.AppBarLayout;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.annotation.ColorInt;
import android.support.annotation.ColorRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.LinearLayoutManager;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.FrameLayout;

import java.util.Arrays;

import com.web.client.R;
import com.web.client.application.AppSettingsActivity;
import com.web.client.engine.Themes;
import com.web.client.engine.app.adapters.DrawerAdapter;
import com.web.client.engine.app.models.DrawerItem;
import com.web.client.engine.app.models.SimpleItem;
import com.web.client.engine.app.models.SpaceItem;
import com.web.client.engine.app.config.Constants;
import com.web.client.engine.app.fragments.FTPViewFragment;
import com.web.client.engine.app.fragments.FTPEditFragment;
import com.web.client.engine.app.fragments.FTPListFragment;
import com.web.client.engine.app.fragments.WebClientFragment;
import com.web.client.engine.app.server.ftp.FTP;
import com.web.client.engine.app.server.ftp.FTPLab;
import com.web.client.engine.graphics.SystemBarTintManager;
import com.web.client.engine.widget.SlidingRootNav;
import com.web.client.engine.widget.SlidingRootNavBuilder;

public class FTPClientActivity extends ThemableActivity implements DrawerAdapter.OnItemSelectedListener,FTPListFragment.MyListener {
    

    public static String TAG = FTPClientActivity.class.getSimpleName();
    public static final String ACTION_FTP = "com.aweb.client.action.ACTION_FTP";
    public static final String ACTION_FTP_EDIT = "com.aweb.client.action.ACTION_FTP_EDIT";
    public static final String ACTION_FTP_LIST = "com.aweb.client.action.ACTION_FTP_LIST";

    public static final String EXTRA_FTP = "com.aweb.client";
    private static final String EXTRA_FTP_ID = "com.aweb.client.crime_id";
    private static final int ADD_FTP = 0;

    private static final int POS_WEB_SITE = 0;
    private static final int POS_WEB_UPLOAD = 1;
    private static final int POS_WEB_FILE_LIST = 2;
    private static final int POS_WEB_LAUNCH = 3;
    private static final int POS_WEB_BACK_TO_HOME = 5;

    private String[] screenTitles;
    private Drawable[] screenIcons;

    private SlidingRootNav slidingRootNav;
    private FTPListFragment mFTPListFragment;
    
    
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        setTheme(R.style.AppTheme_NoActionBar);
        if (Themes.hasLollipop())
        {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        }
        else if (Themes.hasKitKat())
        {
            setTheme(R.style.AppTheme_Translucent);
        }
        setUpStatusBar();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_store);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle("Remote Web");
        toolbar.setSubtitle("The Best Of FTP Client");
        setSupportActionBar(toolbar);

        slidingRootNav = new SlidingRootNavBuilder(this)
            .withToolbarMenuToggle(toolbar)
            .withMenuOpened(false)
            .withContentClickableWhenMenuOpened(false)
            .withSavedState(savedInstanceState)
            .withMenuLayout(R.layout.menu_application_drawer)
            .inject();

        screenIcons = loadScreenIcons();
        screenTitles = loadScreenTitles();

        DrawerAdapter adapter = new DrawerAdapter(Arrays.asList(
                                                      createItemFor(POS_WEB_SITE).setChecked(true),
                                                      createItemFor(POS_WEB_UPLOAD),
                                                      createItemFor(POS_WEB_FILE_LIST),
                                                      createItemFor(POS_WEB_LAUNCH),
                                                      new SpaceItem(48),
                                                      createItemFor(POS_WEB_BACK_TO_HOME)));
        adapter.setListener(this);

        RecyclerView list = (RecyclerView)findViewById(R.id.list);
        list.setNestedScrollingEnabled(false);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        adapter.setSelected(POS_WEB_SITE);

        changeActionBarColor();
    }

    @Override
    public void onItemSelected(int position)
    {
        // TODO: Implement this method

        if (position == POS_WEB_SITE) {
            mFTPListFragment = new FTPListFragment();           
            showFragment(mFTPListFragment);
        }
        if (position == POS_WEB_UPLOAD) {
            FTP ftp = new FTP();
            Intent intent = FTPEditActivity.newIntent(this, ftp);
            startActivityForResult(intent, FTPEditFragment.ADD_FTP);
        }
        if (position == POS_WEB_FILE_LIST) {
            //switchFragment(FTPViewFragment.newInstance(ftpId));
        }
        if (position == POS_WEB_LAUNCH) {
            showFragment(WebClientFragment.loadWeb(Constants.ASEPMO_URL));
        }
        
        if (position == POS_WEB_BACK_TO_HOME) {
            //switchFragment(ArchiveFragment.newInstance(0));
        }
        slidingRootNav.closeMenu();
       
    }


    @Override
    public void finishActivity() {
        FTPClientActivity.this.finish();
    }
    
    public void showFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    }

    private DrawerItem createItemFor(int position) {
        return new SimpleItem(screenIcons[position], screenTitles[position])
            .withIconTint(color(R.color.textColorSecondary))
            .withTextTint(color(R.color.textColorPrimary))
            .withSelectedIconTint(color(R.color.colorAccent))
            .withSelectedTextTint(color(R.color.colorAccent));
    }

    private String[] loadScreenTitles() {
        return getResources().getStringArray(R.array.ld_remoteWebTitles);
    }

    private Drawable[] loadScreenIcons() {
        TypedArray ta = getResources().obtainTypedArray(R.array.ld_remoteWebIcons);
        Drawable[] icons = new Drawable[ta.length()];
        for (int i = 0; i < ta.length(); i++) {
            int id = ta.getResourceId(i, 0);
            if (id != 0) {
                icons[i] = ContextCompat.getDrawable(this, id);
            }
        }
        ta.recycle();
        return icons;
    }

    @ColorInt
    private int color(@ColorRes int res) {
        return ContextCompat.getColor(this, res);
    }

    @Override
    protected void onResume()
    {
        // TODO: Implement this method
        super.onResume();
        changeActionBarColor();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings)
        {
            AppSettingsActivity.start(FTPClientActivity.this);
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private final Handler handler = new Handler();
    private Drawable oldBackground;

    private void changeActionBarColor()
    {

        int color = AppSettingsActivity.getPrimaryColor(this);
        Drawable colorDrawable = new ColorDrawable(color);

        if (oldBackground == null)
        {
            getSupportActionBar().setBackgroundDrawable(colorDrawable);
        }
        else
        {
            TransitionDrawable td = new TransitionDrawable(new Drawable[] { oldBackground, colorDrawable });
            getSupportActionBar().setBackgroundDrawable(td);
            td.startTransition(200);
        }

        oldBackground = colorDrawable;

        setUpStatusBar();
    }

    private Drawable.Callback drawableCallback = new Drawable.Callback() {
        @Override
        public void invalidateDrawable(Drawable who)
        {
            getSupportActionBar().setBackgroundDrawable(who);
        }

        @Override
        public void scheduleDrawable(Drawable who, Runnable what, long when)
        {
            handler.postAtTime(what, when);
        }

        @Override
        public void unscheduleDrawable(Drawable who, Runnable what)
        {
            handler.removeCallbacks(what);
        }
    };

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void setUpStatusBar()
    {
        // TODO: Implement this method
        int color = Themes.getStatusBarColor(AppSettingsActivity.getPrimaryColor(this));
        if (Themes.hasLollipop())
        {
            getWindow().setStatusBarColor(color);
        }
        else if (Themes.hasKitKat())
        {
            SystemBarTintManager systemBarTintManager = new SystemBarTintManager(this);
            systemBarTintManager.setTintColor(color);
            systemBarTintManager.setStatusBarTintEnabled(true);
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void setUpDefaultStatusBar()
    {
        // TODO: Implement this method
        int color = ContextCompat.getColor(this, R.color.alertColor);
        if (Themes.hasLollipop())
        {
            getWindow().setStatusBarColor(color);
        }
        else if (Themes.hasKitKat())
        {
            SystemBarTintManager systemBarTintManager = new SystemBarTintManager(this);
            systemBarTintManager.setTintColor(Themes.getStatusBarColor(color));
            systemBarTintManager.setStatusBarTintEnabled(true);
        }
    }

    public static int getStatusBarHeight(Context context)
    {
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0)
        {
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }
    @Override
    public String getTag()
    {
        // TODO: Implement this method
        return TAG;
    }
}

