package com.web.client.engine.app.settings;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.preference.PreferenceManager;

import java.io.File;
import java.security.InvalidParameterException;
import java.util.Comparator;

import com.web.client.R;
import com.web.client.engine.app.root.RootChecker;
import com.web.client.engine.app.config.Constants;

public class Settings {
    
    public static String TAG = Settings.class.getSimpleName();
    private static final String NAME = "SharedPref";
    private static SharedPreferences mPrefs;
    private static SharedPreferences.Editor editor;
    public static int mTheme;

    public static void updatePreferences(Context context) {
        mPrefs = PreferenceManager.getDefaultSharedPreferences(context);
        mPrefs = context.getSharedPreferences(NAME, Activity.MODE_PRIVATE);
        mTheme = Integer.parseInt(mPrefs.getString("preference_theme", Integer.toString(R.style.AppTheme_NoActionBar)));

        rootAccess();
    }
    
    public static boolean saveDetals(String name, String email, String password, String age, String gender, String imgpath)
    {
        editor = mPrefs.edit();
        editor.putString("name",name);
        editor.putString("email",email);
        editor.putString("password",password);
        editor.putString("gender",gender);
        editor.putString("age",age);
        editor.putString("imgpath",imgpath);

        return editor.commit();
    }

    public static String getName()
    {
        return mPrefs.getString("name","0");
    }
    
    public static String getEmail()
    {
        return mPrefs.getString("email","0");
    }
    
    public static String getPassword()
    {
        return mPrefs.getString("password","0");
    }
    
    public static String getAge()
    {
        return mPrefs.getString("age","0");
    }
    
    public static String getGender()
    {
        return mPrefs.getString("gender","0");
    }
    
    public static String getImgPath()
    {
        return mPrefs.getString("imgpath","0");
    }

    public static boolean setLoginStatus(boolean status)
    {
        editor = mPrefs.edit();
        editor.putBoolean("status",status);
        return editor.commit();
    }

    public static boolean getLoginStatus()
    {
        return mPrefs.getBoolean("status",false);
    }


    public static boolean setChannelId(String id){
        editor = mPrefs.edit();
        editor.putString("channelID",id);
        return editor.commit();
    }

    public static String getChannelID()
    {
        return mPrefs.getString("channelID", Constants.CHANNEL_ID);
    }
    
    public static void setIsShortCut(Context context, Boolean isLogin) {
        editor = mPrefs.edit();
        editor.putBoolean("isShortCut", isLogin);
        editor.commit();
    }

    public static Boolean isShortCut(Context context) {
        return mPrefs.getBoolean("isShortCut", false);
    }
    
    public static String getWebFileMd5()
    {
        return mPrefs.getString("web_file_md5", "");
    }
    
    public static void setWebFileMd5(String md5)
    {
        mPrefs.edit().putString("web_file_md5", md5).commit();
    }
    
    public static int getPort()
    {
        return mPrefs.getInt("server_port", 8080);
    }
    
    public static void setPort(int port){
        mPrefs.edit().putInt("server_port", port).commit();
	}
    
    public static boolean rootAccess() {
        return mPrefs.getBoolean("enablerootaccess", false) && RootChecker.isDeviceRooted();
    }
    
    public static String getDefaultDir() {
        return mPrefs.getString("defaultdir", Environment.getExternalStorageDirectory().getPath());
    }
    
    public static int getDefaultTheme() {
        return mTheme;
    }

    public static void setDefaultTheme(int theme) {
        mTheme = theme;
    }
}
