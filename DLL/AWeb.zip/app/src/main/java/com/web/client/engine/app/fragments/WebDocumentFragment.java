package com.web.client.engine.app.fragments;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.app.PendingIntent;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.DialogInterface.OnCancelListener;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

import com.web.client.R;
import com.web.client.application.ApplicationActivity;
import com.web.client.application.SettingsActivity;
import com.web.client.engine.app.server.web.WebFileInstaller;
import com.web.client.engine.app.server.web.Intents;
import com.web.client.engine.app.server.web.Utils;
import com.web.client.engine.app.settings.Settings;
import com.web.client.service.HttpService;

public class WebDocumentFragment extends Fragment implements OnClickListener, DialogInterface.OnClickListener, OnCancelListener {

    public static String TAG = WebDocumentFragment.class.getSimpleName();
    private Context mContext;
    private ToggleButton toggleButton;
    private TextView textView;
    private TextView textUrl;
    private ConnectivityManager connMgr;
    private String ipAddress;
    private ProgressDialog progress;
    private ImageView img;
    private ImageView imgQrcode;
    private IntentFilter filter;
	private Bitmap mQRbitmap;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_app_web_file, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        toggleButton = (ToggleButton) view.findViewById(R.id.toggleButton1);
        toggleButton.setOnClickListener(this);

        mContext = getActivity();
        textView = (TextView) view.findViewById(R.id.textView1);
        textUrl = (TextView) view.findViewById(R.id.textView2);
        img = (ImageView) view.findViewById(R.id.imageView1);
        imgQrcode = (ImageView) view.findViewById(R.id.imageView_QRcode);
        connMgr = (ConnectivityManager) mContext.getSystemService(Context.CONNECTIVITY_SERVICE);

        Settings.updatePreferences(mContext);

        if (!WebFileInstaller.isWebfileInstalled(mContext)) {
            showInstallProgress();
            installWebFiles();
        }
        filter = new IntentFilter();
        filter.addAction(Intents.ACTION_SERVER_STATE_CHANGE);
		filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        setHasOptionsMenu(true);
    }

    @Override
    public void onResume() {

        getActivity().registerReceiver(receiver, filter);
        refreshUIState();

        super.onResume();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.add("Chrome")
            .setIcon(R.drawable.ic_google_chrome)
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    if (HttpService.isRunning()) {
                        ipAddress = Utils.getLocalIpAddress();
                        final String url = String.format("http://%s:%d", ipAddress, Settings.getPort());

                        new Handler().postDelayed(new Runnable(){
                                @Override
                                public void run() {
                                    ApplicationActivity mApplication = (ApplicationActivity)getActivity();
                                    mApplication.switchFragment(WebClientFragment.loadWeb(url));
                                }
                            }, 200);
                    }
                    return false;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        inflater.inflate(R.menu.menu_web_server, menu);
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // TODO: Implement this method
        switch (item.getItemId()) {
            case R.id.action_settings:
                SettingsActivity.startPreference(getActivity());
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    private void refreshUIState() {
        if (!Utils.isSdCardMounted()) {
            Toast.makeText(mContext, R.string.web_storage_off, Toast.LENGTH_LONG).show();
        }

        if (!Utils.isNetworkActive(connMgr)) {

            textView.setText(R.string.web_wifi_off);
            textView.setTextColor(Color.RED);
            img.setImageResource(R.drawable.ic_signal_connection);
            toggleButton.setEnabled(false);
            textUrl.setVisibility(View.GONE);
            imgQrcode.setVisibility(View.GONE);
            return;

        }
        toggleButton.setEnabled(true);
        if (HttpService.isRunning()) {
            ipAddress = Utils.getLocalIpAddress();

            textView.setText(R.string.web_server_on);
            textView.setTextColor(Color.argb(255, 0x22, 0x8b, 0x22));
            img.setImageResource(R.drawable.ic_signal_connection_on);
            toggleButton.setChecked(true);
            textUrl.setVisibility(View.VISIBLE);
            String url = String.format("http://%s:%d", ipAddress, Settings.getPort());
            textUrl.setText(url);


            createQRcode(url);

        } else {
            textView.setText(R.string.web_server_off);
            textView.setTextColor(Color.RED);
            img.setImageResource(R.drawable.ic_signal_connection);
            toggleButton.setChecked(false);
            textUrl.setVisibility(View.GONE);
            imgQrcode.setVisibility(View.GONE);
        }

    }

    private PendingIntent createPendingIntent() {
        Intent actionIntent = new Intent(mContext, ApplicationActivity.class);
        actionIntent.setFlags(Intent.FLAG_ACTIVITY_NO_HISTORY);
        return PendingIntent.getActivity(mContext, 0, actionIntent, 0);
    }

    @Override
    public void onPause() {
        getActivity().unregisterReceiver(receiver);
        super.onPause();
    }

    private BroadcastReceiver receiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            if (Intents.ACTION_SERVER_STATE_CHANGE.equals(intent.getAction())) {
                refreshUIState();

            } else if (ConnectivityManager.CONNECTIVITY_ACTION.equals(intent.getAction())) {

                refreshUIState();

            }
        }

    };

    private void showInstallProgress() {
        progress = new ProgressDialog(mContext);
        progress.setTitle(R.string.web_file_extract);
        progress.setCanceledOnTouchOutside(false);
        progress.setCancelable(false);
        progress.setOnCancelListener(this);
        progress.show();
    }

    @Override
    public void onCancel(DialogInterface dialog) {

        // Toast.makeText(this, "cancel", Toast.LENGTH_SHORT).show();
    }

    private Handler handler = new Handler() {

        @Override
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0:
                    if (progress != null) {
                        progress.dismiss();
                    }
                    break;
                case 1:
                    getActivity().finish();
                    break;
                case 2:
                    if (HttpService.isRunning()) {
                        imgQrcode.setVisibility(View.VISIBLE);
                        imgQrcode.setImageBitmap(mQRbitmap);
                    }
                    break;
                default:
                    break;
            }
        }

    };

    private void installWebFiles() {
        new Thread() {

            @Override
            public void run() {
                WebFileInstaller.installWebfile(mContext, handler);
            }

        }.start();
    }

    @Override
    public void onClick(DialogInterface dialog, int which) {
        getActivity().finish();
    }



    @Override
    public void onClick(View v) {

        Intent intent = new Intent();
        intent.setClass(mContext, HttpService.class);
        if (!HttpService.isRunning()) {
            mContext.startService(intent);
        } else {
            mContext.stopService(intent);
        }
    }


    private void createQRcode(final String url) {
        new Thread(){

            @Override
            public void run() {
                mQRbitmap = Utils.Create2DCode(url);

                if (mQRbitmap != null) {
                    Message msg=new Message();
                    msg.what = 2;
                    handler.sendMessage(msg);
                }
                super.run();
            }
        }.start();
	}
}
