package com.web.client.engine.app.fragments;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

import com.yanzhenjie.loading.dialog.LoadingDialog;

import java.util.LinkedList;
import java.util.List;

import com.web.client.R;
import com.web.client.AppController;
import com.web.client.application.ApplicationActivity;
import com.web.client.receiver.ServerReceiver;

public class WebServerFragment extends Fragment implements View.OnClickListener, ServerReceiver.OnServerReceiverListener {
      
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_EXTRA_URL = "EXTRA_URL";
    private static final String TAG = WebServerFragment.class.getSimpleName();

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    /*public static WebServerFragment loadWeb(String url) {
        WebServerFragment f = new WebServerFragment();
        Bundle b = new Bundle();
        b.putString(ARG_EXTRA_URL, url);
        f.setArguments(b);

        return f;
    }*/
    
    private ServerReceiver mServerManager;
    private Context mContext;
    private Button mBtnStart;
    private Button mBtnStop;
    private Button mBtnBrowser;
    private TextView mTvMessage;

    private LoadingDialog mDialog;
    private String mRootUrl;
    public WebServerFragment() {
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_app_web_server, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
 
        mContext = getActivity();
        mBtnStart = (Button) view.findViewById(R.id.btn_start);
        mBtnStop = (Button) view.findViewById(R.id.btn_stop);
        mBtnBrowser = (Button) view.findViewById(R.id.btn_browse);
        mTvMessage = (TextView) view.findViewById(R.id.tv_message);

        mBtnStart.setOnClickListener(this);
        mBtnStop.setOnClickListener(this);
        mBtnBrowser.setOnClickListener(this);

        // AndServer run in the service.
        mServerManager = new ServerReceiver(getActivity());
        mServerManager.register();
        mServerManager.setOnServerReceiverListener(this);
        
        // startServer;
        mBtnStart.performClick(); 
    }

    @Override
    public void onServerStart(String Ip) {
        serverStart(Ip);
    }

    @Override
    public void onServerError(String message) {
        serverError(message);
    }

    @Override
    public void onServerStop() {
        serverStop();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mServerManager.unRegister();
    }

    @Override
    public void onClick(View v) {
        int id = v.getId();
        switch (id) {
            case R.id.btn_start: {
                showDialog();
                mServerManager.startService();
                break;
            }
            case R.id.btn_stop: {
                showDialog();
                mServerManager.stopService();
                break;
            }
            case R.id.btn_browse: {
                if (!TextUtils.isEmpty(mRootUrl)) {
                    Intent intent = new Intent();
                    intent.setAction("android.intent.action.VIEW");
                    intent.setData(Uri.parse(mRootUrl));
                    startActivity(intent);
                }
                break;
            }
        }
    }

    /**
     * Start notify.
     */
    public void serverStart(String ip) {
        closeDialog();
        mBtnStart.setVisibility(View.GONE);
        mBtnStop.setVisibility(View.VISIBLE);
        mBtnBrowser.setVisibility(View.VISIBLE);

        if (!TextUtils.isEmpty(ip)) {
            List<String> addressList = new LinkedList<>();
            mRootUrl = "http://" + ip + ":8080/";
            addressList.add(mRootUrl);
            addressList.add("http://" + ip + ":8080/login.html");
            addressList.add("http://" + ip + ":8080/image");
            addressList.add("http://" + ip + ":8080/download");
            addressList.add("http://" + ip + ":8080/upload");
            mTvMessage.setText(TextUtils.join("\n", addressList));
        } else {
            mRootUrl = null;
            mTvMessage.setText(R.string.web_server_ip_error);
        }
    }

    /**
     * Error notify.
     */
    public void serverError(String message) {
        closeDialog();
        mRootUrl = null;
        mBtnStart.setVisibility(View.VISIBLE);
        mBtnStop.setVisibility(View.GONE);
        mBtnBrowser.setVisibility(View.GONE);
        mTvMessage.setText(message);
    }

    /**
     * Stop notify.
     */
    public void serverStop() {
        closeDialog();
        mRootUrl = null;
        mBtnStart.setVisibility(View.VISIBLE);
        mBtnStop.setVisibility(View.GONE);
        mBtnBrowser.setVisibility(View.GONE);
        mTvMessage.setText(R.string.web_server_stop_succeed);
    }

    private void showDialog() {
        if (mDialog == null)
            mDialog = new LoadingDialog(mContext);
        if (!mDialog.isShowing())
            mDialog.show();
    }

    private void closeDialog() {
        if (mDialog != null && mDialog.isShowing())
            mDialog.dismiss();
    }

}
