package com.web.client.engine.app.fragments;

import android.support.v4.app.Fragment;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.speech.RecognizerIntent;
import android.os.Bundle;
import android.util.Log;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.MenuItem;
import android.view.KeyEvent;
import android.widget.TextView;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.PopupMenu;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Date;

import com.web.client.R;
import com.web.client.engine.widget.SearchBox;
import com.web.client.engine.widget.SearchBoxLayout;

public class WebBrowserFragment extends Fragment implements SearchBox.OnSearchListener {

    public static String TAG = WebBrowserFragment.class.getSimpleName();
    public static String ARG_EXTRA_KEYWORD = "ARG_EXTRA_KEYWORD";
    public static int VOICE_RECOGNITION_CODE = 1234;

    private View mRootView;
    private Context mContext;  
    private String mSearchText;
    private SearchBox mSearch;
    private SearchBoxLayout mSearchLayout;
    private LinearLayout mProgressLayout;
    private ProgressBar mProgressBar;

    public static WebBrowserFragment newInstance(String keyword) {
        WebBrowserFragment f = new WebBrowserFragment();
        Bundle b = new Bundle();
        b.putString(ARG_EXTRA_KEYWORD, keyword);
        f.setArguments(b);
        return f;
    }

    public WebBrowserFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mSearchText = getArguments().getString(ARG_EXTRA_KEYWORD);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater,  ViewGroup container, Bundle savedInstanceState) {

        mRootView = inflater.inflate(R.layout.fragment_app_web_browser, container, false);
        return mRootView;
    }

    @Override
    public void onViewCreated(View view,  Bundle savedInstanceState) {

        mContext = getActivity();
        mSearch = (SearchBox) view.findViewById(R.id.searchbox);

        mSearchLayout = (SearchBoxLayout) view.findViewById(R.id.searchboxLayout);      
        mProgressLayout = (LinearLayout)view.findViewById(R.id.progressWrapper);
        mProgressBar = (ProgressBar)view.findViewById(R.id.activity_bar);  
        initBrowser();
    }

    private void initBrowser() {
        mSearchLayout.setStatus(SearchBoxLayout.Status.WEBVIEW);
        mSearch.setHint(mSearchText);     
        mSearch.initTextToSpeech(mContext, new SearchBox.OnReadyListener(){
                @Override
                public void onReady() {
                    mSearchLayout.setStatus(SearchBoxLayout.Status.WEBVIEW);
                }

            });
        mSearch.setOnLogoClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    mSearch.speak("Logo web disini");
                }
            });
        mSearch.setOnMicClickListener(new View.OnClickListener(){
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT, mContext.getString(R.string.speak_now));         
                    startActivityForResult(intent, VOICE_RECOGNITION_CODE); 
                    mSearch.speak("Please wait..");
                }
            });
        mSearch.setOverflowMenu(R.menu.menu_web_browser);
        mSearch.setOverflowMenuItemClickListener(new PopupMenu.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    switch (item.getItemId()) {
                        case R.id.action_history:
                            break;
                    }
                    return true;
                }
            });
        mSearch.setOnTextToSpeechListener(new SearchBox.OnTextToSpeechListener(){
                @Override
                public void onCommand(String command) {
                    setTextToSpeech(command);
                }
            });
        mSearch.setOnSearchListener(this);

    }

    @Override
    public void onSearchTextChanged(String keyword) {
        Toast.makeText(mContext, keyword, Toast.LENGTH_SHORT).show();      
        mSearchLayout.setTextView(keyword);
    }

    @Override
    public void onFocusChange(View v, boolean hasFocus) {
    }

    @Override
    public boolean onEditorAction(TextView arg0, int actionId, KeyEvent arg2) {
        return false;
    }

    @Override
    public void requestFocus() {
    }

    @Override
    public void refreshOrStop() {
    }

    public void setTextToSpeech(String command) {
        command = command.toLowerCase();
        if (command.indexOf("siapa") != -1) {
            if (command.indexOf("nama kamu") != -1) {
                mSearch.speak("Namaku Alexa");
            }
            if (command.indexOf("pencipta kamu") != -1) {
                mSearch.speak("Penciptaku adalah asepmo");
            }
            if (command.indexOf("asepmo itu") != -1) {
                mSearch.speak("Dialah Penciptaku.Jika anda ingin tahu lebih jelas lagi silahkan klik salah satu link yang tertera berikut ini...");
            }
            if (command.indexOf("asepmo") != -1) {
                mSearch.speak("Dialah Penciptaku.Jika anda ingin tahu lebih jelas lagi silahkan klik salah satu link yang tertera berikut ini...");
            }
        } else if (command.indexOf("kapan") != -1) {
            if (command.indexOf("kamu diciptakan") != -1) {
                mSearch.speak("beberapa tahun yang lalu.tepatnya tanggal 13 mei 2021");
            }
            if (command.indexOf("asepmo lahir") != -1) {
                mSearch.speak("beberapa tahun yang lalu.tepatnya tanggal 13 mei 2021");
            }
            if (command.indexOf("asepmo itu") != -1) {
                mSearch.speak("Dialah Penciptaku.Jika anda ingin tahu lebih jelas lagi silahkan klik salah satu link yang tertera berikut ini...");
            }
            if (command.indexOf("asepmo") != -1) {
                mSearch.speak("Dialah Penciptaku.Jika anda ingin tahu lebih jelas lagi silahkan klik salah satu link yang tertera berikut ini...");
            }
        } else if (command.indexOf("jam") != -1) {
            if (command.indexOf("berapa sekarang") != -1) {
                Date now = new Date();
                String time = DateUtils.formatDateTime(mContext, now.getTime(), DateUtils.FORMAT_SHOW_TIME);
                mSearch.speak("Sekarang Jam " + time);
            }
            if (command.indexOf("berapa dia akan datang") != -1) {
                mSearch.speak("menurut percakapan kamu dan dia kemarin. kira-kira dia akan datang jam dua belas siang.mungkin dia akan telat karena ada beberapa hal yang mungkin terjadi  ");
            }
        } else if (command.indexOf("tanggal") != -1) {
            if (command.indexOf("berapa sekarang") != -1) {
                Date now = new Date();
                String date = DateUtils.formatDateTime(mContext, now.getDate(), DateUtils.FORMAT_SHOW_DATE);
                mSearch.speak("Sekarang hari " + date);
            }
        } else if (command.indexOf("open") != -1) {
            if (command.indexOf("browser") != -1) {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=AnNJPf-4T70"));
                mContext.startActivity(intent);
            }
        } else if (command.equalsIgnoreCase("siapa asepmo itu")) {
            mSearch.speak("Dialah Penciptaku.Jika anda ingin tahu lebih jelas lagi silahkan klik salah satu link yang tertera berikut ini...");
        } else {
            mSearch.speak("Pencarian Dimulai Dengan Keyword " + command);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.i(TAG, "onResume()");
        mSearch.initTextToSpeech(mContext, new SearchBox.OnReadyListener(){
                @Override
                public void onReady() {
                    mSearchLayout.setStatus(SearchBoxLayout.Status.WEBVIEW);
                }

            });
            
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.i(TAG, "onPause()");
        mSearch.onPause();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == VOICE_RECOGNITION_CODE && resultCode == Activity.RESULT_OK) {
            ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            mSearch.populateEditText(matches.get(0));
        }
        super.onActivityResult(requestCode, resultCode, data);
    }
}
