package com.web.client.receiver;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;

import com.web.client.engine.app.utils.NetUtil;

public class NetworkBroadcastReceiver extends BroadcastReceiver {
    private NetworkListener mNetworkListener;
    private IntentFilter mIntentFilter;

    public NetworkBroadcastReceiver() {
        
    }

    public void setIntentFilter(){
        mIntentFilter = new IntentFilter();
        mIntentFilter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
    }
    
    public void setNetworkListener(NetworkListener changeListener){
        this.mNetworkListener = changeListener;
    }
    
    @Override
    public void onReceive(Context context, Intent intent) {
        if (mNetworkListener == null) {
            return;
        }

        if (intent.getAction() != null
            && intent.getAction().equals(ConnectivityManager.CONNECTIVITY_ACTION)) {
            boolean isNetworkAvailable = NetUtil.isNetworkAvailable(context);
            if (isNetworkAvailable) {
                mNetworkListener.onNetworkState(NetworkState.CONNECTED);
            } else {
                mNetworkListener.onNetworkState(NetworkState.DISCONNECTED);
            }
        }
    }

    public IntentFilter getIntentFilter() {
        return mIntentFilter;
    }

    public interface NetworkListener {
        void onNetworkState(NetworkState networkState);
    }

    public enum NetworkState {
        CONNECTED,
        DISCONNECTED,
        NOTHING
        }
}

