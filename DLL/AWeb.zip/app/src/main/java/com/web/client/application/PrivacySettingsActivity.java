package com.web.client.application;

public class PrivacySettingsActivity {
    
}
