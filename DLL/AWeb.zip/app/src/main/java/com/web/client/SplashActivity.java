package com.web.client;

import android.annotation.TargetApi;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.content.ContextCompat;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Bundle;
import android.os.Build;
import android.os.Handler;
import android.view.WindowManager;
import android.widget.ImageView;

import java.io.File;
import java.util.List;
import java.util.ArrayList;

import com.web.client.application.Application;
import com.web.client.application.ApplicationActivity;
import com.web.client.application.AppSettingsActivity;
import com.web.client.application.ThemableActivity;
import com.web.client.engine.Themes;
import com.web.client.engine.app.models.VideoData;
import com.web.client.engine.app.folders.FileMe;
import com.web.client.engine.app.folders.FolderMe;
import com.web.client.engine.app.settings.Settings;
import com.web.client.engine.graphics.SystemBarTintManager;
import com.web.client.engine.widget.soundPool.SoundPoolManager;

public class SplashActivity extends ThemableActivity {

    public static String TAG = SplashActivity.class.getSimpleName();
    
    private ImageView mCover;
    private Handler mHandler = new Handler();
    private Runnable mRunner = new Runnable(){
        @Override
        public void run() {
            ApplicationActivity.start(SplashActivity.this);
            SplashActivity.this.finish();
        }
    };
    private Application mApplication;

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        setTheme(R.style.AppTheme_NoActionBar);
        if (Themes.hasLollipop())
        {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        }
        else if (Themes.hasKitKat())
        {
            setTheme(R.style.AppTheme_Translucent);
        }
        setUpStatusBar();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mCover = (ImageView)findViewById(R.id.splash_image);
        mApplication = Application.with(this);
        mApplication.setPermission(this, Application.requestPermissionStorage, new Application.OnActionPermissionListener(){
                @Override
                public void onGranted() {
                    setTask();
                }

                @Override
                public void onDenied(String permission) {

                }
            });
            changeActionBarColor();
    }

    public void setTask() {
        Application.getInstance().setApplicationTaskListener(this, new Application.OnApplicationTaskListener(){
                @Override
                public void onPreExecute() {
                    FileMe fileMe = FileMe.with(SplashActivity.this);
                    fileMe.ScriptMe(FolderMe.EXTERNAL_DIR + "/"+ getString(R.string.app_name), getString(R.string.app_name) + ".dat", "Welcome To " + getString(R.string.app_name));
                   /* if(fileMe.isExists())
                    fileMe.WebMe(FolderMe.FOLDER_WEB_EDITOR, FileMe.INDEX_HTML, "<h2>Welcome To AndroWeb</h2>");*/

                    SoundPoolManager.getInstance().playSound(R.raw.add);
                }

                @Override
                public void onFailed() {

                }

                @Override
                public void isEmpty() {

                }
                @Override
                public void onSuccess(ArrayList<VideoData> result) {
                    SoundPoolManager.getInstance().playSound(R.raw.done);
                    
                    mHandler.postDelayed(mRunner, 100);
                }

            });
    }

    @Override
    protected void onPause() {
        super.onPause();
        mHandler.removeCallbacks(mRunner);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(mRunner);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        Application.getInstance().onRequestPermissionsResult(requestCode, permissions, grantResults);
    }


    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void setUpStatusBar()
    {
        // TODO: Implement this method
        int color = Themes.getStatusBarColor(AppSettingsActivity.getPrimaryColor(this));
        if (Themes.hasLollipop())
        {
            getWindow().setStatusBarColor(color);
        }
        else if (Themes.hasKitKat())
        {
            SystemBarTintManager systemBarTintManager = new SystemBarTintManager(this);
            systemBarTintManager.setTintColor(color);
            systemBarTintManager.setStatusBarTintEnabled(true);
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void setUpDefaultStatusBar()
    {
        // TODO: Implement this method
        int color = ContextCompat.getColor(this, R.color.alertColor);
        if (Themes.hasLollipop())
        {
            getWindow().setStatusBarColor(color);
        }
        else if (Themes.hasKitKat())
        {
            SystemBarTintManager systemBarTintManager = new SystemBarTintManager(this);
            systemBarTintManager.setTintColor(Themes.getStatusBarColor(color));
            systemBarTintManager.setStatusBarTintEnabled(true);
        }
    }
    
    private Drawable oldBackground;
    private void changeActionBarColor()
    {

        int color = AppSettingsActivity.getPrimaryColor(this);
        Drawable colorDrawable = new ColorDrawable(color);

        if (oldBackground == null)
        {
            getSupportActionBar().setBackgroundDrawable(colorDrawable);
        }
        else
        {
            TransitionDrawable td = new TransitionDrawable(new Drawable[] { oldBackground, colorDrawable });
            getSupportActionBar().setBackgroundDrawable(td);
            td.startTransition(200);
        }

        oldBackground = colorDrawable;

        setUpStatusBar();
    }

    @Override
    public String getTag()
    {
        // TODO: Implement this method
        return TAG;
	}
}

