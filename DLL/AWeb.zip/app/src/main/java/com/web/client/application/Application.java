package com.web.client.application;

import android.Manifest;
import android.support.annotation.Nullable;
import android.support.annotation.NonNull;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.view.Gravity;
import android.widget.Toast;

import java.io.File;
import java.util.List;
import java.util.ArrayList;

import com.web.client.R;
import com.web.client.AppController;
import com.web.client.engine.app.folders.FileMe;
import com.web.client.engine.app.folders.FolderMe;
import com.web.client.engine.app.models.VideoData;
import com.web.client.engine.app.tasks.VideoTask;
import com.web.client.engine.app.permissions.PermissionsManager;
import com.web.client.engine.app.permissions.PermissionsResultAction;
import com.web.client.engine.widget.soundPool.SoundPoolManager;
import com.web.client.engine.app.settings.Settings;

public class Application {
    private static final String TAG = Application.class.getSimpleName();
    private static volatile Application Instance = null;
    private Context context;

    public static Application getInstance() {
        Application localInstance = Instance;
        if (localInstance == null) {
            synchronized (Application.class) {
                localInstance = Instance;
                if (localInstance == null) {
                    Instance = localInstance = new Application(AppController.getContext());
                }
            }
        }
        return localInstance;
    }

    private Application(Context context) {
        this.context = context;
        FolderMe.initFolderMe(context);
    }

    public static Application with(Context context) {
        return new Application(context);
    }
    
    public void setPermission(Activity act, String[] permissions, final OnActionPermissionListener mOnActionPermissionListener) {      
        PermissionsManager.getInstance().requestPermissionsIfNecessaryForResult(act, permissions, new PermissionsResultAction() {
                @Override
                public void onGranted() {
                    mOnActionPermissionListener.onGranted();
                }


                @Override
                public void onDenied(String permission) {
                    mOnActionPermissionListener.onDenied(permission);
                }
            });
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,  @NonNull int[] grantResults) {
        Log.i(TAG, "Activity-onRequestPermissionsResult() PermissionsManager.notifyPermissionsChange()");
        PermissionsManager.getInstance().notifyPermissionsChange(permissions, grantResults);
    }
    
    public void setApplicationTaskListener(final Activity act, final OnApplicationTaskListener listener) {

        VideoTask task = new VideoTask(act);
        task.setOnVideoTaskListener(new VideoTask.OnVideoTaskListener(){
                @Override
                public void onPreExecute() {
                    listener.onPreExecute();
                }
                @Override
                public void onSuccess(ArrayList<VideoData> result) {
                    listener.onSuccess(result); 
                }

                @Override
                public void onFailed() {
                    listener.onFailed(); 
                } 

                @Override
                public void isEmpty() {
                    listener.isEmpty();
                } 
            });
        task.execute();    
    }
    
    public void checkRegistration(final Activity c){
          new Thread(new Runnable() {
            @Override
            public void run() {
                SystemClock.sleep(1000);
                // Now change the color back. Needs to be done on the UI thread
                c.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if(Settings.getLoginStatus())
                            c.startActivity(new Intent(c, ApplicationActivity.class));
                        else
                            c.startActivity(new Intent(c, Authenticate.class));
                       c.finish();
                    }
                });
            }
        }).start();
    }
    
    public void soundPlay(int sound) {
        SoundPoolManager.getInstance().playSound(sound);
    }


    public void soundRelease() {
        SoundPoolManager.getInstance().release();
    }
    
    
    public static String[] requestPermissionConnection = new String[]
    {
        Manifest.permission.INTERNET,
        Manifest.permission.ACCESS_NETWORK_STATE,
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.CHANGE_NETWORK_STATE,
        Manifest.permission.CHANGE_WIFI_STATE
    };

    public static String[] requestPermissionStorage = new String[]
    {
        Manifest.permission.INTERNET,
        Manifest.permission.ACCESS_NETWORK_STATE,
        Manifest.permission.ACCESS_WIFI_STATE,
        Manifest.permission.READ_EXTERNAL_STORAGE,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
    };
    
    public void exitApplication(Context c) {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(intent);
    }

    public interface OnActionPermissionListener {
        void onGranted();
        void onDenied(String permission);
    }

    public interface OnApplicationTaskListener {
        void onPreExecute();
        void onSuccess(ArrayList<VideoData> result);
        void onFailed();
        void isEmpty();
    }
}

