package com.web.client.engine.app.utils;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StringRes;
import android.support.design.widget.Snackbar;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Map;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.List;
import java.net.URI;
import java.net.URISyntaxException;

import com.web.client.R;
import com.web.client.engine.app.config.Constants;
import com.web.client.engine.app.models.HistoryItem;
import com.web.client.engine.app.download.DownloadHandler;

public class Utils {
    
    public static final String TAG = Utils.class.getSimpleName();
    private Utils() {
    }

    private static Map<String, Typeface> cachedFontMap = new HashMap<String, Typeface>();

    public static int pxToSp(final Context context, final float px) {
        return Math.round(px / context.getResources().getDisplayMetrics().scaledDensity);
    }

    public static int spToPx(final Context context, final float sp) {
        return Math.round(sp * context.getResources().getDisplayMetrics().scaledDensity);
    }

    public static Typeface findFont(Context context, String fontPath, String defaultFontPath){

        if (fontPath == null){
            return Typeface.DEFAULT;
        }

        String fontName = new File(fontPath).getName();
        String defaultFontName = "";
        if (!TextUtils.isEmpty(defaultFontPath)){
            defaultFontName = new File(defaultFontPath).getName();
        }

        if (cachedFontMap.containsKey(fontName)){
            return cachedFontMap.get(fontName);
        }else{
            try{
                AssetManager assets = context.getResources().getAssets();

                if (Arrays.asList(assets.list("")).contains(fontPath)){
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), fontName);
                    cachedFontMap.put(fontName, typeface);
                    return typeface;
                }else if (Arrays.asList(assets.list("fonts")).contains(fontName)){
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), String.format("fonts/%s",fontName));
                    cachedFontMap.put(fontName, typeface);
                    return typeface;
                }else if (Arrays.asList(assets.list("iconfonts")).contains(fontName)){
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), String.format("iconfonts/%s",fontName));
                    cachedFontMap.put(fontName, typeface);
                    return typeface;
                }else if (!TextUtils.isEmpty(defaultFontPath) && Arrays.asList(assets.list("")).contains(defaultFontPath)){
                    Typeface typeface = Typeface.createFromAsset(context.getAssets(), defaultFontPath);
                    cachedFontMap.put(defaultFontName, typeface);
                    return typeface;
                } else {
                    throw new Exception("Font not Found");
                }

            }catch (Exception e){
                Log.e(TAG, String.format("Unable to find %s font. Using Typeface.DEFAULT instead.", fontName));
                cachedFontMap.put(fontName, Typeface.DEFAULT);
                return Typeface.DEFAULT;
            }
        }
    }
    
    public static void downloadFile(final Activity activity, final String url,
                                    final String userAgent, final String contentDisposition, final boolean privateBrowsing) {
        String fileName = URLUtil.guessFileName(url, null, null);
        DownloadHandler.onDownloadStart(activity, url, userAgent, contentDisposition, null,
                                        privateBrowsing);
        Log.i(Constants.TAG, "Downloading" + fileName);
    }

    public static Intent newEmailIntent(Context context, String address, String subject,
                                        String body, String cc) {
        Intent intent = new Intent(Intent.ACTION_SEND);
        intent.putExtra(Intent.EXTRA_EMAIL, new String[] { address });
        intent.putExtra(Intent.EXTRA_TEXT, body);
        intent.putExtra(Intent.EXTRA_SUBJECT, subject);
        intent.putExtra(Intent.EXTRA_CC, cc);
        intent.setType("message/rfc822");
        return intent;
    }

    public static void createInformativeDialog(Context context, String title, String message) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        builder.setTitle(title);
        builder.setMessage(message)
            .setCancelable(true)
            .setPositiveButton(context.getResources().getString(android.R.string.ok),
            new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                }
            });
        AlertDialog alert = builder.create();
        alert.show();
    }

    public static void showToast(Context context, String message) {
        Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
    }
    
    public static void showSnackbar(@NonNull Activity activity, @StringRes int resource) {
        View view = activity.findViewById(android.R.id.content);
        if (view == null) {
            Log.e(TAG, "showSnackbar", new NullPointerException("Unable to find android.R.id.content"));
            return;
        }
        Snackbar.make(view, resource, Snackbar.LENGTH_SHORT).show();
    }

    /**
     * Displays a snackbar to the user with a string message.
     * <p>
     * NOTE: If there is an accessibility manager enabled on
     * the device, such as LastPass, then the snackbar animations
     * will not work.
     *
     * @param activity the activity needed to create a snackbar.
     * @param message  the string message to show to the user.
     */
    public static void showSnackbar(@NonNull Activity activity, @NonNull String message) {
        View view = activity.findViewById(android.R.id.content);
        if (view == null) {
            Log.e(TAG, "showSnackbar", new NullPointerException("Unable to find android.R.id.content"));
            return;
        }
        Snackbar.make(view, message, Snackbar.LENGTH_SHORT).show();
    }
    
    /**
     * Returns the number of pixels corresponding to the passed density pixels
     */
    public static int convertToDensityPixels(Context context, int densityPixels) {
        float scale = context.getResources().getDisplayMetrics().density;
        return (int) (densityPixels * scale + 0.5f);
    }

    public static String getDomainName(String url) {
        URI uri;
        try {
            uri = new URI(url);
        } catch (URISyntaxException e) {
            return url;
        }
        String domain = uri.getHost();
        if (domain == null) {
            return url;
        }
        return domain.startsWith("www.") ? domain.substring(4) : domain;
    }

    public static List<HistoryItem> getOldBookmarks(Context context) {
        List<HistoryItem> bookmarks = new ArrayList<HistoryItem>();
        File bookUrl = new File(context.getFilesDir(), "bookurl");
        File book = new File(context.getFilesDir(), "bookmarks");
        try {
            BufferedReader readUrl = new BufferedReader(new FileReader(bookUrl));
            BufferedReader readBook = new BufferedReader(new FileReader(book));
            String u, t;
            while ((u = readUrl.readLine()) != null && (t = readBook.readLine()) != null) {
                HistoryItem map = new HistoryItem(u, t, R.drawable.ic_bookmark);
                bookmarks.add(map);
            }
            readBook.close();
            readUrl.close();
        } catch (FileNotFoundException ignored) {
        } catch (IOException ignored) {
        }
        return bookmarks;
    }

    public static String[] getArray(String input) {
        return input.split("\\|\\$\\|SEPARATOR\\|\\$\\|");
    }

    public static void trimCache(Context context) {
        try {
            File dir = context.getCacheDir();

            if (dir != null && dir.isDirectory()) {
                deleteDir(dir);
            }
        } catch (Exception ignored) {

        }
    }

    public static boolean deleteDir(File dir) {
        if (dir != null && dir.isDirectory()) {
            String[] children = dir.list();
            for (String aChildren : children) {
                boolean success = deleteDir(new File(dir, aChildren));
                if (!success) {
                    return false;
                }
            }
        }
        // The directory is now empty so delete it
        return dir != null && dir.delete();
    }
   
}
