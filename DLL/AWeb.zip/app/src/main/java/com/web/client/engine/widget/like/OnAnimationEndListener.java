package com.web.client.engine.widget.like;

public interface OnAnimationEndListener {
    void onAnimationEnd(LikeButton likeButton);
}
