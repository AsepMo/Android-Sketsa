package com.web.client.engine.app.crashes.action;

import com.web.client.engine.app.core.investigation.CrashViewModel;
import com.web.client.engine.app.crashes.viewmodel.AppInfoViewModel;

public interface CrashActions {
  void openSendApplicationChooser(String crashDetails);

  void renderAppInfo(AppInfoViewModel viewModel);

  void render(CrashViewModel viewModel);
}
