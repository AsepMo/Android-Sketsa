package com.web.client.engine.app.server.web;

public class Intents {
	public static final String ACTION_SERVER_STATE_CHANGE = "com.aweb.client.action.SERVER_STATE_CHANGE";
	public static final String ACTION_RESTART_SERVER="com.aweb.client.action.RESTART_SERVER";
}
