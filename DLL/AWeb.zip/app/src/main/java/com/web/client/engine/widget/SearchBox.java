package com.web.client.engine.widget;

import android.support.annotation.MenuRes;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.annotation.TargetApi;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Fragment;
import android.content.Intent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.ClipboardManager;
import android.content.ClipData;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.os.Build;
import android.os.Handler;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.View.OnLongClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.MotionEvent;
import android.view.KeyEvent;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.RelativeLayout;
import android.widget.FrameLayout;
import android.widget.ListView;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.TextView.OnEditorActionListener;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.Locale;

import com.web.client.R;
import com.web.client.application.BrowserActivity;
import com.web.client.engine.app.utils.Utils;
import android.widget.BaseAdapter;
import com.web.client.engine.app.adapters.SearchAdapter;

public class SearchBox extends RelativeLayout implements View.OnClickListener {

    public static String TAG = SearchBox.class.getSimpleName();
    public static final int VOICE_RECOGNITION_CODE = 1234;

    private Uri mSource;
    private Handler mHandler;
    private AutoCompleteTextView mSearch;
    private ImageView mIconWeb;
    private ImageView mIconMic;
    private ImageView mIconMenu;
    private PopupMenu popupMenu;
    private String[] nameList = {"Abhishek","Anad","Anurag","Avni","Bindiya","Bunny","Ban","Chandni","Champ","Charu","Dax","Dhruva",
        "Milan","Mayur","Mohit","Payal","Priti","Prachi","Kajal","Krisha","Kriva","Kishan","Kaushik","Hetal","Hina","Rahul","Rutvi",
        "Rutvik","Sneha","Shreya","Sarika","Zen"};

    private Drawable mDeleteIcon;
    private Drawable mRefreshIcon;
    private Drawable mCopyIcon;
    private Drawable mIcon;
    private boolean isVoiceRecognitionIntentSupported;
    
    private TextToSpeech myTTS;
    private OnSearchListener mOnSearchListener;
    private OnTextToSpeechListener mOnTextToSpeechListener;
    
    public static final String CALCULATOR_PACKAGE ="com.android.calculator2";
    public static final String CALCULATOR_CLASS ="com.android.calculator2.Calculator";

    private Context mContext;
    private Activity mActivity;
    
    private View.OnClickListener mOnIconWebClickListener;
    private View.OnClickListener mOnIconMicClickListener;

    public SearchBox(Context context) {
        super(context);
        init(context, null);
    }

    public SearchBox(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public SearchBox(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {
        setBackgroundColor(Color.BLACK);
        mContext = context;
        mActivity = (Activity)context;
        isVoiceRecognitionIntentSupported = isIntentAvailable(mActivity, new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)); 

        if (attrs != null) {
            TypedArray a = context.getTheme().obtainStyledAttributes(attrs, R.styleable.SearchBox, 0, 0);
            try {

                String source = a.getString(R.styleable.SearchBox_sb_url);
                if (source != null && !source.trim().isEmpty())
                    mSource = Uri.parse(source);
            } catch (Exception e) {
                Log.i(TAG, "Exception " + e.getMessage());
                e.printStackTrace();
            } finally {
                a.recycle();
            }
        } else {

        }     
    }


    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        setKeepScreenOn(true);

        mHandler = new Handler();

        final LayoutInflater li = LayoutInflater.from(getContext());
        View mFrame = li.inflate(R.layout.layout_search_box, this, false);
        addView(mFrame);

        mIconWeb = (ImageView) mFrame.findViewById(R.id.item_search_icon);   
        mIconMic = (ImageView) mFrame.findViewById(R.id.item_mic_icon);     
        mIconMenu = (ImageView) mFrame.findViewById(R.id.item_menu_icon);     

        mSearch = (AutoCompleteTextView) mFrame.findViewById(R.id.search);
        mSearch.setHintTextColor(Color.GRAY);
        mDeleteIcon = getResources().getDrawable(R.drawable.ic_action_delete);
        mDeleteIcon.setBounds(0, 0, Utils.convertToDensityPixels(mContext, 24),
                              Utils.convertToDensityPixels(mContext, 24));
        mRefreshIcon = getResources().getDrawable(R.drawable.ic_action_refresh);
        mRefreshIcon.setBounds(0, 0, Utils.convertToDensityPixels(mContext, 24),
                               Utils.convertToDensityPixels(mContext, 24));
        mCopyIcon = getResources().getDrawable(R.drawable.ic_action_copy);
        mCopyIcon.setBounds(0, 0, Utils.convertToDensityPixels(mContext, 24),
                            Utils.convertToDensityPixels(mContext, 24));
        mIcon = mRefreshIcon;
        mSearch.setCompoundDrawables(null, null, mRefreshIcon, null);
        /*StringBuilder editText = new StringBuilder();
        editText.append("Input Value:").append("\n");

        for (String value: nameList) {
            editText.append(value).append(", ");
        }

       // ArrayAdapter adapter = new ArrayAdapter(mContext, android.R.layout.simple_list_item_1, nameList);
       // mSearch.setAdapter(adapter);*/
        mSearch.setThreshold(1);//start searching from 1 character
        mSearch.setOnKeyListener(new OnKeyListener() {

                @Override
                public boolean onKey(View arg0, int arg1, KeyEvent arg2) {

                    switch (arg1) {
                        case KeyEvent.KEYCODE_ENTER:
                            InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                            imm.hideSoftInputFromWindow(mSearch.getWindowToken(), 0);
                            setSearchText(mSearch.getText().toString());
                            if (mOnSearchListener != null) {
                                mOnSearchListener.onSearchTextChanged(getSearchText());
                            }
                            if (mOnTextToSpeechListener != null) {
                                mOnTextToSpeechListener.onCommand(getSearchText());
                            }
                            return true;
                        default:
                            break;
                    }
                    return false;
                }

            });

        mSearch.setOnFocusChangeListener(new View.OnFocusChangeListener() {

                @Override
                public void onFocusChange(View v, boolean hasFocus) {
                    if (!hasFocus && mOnSearchListener != null) {
                        if (mOnSearchListener != null) {
                            mOnSearchListener.onFocusChange(v, hasFocus);
                        }   
                    } else if (hasFocus) {
                        mIcon = mCopyIcon;
                        mSearch.setCompoundDrawables(null, null, mCopyIcon, null);
                    }           
                }
            });
        mSearch.setOnEditorActionListener(new OnEditorActionListener() {

                @Override
                public boolean onEditorAction(TextView arg0, int actionId, KeyEvent arg2) {
                    // hide the keyboard and search the web when the enter key
                    // button is pressed
                    if (actionId == EditorInfo.IME_ACTION_GO || actionId == EditorInfo.IME_ACTION_DONE
                        || actionId == EditorInfo.IME_ACTION_NEXT
                        || actionId == EditorInfo.IME_ACTION_SEND
                        || actionId == EditorInfo.IME_ACTION_SEARCH
                        || (arg2.getAction() == KeyEvent.KEYCODE_ENTER)) {
                        InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(mSearch.getWindowToken(), 0);
                        setSearchText(mSearch.getText().toString());
                        if (mOnSearchListener != null) {
                                mOnSearchListener.onSearchTextChanged(getSearchText());
                        }
                        if (mOnSearchListener != null) {
                            mOnSearchListener.onEditorAction(arg0, actionId, arg2);
                        }
                        if (mOnTextToSpeechListener != null) {
                            mOnTextToSpeechListener.onCommand(getSearchText());
                        }
                        return true;
                    }
                    return false;
                }

            });

        mSearch.setOnTouchListener(new OnTouchListener() {

                @SuppressLint("ClickableViewAccessibility")
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    if (mSearch.getCompoundDrawables()[2] != null) {
                        boolean tappedX = event.getX() > (mSearch.getWidth() - mSearch.getPaddingRight() - mIcon.getIntrinsicWidth());
                        if (tappedX) {
                            if (event.getAction() == MotionEvent.ACTION_UP) {
                                if (mSearch.hasFocus()) {
                                    ClipboardManager clipboard = (ClipboardManager) mContext.getSystemService(Context.CLIPBOARD_SERVICE);
                                    ClipData clip = ClipData.newPlainText("label", mSearch.getText().toString());

                                    clipboard.setPrimaryClip(clip);
                                    Utils.showToast(mContext, mContext.getResources().getString(R.string.message_text_copied));
                                } else {
                                    if (mOnSearchListener != null) {
                                        mOnSearchListener.refreshOrStop();
                                    }
                                }
                            }
                            return true;
                        }
                    }
                    return false;
                }

            });
        mIconWeb.setOnClickListener(this);
        mIconMic.setOnClickListener(this);
        mIconMenu.setOnClickListener(this);
        Thread initialize = new Thread(new Runnable() {

                @Override
                public void run() {
                    initializeSearchSuggestions(mSearch);
                }

            });
        initialize.run();
    }

    private void initializeSearchSuggestions(final AutoCompleteTextView getUrl) {

        getUrl.setThreshold(1);
        getUrl.setDropDownWidth(-1);
        getUrl.setDropDownAnchor(R.id.progressWrapper);
        getUrl.setOnItemClickListener(new OnItemClickListener() {

                @Override
                public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
                    try {
                        String url;
                        url = ((TextView) arg1.findViewById(R.id.url)).getText().toString();
                        if (url.startsWith(mContext.getString(R.string.web_browser_suggestion))) {
                            url = ((TextView) arg1.findViewById(R.id.title)).getText().toString();
                        } else {
                            getUrl.setText(url);
                        }
                        setSearchText(url);
                        url = null;
                        InputMethodManager imm = (InputMethodManager) mContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                        imm.hideSoftInputFromWindow(getUrl.getWindowToken(), 0);
                        if (mOnSearchListener != null) {
                            mOnSearchListener.requestFocus();
                        }
                    } catch (NullPointerException e) {
                        Log.e("Browser Error: ", "NullPointerException on item click");
                    }
                }

            });

        getUrl.setSelectAllOnFocus(true);
        SearchAdapter mSearchAdapter = new SearchAdapter(mContext, false);
        getUrl.setAdapter(mSearchAdapter);
    }
    
    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.item_search_icon:
                if (mOnIconWebClickListener != null) {
                    mOnIconWebClickListener.onClick(v);
                }
                //mContext.startActivity(new Intent(mContext, BrowserActivity.class));
                break;
            case R.id.item_mic_icon:
                if (mOnIconMicClickListener != null) {
                    mOnIconMicClickListener.onClick(v);
                }
                break;
            case R.id.item_menu_icon:
                popupMenu.show();
                break;      
        }
    }

    public static boolean isIntentAvailable(Context context, Intent intent) {
        PackageManager mgr = context.getPackageManager();
        if (mgr != null) {
            List<ResolveInfo> list = mgr.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
            return list.size() > 0;
        }
        return false;
	}

    /***
     * Start the voice input activity manually
     */
    public void startVoiceRecognition(Activity act) {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, mContext.getString(R.string.speak_now));         
        act.startActivityForResult(intent, VOICE_RECOGNITION_CODE);
    }

    public void setOverflowMenu(@MenuRes int overflowMenuResId) {
        mIconMenu.setVisibility(VISIBLE);
        popupMenu = new PopupMenu(mContext, mIconMenu);
        popupMenu.getMenuInflater().inflate(overflowMenuResId, popupMenu.getMenu());
    }

    public void setOverflowMenuItemClickListener(PopupMenu.OnMenuItemClickListener onMenuItemClickListener) {
        popupMenu.setOnMenuItemClickListener(onMenuItemClickListener);
    }
    /***
     * Set the searchbox's current text manually
     * @param text Text
     */
    public void setSearchText(String text) {
        mSearch.setText(text);
    }
    /***
     * Get the searchbox's current text
     * @return Text
     */
    public String getSearchText() {
        return mSearch.getText().toString();
	}
    /***
     * Populate the searchbox with words, in an arraylist. Used by the voice input
     * @param match Matches
     */
    public void populateEditText(String match) {
        setSearchText(match);
    }

    /***
     * Set the image drawable of the drawer icon logo (do not set if you have not hidden the menu icon)
     * @param icon Icon
     */
    public void setLogo(Drawable icon) {
        mIconWeb.setImageDrawable(icon);
        mIconWeb.setScaleType(ImageView.ScaleType.FIT_XY);
    }

    public void setLogo(Integer icon) {
        setLogo(getResources().getDrawable(icon));
    }

    public void setOnLogoClickListener(View.OnClickListener mOnClickListener) {
        this.mOnIconWebClickListener = mOnClickListener;
    }

    public void setOnMicClickListener(View.OnClickListener mOnClickListener) {
        this.mOnIconMicClickListener = mOnClickListener;
    }

    public void setOnSearchListener(OnSearchListener mOnSearchListener) {
        this.mOnSearchListener = mOnSearchListener;
    }
    
    public void setOnTextToSpeechListener(OnTextToSpeechListener mOnTextToSpeechListener) {
        this.mOnTextToSpeechListener = mOnTextToSpeechListener;
    }
    /***
     * Sets the hint for the Search Field
     * @param hint The hint for Search Field
     */
    public void setHint(String hint) {
        this.mSearch.setHint(hint);
    }
    /**
     * This method lets the search bar know that the page is currently loading
     * and that it should display the stop icon to indicate to the user that
     * pressing it stops the page from loading
     */
    public void setIsLoading() {
        if (!mSearch.hasFocus()) {
            mIcon = mDeleteIcon;
            mSearch.setCompoundDrawables(null, null, mDeleteIcon, null);
        }
    }

    /**
     * This tells the search bar that the page is finished loading and it should
     * display the refresh icon
     */
    public void setIsFinishedLoading() {
        if (!mSearch.hasFocus()) {
            mIcon = mRefreshIcon;
            mSearch.setCompoundDrawables(null, null, mRefreshIcon, null);
        }
    }

    public interface OnSearchListener {
        /**
         * Called when the menu button is pressed
         */
        public void onSearchTextChanged(String keyword);
        public void onFocusChange(View v, boolean hasFocus);
        public boolean onEditorAction(TextView arg0, int actionId, KeyEvent arg2);
        public void requestFocus();
        public void refreshOrStop();
	}

    public interface OnReadyListener {
        public void onReady();
    }
    public interface OnTextToSpeechListener {
        void onCommand(String command);
    }

    public void initTextToSpeech(final Context context, final OnReadyListener mOnReadyListener) {
        myTTS = new TextToSpeech(context, new TextToSpeech.OnInitListener() {
                @Override
                public void onInit(int i) {
                    if (myTTS.getEngines().size() == 0) {
                        Toast.makeText(context, "There is no TTS Engine in your device", Toast.LENGTH_SHORT).show();              
                    } else {
                        myTTS.setLanguage(Locale.getDefault());
                        speak("Ok Say Aku Sudah Siap nih");
                        mOnReadyListener.onReady();                    
                    }
                }
            });
    }

    public void speak(String message) {
        if (Build.VERSION.SDK_INT >= 21) {
            myTTS.speak(message, TextToSpeech.QUEUE_FLUSH, null, null);
        } else {
            myTTS.speak(message, TextToSpeech.QUEUE_FLUSH, null);
        }
    }

    public void onPause() {
        myTTS.shutdown();
    }
    
    /**
     * method to generate search suggestions for the AutoCompleteTextView from
     * previously searched URLs
     */
    public void initSearchSuggestions() {
    }
}
