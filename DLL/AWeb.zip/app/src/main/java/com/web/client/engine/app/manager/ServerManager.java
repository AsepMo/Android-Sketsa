package com.web.client.engine.app.manager;

public class ServerManager {
    
    public static String TAG = ServerManager.class.getSimpleName();
    
}
