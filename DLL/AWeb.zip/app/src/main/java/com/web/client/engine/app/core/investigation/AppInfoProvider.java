package com.web.client.engine.app.core.investigation;

public interface AppInfoProvider {
  AppInfo getAppInfo();
}
