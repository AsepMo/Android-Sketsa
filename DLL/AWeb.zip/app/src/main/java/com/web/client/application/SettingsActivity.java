package com.web.client.application;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.Toast;

import com.web.client.R;
import com.web.client.AppController;
import com.web.client.engine.app.fragments.WebSettingFragment;
import com.web.client.engine.app.settings.AppCompatPreferenceActivity;

public class SettingsActivity extends AppCompatPreferenceActivity {

    public static String TAG = SettingsActivity.class.getSimpleName();
    public static void startPreference(Context context) {
        Intent mApplication = new Intent(context, SettingsActivity.class);
        context.startActivity(mApplication);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // load settings fragment
        getFragmentManager().beginTransaction().replace(android.R.id.content, new WebSettingFragment()).commit();

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            onBackPressed();
        }
        return super.onOptionsItemSelected(item);
    }
    
    @Override
    public String getTag()
    {
        // TODO: Implement this method
        return TAG;
    }
}



