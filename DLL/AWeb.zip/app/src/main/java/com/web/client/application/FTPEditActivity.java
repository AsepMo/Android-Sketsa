package com.web.client.application;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;

import java.util.UUID;

import com.web.client.engine.app.fragments.FTPEditFragment;
import com.web.client.engine.app.server.ftp.FTP;

public class FTPEditActivity extends SingleFragmentActivity {

    private static final String EXTRA_FTP = "com.aweb.client";
	private static final String RETURN_STATE = "ftpState";

    public static Intent newIntent(Context packageContext, FTP ftp) {
        Intent intent = new Intent(packageContext, FTPEditActivity.class);
        intent.putExtra(EXTRA_FTP, ftp);
        return intent;
    }
	
    @Override
    protected Fragment createFragment() {
        FTP ftp = (FTP) getIntent()
                .getSerializableExtra(EXTRA_FTP);
        return FTPEditFragment.newInstance(ftp);
    }

}
