package com.web.client.engine.app.listeners;

import com.web.client.engine.widget.MaterialCheckbox;

public interface OnCheckedChangeListener {
    void onCheckedChanged(MaterialCheckbox checkbox, boolean isChecked);
}
