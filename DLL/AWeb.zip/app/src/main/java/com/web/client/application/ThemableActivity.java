package com.web.client.application;

import android.support.annotation.Nullable;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;

import com.web.client.engine.Themes;
import com.web.client.engine.app.analytics.AnalyticsManager;
import com.web.client.engine.app.settings.Settings;

public abstract class ThemableActivity extends AppCompatActivity {

    public abstract void setUpStatusBar();
    public abstract void setUpDefaultStatusBar();
    
    public static void startAction(Context c, Class<?> mClass) {
        Intent mIntent = new Intent(c, mClass);
        c.startActivity(mIntent);
    }
    
    //private int mCurrentTheme;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // get default preferences at start - we need this for setting the theme
        Settings.updatePreferences(this);
        Themes.changeThemeStyle(getDelegate());
        //mCurrentTheme = Settings.getDefaultTheme();
        //setTheme(mCurrentTheme);
        super.onCreate(savedInstanceState);
    }

    @Override
    protected void onResume() {
        super.onResume();
        /*if (mCurrentTheme != Settings.getDefaultTheme()) {
            restart();
        }*/
        AnalyticsManager.setCurrentScreen(this, getTag());
    }

    @Override
    public ActionBar getSupportActionBar() {
        return super.getSupportActionBar();
    }

    @Override
    public void recreate() {
        Themes.changeThemeStyle(getDelegate());
        super.recreate();
    }

    public abstract String getTag();
    
    protected void restart() {
        final Bundle outState = new Bundle();
        onSaveInstanceState(outState);
        final Intent intent = new Intent(this, getClass());
        finish();
        overridePendingTransition(0, 0);
        startActivity(intent);
    }
}
