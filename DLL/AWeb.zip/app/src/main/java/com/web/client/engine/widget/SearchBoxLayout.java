package com.web.client.engine.widget;

import android.app.Activity;
import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.web.client.R;

public class SearchBoxLayout extends RelativeLayout {

    public static String TAG = SearchBoxLayout.class.getSimpleName();
    /**
     * Current status of status view
     */
    private Status currentStatus;


    /**
     * Views for each status
     */
    private View webView;
    private View errorView;
    private View loadingView;
    private View readyView;

    /**
    *
    * Featured SearchBoxLayoit
    */
    private TextView mTextView;
    /**
     * Fade in out animations
     */
    private Animation slideOut;
    private Animation slideIn;

    /**
     * layout inflater
     */
    private LayoutInflater inflater;

    /**
     * Handler
     */
    private Handler handler;
    private String text;
    /**
     * Auto dismiss on complete
     */
    private Runnable autoDismissOnComplete = new Runnable() {
        @Override
        public void run() {
            exitAnimation(getCurrentView(currentStatus));
            handler.removeCallbacks(autoDismissOnComplete);
        }
    };

    public SearchBoxLayout(Context context) {
        super(context);
        init(context, null);
    }

    public SearchBoxLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public SearchBoxLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }

    private void init(Context context, AttributeSet attrs) {

        /**
         * Load initial values
         */
        currentStatus = Status.IDLE;

        slideIn = AnimationUtils.loadAnimation(context, android.R.anim.fade_in);
        slideOut = AnimationUtils.loadAnimation(context, android.R.anim.fade_out);
        inflater = LayoutInflater.from(context);
        handler = new Handler();

        /**
         * inflate layouts
         */
        webView = inflater.inflate(R.layout.layout_search_result, null);
        errorView = inflater.inflate(R.layout.layout_search_message, null);
        loadingView = inflater.inflate(R.layout.layout_search_loading, null);
        readyView = inflater.inflate(R.layout.layout_search_ready, null);

        /**
         * Default layout params
         */
        webView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        errorView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        loadingView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        readyView.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        /**
         * Add layout to root
         */
        addView(webView);
        addView(errorView);
        addView(loadingView);
        addView(readyView);

        /**
         * set visibilities of childs
         */
        webView.setVisibility(View.INVISIBLE);
        errorView.setVisibility(View.INVISIBLE);
        loadingView.setVisibility(View.INVISIBLE);
        readyView.setVisibility(View.INVISIBLE);
        
        /**
        *
        * set Featur SearchBoxLayout
        */
        
        mTextView = (TextView)webView.findViewById(R.id.web_search_result);
        
    }

    public void setTextView(String text){
        mTextView.setText(text);
        setStatus(SearchBoxLayout.Status.WEBVIEW);
    }
    
    public void setOnErrorClickListener(OnClickListener onErrorClickListener) {
        errorView.setOnClickListener(onErrorClickListener);
    }

    public void setOnLoadingClickListener(OnClickListener onLoadingClickListener) {
        loadingView.setOnClickListener(onLoadingClickListener);
    }

    public void setOnCompleteClickListener(OnClickListener onCompleteClickListener) {
        webView.setOnClickListener(onCompleteClickListener);
    }

    public void setOnReadyClickListener(OnClickListener onCompleteClickListener) {
        readyView.setOnClickListener(onCompleteClickListener);
    }
    
    public View getErrorView() {
        return errorView;
    }

    public View getCompleteView() {
        return webView;
    }

    public View getLoadingView() {
        return loadingView;
    }

    public View getReadyView() {
        return readyView;
    }
    
    public void setStatus(final Status status) {
        if (currentStatus == Status.IDLE) {
            currentStatus = status;
            enterAnimation(getCurrentView(currentStatus));
        } else if (status != Status.IDLE) {
            switchAnimation(getCurrentView(currentStatus), getCurrentView(status));
            currentStatus = status;
        } else {
            exitAnimation(getCurrentView(currentStatus));
        }

        handler.removeCallbacksAndMessages(null);
    }
    /**
     * 
     * @return Status object 
     */
    public Status getStatus() {
        return this.currentStatus;
    }

    private View getCurrentView(Status status) {
        if (status == Status.IDLE)
            return null;
        else if (status == Status.WEBVIEW)
            return webView;
        else if (status == Status.ERROR)
            return errorView;
        else if (status == Status.LOADING)
            return loadingView;
        else if (status == Status.READY)
            return readyView;     
        return null;
    }

    private void switchAnimation(final View exitView, final View enterView) {
        clearAnimation();
        exitView.setVisibility(View.VISIBLE);
        exitView.startAnimation(slideOut);
        slideOut.setAnimationListener(new SimpleAnimListener() {
                @Override
                public void onAnimationEnd(Animation animation) {
                    slideOut.setAnimationListener(null);
                    exitView.setVisibility(View.INVISIBLE);
                    enterView.setVisibility(View.VISIBLE);
                    enterView.startAnimation(slideIn);
                }
            });
    }

    private void enterAnimation(View enterView) {
        if (enterView == null)
            return;

        enterView.setVisibility(VISIBLE);
        enterView.startAnimation(slideIn);
    }

    private void exitAnimation(final View exitView) {
        if (exitView == null)
            return;

        exitView.startAnimation(slideOut);
        slideOut.setAnimationListener(new SimpleAnimListener() {
                @Override
                public void onAnimationEnd(Animation animation) {
                    currentStatus = Status.IDLE;
                    exitView.setVisibility(INVISIBLE);
                    slideOut.setAnimationListener(null);
                }
            });
    }

    public enum Status {
        IDLE, LOADING, ERROR, WEBVIEW, READY
        }

    public abstract class SimpleAnimListener implements Animation.AnimationListener {

        @Override
        public void onAnimationRepeat(Animation animation) {

        }

        @Override
        public void onAnimationStart(Animation animation) {

        }
    }
}
