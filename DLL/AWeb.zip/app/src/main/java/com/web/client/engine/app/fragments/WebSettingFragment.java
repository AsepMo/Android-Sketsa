package com.web.client.engine.app.fragments;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.Preference;
import android.preference.PreferenceFragment;
import android.preference.PreferenceManager;
import android.preference.RingtonePreference;
import android.text.TextUtils;
import android.widget.Toast;

import com.web.client.R;
import com.web.client.engine.app.settings.Settings;
import com.web.client.engine.app.server.web.Intents;
import com.web.client.AppController;

public class WebSettingFragment extends PreferenceFragment {
    
    public static String TAG = WebSettingFragment.class.getSimpleName();
    private static final String KEY_SERVER_PORT = "key_server_port";
        private static final String KEY_VERSION = "prdference_version";

        private Context mContext;
        private EditTextPreference preferencePort;
        
        @Override
        public void onCreate(final Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            addPreferencesFromResource(R.xml.pref_main);

            Settings.updatePreferences(AppController.getContext());
            preferencePort = (EditTextPreference) findPreference(KEY_SERVER_PORT);
            if (preferencePort != null) {
                preferencePort.setOnPreferenceChangeListener(onPreference);
                updatePreferences();
            }

            Preference preferenceVersion = findPreference(KEY_VERSION);
            mContext = preferenceVersion.getContext();
            if (preferenceVersion != null) {
                try {
                    preferenceVersion.setSummary(mContext.getPackageManager().getPackageInfo(mContext.getPackageName(), 0).versionName);
                } catch (Exception e) {

                }
            }

            // Default Port EditText change listener
            bindPreferenceSummaryToValue(findPreference(KEY_SERVER_PORT));

            // DefaultDir EditText change listener
            bindPreferenceSummaryToValue(findPreference(getString(R.string.key_default_storage)));

            // notification preference change listener
            bindPreferenceSummaryToValue(findPreference(getString(R.string.key_notifications_new_message_ringtone)));

            // feedback preference click listener
            Preference myPref = findPreference(getString(R.string.key_send_feedback));
            myPref.setOnPreferenceClickListener(new Preference.OnPreferenceClickListener() {
                    public boolean onPreferenceClick(Preference preference) {
                        sendFeedback(getActivity());
                        return true;
                    }
                });               
        }

        private Preference.OnPreferenceChangeListener onPreference = new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                String stringValue = newValue.toString();
                if (preference.getKey().equals(KEY_SERVER_PORT)) {
                    int port = Integer.parseInt(stringValue);
                    if (port < 1024 || port > 65535) {
                        Toast.makeText(preference.getContext(), R.string.web_server_port_invalid,
                                       Toast.LENGTH_SHORT).show();
                    } else {
                        Settings.setPort(port);
                        updatePreferences();
                        Intent intent = new Intent(Intents.ACTION_RESTART_SERVER);
                        preference.getContext().sendBroadcast(intent);

                    }

                }
                return false;
            }
        };

        private void updatePreferences() {
            if (preferencePort != null) {
                preferencePort.setText(String.valueOf(Settings.getPort()));
                preferencePort.setSummary(getResources().getString(R.string.web_server_port_summary, Settings.getPort()));
            }
        }
        
        private void bindPreferenceSummaryToValue(Preference preference) {
            preference.setOnPreferenceChangeListener(sBindPreferenceSummaryToValueListener);

            sBindPreferenceSummaryToValueListener.onPreferenceChange(preference,
                                                                     PreferenceManager
                                                                     .getDefaultSharedPreferences(preference.getContext())
                                                                     .getString(preference.getKey(), ""));
        }

        /**
         * A preference value change listener that updates the preference's summary
         * to reflect its new value.
         */
        private Preference.OnPreferenceChangeListener sBindPreferenceSummaryToValueListener = new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                String stringValue = newValue.toString();

                if (preference instanceof ListPreference) {
                    // For list preferences, look up the correct display value in
                    // the preference's 'entries' list.
                    ListPreference listPreference = (ListPreference) preference;
                    int index = listPreference.findIndexOfValue(stringValue);

                    // Set the summary to reflect the new value.
                    preference.setSummary(
                        index >= 0
                        ? listPreference.getEntries()[index]
                        : null);

                } else if (preference instanceof RingtonePreference) {
                    // For ringtone preferences, look up the correct display value
                    // using RingtoneManager.
                    if (TextUtils.isEmpty(stringValue)) {
                        // Empty values correspond to 'silent' (no ringtone).
                        preference.setSummary(R.string.summary_ringtone_silent);

                    } else {
                        Ringtone ringtone = RingtoneManager.getRingtone(preference.getContext(), Uri.parse(stringValue));

                        if (ringtone == null) {
                            // Clear the summary if there was a lookup error.
                            preference.setSummary(R.string.summary_choose_ringtone);
                        } else {
                            // Set the summary to reflect the new ringtone display
                            // name.
                            String name = ringtone.getTitle(preference.getContext());
                            preference.setSummary(name);
                        }
                    }

                } else {
                    preference.setSummary(stringValue);
                }
                return true;
            }
        };

        /**
         * Email client intent to send support mail
         * Appends the necessary device information to email body
         * useful when providing support
         */
        public void sendFeedback(Context context) {
            String body = null;
            try {
                body = context.getPackageManager().getPackageInfo(context.getPackageName(), 0).versionName;
                body = "\n\n-----------------------------\nPlease don't remove this information\n Device OS: Android \n Device OS version: " +
                    Build.VERSION.RELEASE + "\n App Version: " + body + "\n Device Brand: " + Build.BRAND +
                    "\n Device Model: " + Build.MODEL + "\n Device Manufacturer: " + Build.MANUFACTURER;
            } catch (PackageManager.NameNotFoundException e) {
            }
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("message/rfc822");
            intent.putExtra(Intent.EXTRA_EMAIL, new String[]{"contact@androidhive.info"});
            intent.putExtra(Intent.EXTRA_SUBJECT, "Query from android app");
            intent.putExtra(Intent.EXTRA_TEXT, body);
            context.startActivity(Intent.createChooser(intent, context.getString(R.string.choose_email_client)));
        }
}
