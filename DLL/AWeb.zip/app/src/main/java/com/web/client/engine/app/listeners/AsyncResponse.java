package com.web.client.engine.app.listeners;

public interface AsyncResponse {

    void onProcessFinish(Integer themeColor);
}
