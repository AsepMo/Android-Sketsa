package com.web.client.engine.widget;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.widget.TextView;
import android.widget.ListView;
import android.webkit.WebView;

public class SearchWeb {
    
    public static String TAG = SearchWeb.class.getSimpleName();
    private Context mContext;
    private TextView mTextView;
    private WebView mWebView;
    private ListView mListView;
    
    private SearchWeb(Context context){
        this.mContext = context;
    }
    
    public static SearchWeb with(Context context) {
        return new SearchWeb(context);
    }
   
    public void attachTextView(TextView textView){
        this.mTextView = textView;
    }
    
    public void attachWebView(WebView webView){
        this.mWebView = webView;
    }
    
    public void attachListView(ListView listView) {
        this.mListView = listView;
    }
    
    
}
