package com.web.client.engine.app.folders;

import android.annotation.TargetApi;
import android.support.annotation.Nullable;
import android.support.v4.app.ShareCompat;
import android.support.v4.provider.DocumentFile;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.os.Build;
import android.os.Environment;
import android.text.TextUtils;
import android.util.Log;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;

import com.web.client.R;
import com.web.client.AppController;
import com.web.client.engine.widget.HtmlTextEditor;

public class FileMe {

    public static final String APK = ".apk", MP4 = ".mp4", MP3 = ".mp3", JPG = ".jpg", JPEG = ".jpeg", PNG = ".png", DOC = ".doc", DOCX = ".docx", XLS = ".xls", XLSX = ".xlsx", PDF = ".pdf";
    public static final String INDEX_HTML = "index.html";
    private static final String TAG = FileMe.class.getSimpleName();
    private static volatile FileMe Instance = null;
    private Context context;

    private FileMe(Context context) {
        this.context = context;
    }

    public static FileMe getInstance() {
        FileMe localInstance = Instance;
        if (localInstance == null) {
            synchronized (FileMe.class) {
                localInstance = Instance;
                if (localInstance == null) {
                    Instance = localInstance = new FileMe(AppController.getContext());
                }
            }
        }
        return localInstance;
    }

    public static FileMe with(Context context) {
        return new FileMe(context);
    }

    public FileMe ScriptMe(String dir, String file, String message) {
        File fileToEdit = new File(dir, file);
        if (!fileToEdit.exists()) {
            try {
                fileToEdit.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        OutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(fileToEdit);
            outputStream.write(message.getBytes());

        } catch (IOException e) {
            Log.e(TAG, "Unable to write to storage", e);

        } finally {
            close(outputStream);
        }
        return this;
    }


    /**
     * Requires Permission: Manifest.permission.WRITE_EXTERNAL_STORAGE
     */
    public FileMe WebMe(String dir, String fileName, String text) {
        File file = new File(dir, fileName);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        OutputStream outputStream = null;
        try {
            outputStream = new FileOutputStream(file);
            outputStream.write(text.getBytes());

        } catch (IOException e) {
            Log.e(TAG, "Unable to write to storage", e);

        } finally {
            close(outputStream);
        }
        return this;
    }

    public static boolean isExists() {
        return doesFileExists(INDEX_HTML);
    }

    /**
     * Checks the all path until it finds it and return immediately.
     *
     * @param value must be only the binary name
     * @return if the value is found in any provided path
     */
    private static boolean doesFileExists(String value) {
        boolean result = false;
        File file = new File(FolderMe.FOLDER_WEB_EDITOR + "/" + value);
        result = file.exists();
        if (result) {
            Log.d(TAG, file + " contains index.html binary");
        }
        return result;
    }
    /**
     * Requires Permission: Manifest.permission.READ_EXTERNAL_STORAGE
     */
    public static void readFromStorage(String filePath, String fileName, HtmlTextEditor editor) {
        File file = new File(filePath, fileName);
        BufferedReader inputStream = null;
        FileInputStream input = null;
        String test = "";
        try {
            input = new FileInputStream(file);
            inputStream = new BufferedReader(new InputStreamReader(input));
            test = inputStream.readLine();
            editor.setText(test);
        } catch (IOException e) {
            Log.e(TAG, "Unable to read from storage", e);

        } finally {
            close(input);
            close(inputStream);
        }
    }

    private static void close(@Nullable Closeable closeable) {
        if (closeable == null) {return;}
        try {
            closeable.close();
        } catch (IOException ignored) {}
    }
}
