package com.web.client.engine.app.fragments;

import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.SwipeRefreshLayout;
import android.annotation.TargetApi;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ActivityInfo;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.LightingColorFilter;
import android.net.Uri;
import android.preference.PreferenceManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.animation.DecelerateInterpolator;
import android.webkit.WebChromeClient;
import android.webkit.WebViewClient;
import android.webkit.PermissionRequest;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.Toast;

import com.web.client.R;
import com.web.client.AppController;
import com.web.client.application.ApplicationActivity;
import com.web.client.receiver.NetworkReceiver;
import com.web.client.engine.app.config.Constants;
import com.web.client.engine.app.settings.Settings;
import com.web.client.engine.app.server.web.Utils;
import com.web.client.engine.app.utils.ServiceUtils;
import com.web.client.engine.widget.AdvancedWebView;
import com.web.client.engine.widget.AdvancedWebView.Listener;
import com.web.client.service.WebServerService;


public class WebCameraFragment extends Fragment implements Listener {

    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_EXTRA_URL = "EXTRA_URL";
    private static final String TAG = WebCameraFragment.class.getSimpleName();

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    /*public static WebCameraFragment loadWeb(String url) {
     WebCameraFragment f = new WebCameraFragment();
     Bundle b = new Bundle();
     b.putString(ARG_EXTRA_URL, url);
     f.setArguments(b);

     return f;
     }*/

    public WebCameraFragment() {
    }

    private String ipAddress;
    private String urlWebCamera;

    private Context mContext;
    private AdvancedWebView mWebView;
    private ProgressBar progressBar;

    private SwipeRefreshLayout refreshLayout;
    private RelativeLayout webContainer;
    private FrameLayout progressBarContainer;
    private LinearLayout firstLoadingView;

    private View mCustomView;
    private int mOriginalSystemUiVisibility;
    private int mOriginalOrientation;
    private WebChromeClient.CustomViewCallback mCustomViewCallback;
    protected FrameLayout mFullscreenContainer;
    
    Integer shortAnimDuration;
    Integer previsionThemeColor = Color.parseColor("#FF8B14");
    SharedPreferences sharedPreferences;
    private ApplicationActivity mActivity;
    private boolean isRunning = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_app_web_camera, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {

        mContext = getActivity();

        mActivity = (ApplicationActivity)getActivity();
        previsionThemeColor = Color.parseColor("#FF8B14");
        shortAnimDuration = getResources().getInteger(android.R.integer.config_shortAnimTime);


        refreshLayout = (SwipeRefreshLayout)view.findViewById(R.id.refresh_layout);
        progressBar = (ProgressBar)view.findViewById(R.id.main_progress_bar);

        webContainer = (RelativeLayout)view.findViewById(R.id.web_container);
        firstLoadingView = (LinearLayout)view.findViewById(R.id.first_loading_view);
        progressBarContainer = (FrameLayout)view.findViewById(R.id.main_progress_bar_container);
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(mContext);


        mWebView = (AdvancedWebView)view.findViewById(R.id.webview);
        mWebView.setListener(getActivity(), this);
        mWebView.setGeolocationEnabled(false);
        mWebView.setMixedContentAllowed(true);
        mWebView.setCookiesEnabled(true);
        mWebView.setThirdPartyCookiesEnabled(true);
        mWebView.setWebViewClient(new WebViewClient() {

                @Override
                public void onPageFinished(WebView view, String url) {
                    Toast.makeText(mContext, "Finished loading", Toast.LENGTH_SHORT).show();
                }

            });
        mWebView.setWebChromeClient(chromeClient);

        mWebView.addHttpHeader("X-Requested-With", "");

        // AppRTC requires third party cookies to work
        CookieManager cookieManager = CookieManager.getInstance();
        cookieManager.setAcceptThirdPartyCookies(mWebView, true);
        refreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
                @Override
                public void onRefresh() {
                    mWebView.reload();
                }
            });

        Settings.updatePreferences(mContext);
        //ipAddress = Utils.getLocalIpAddress();
        //urlWebCamera = String.format("http://%s:%d", ipAddress, Settings.getPort());

        try {
            new Handler().postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        if (firstLoadingView.getVisibility() == View.VISIBLE) {
                            crossFade(firstLoadingView, webContainer);
                            mWebView.loadUrl("https://apprtc-m.appspot.com/");
                        }
                    }
                }, 2000);


        } catch (final RuntimeException e) {
        }

        setProgressBarColor(R.color.accent_green);

    }

    @Override
    public void onPageStarted(String url, Bitmap favicon) {
        mWebView.setVisibility(View.INVISIBLE);

        //Showing progress bar
        progressBarContainer.animate()
            .alpha(1f)
            .setDuration(getResources().getInteger(android.R.integer.config_shortAnimTime))
            .setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationStart(Animator animation) {
                    super.onAnimationStart(animation);
                    progressBarContainer.setVisibility(View.VISIBLE);
                }
            });

    }

    @Override
    public void onPageError(int errorCode, String description, String failingUrl) {
        mWebView.loadUrl(Constants.ASSET_URL_VIDEO_PLAYER);
        //Toast.makeText(mContext, "onPageError(errorCode = " + errorCode + ",  description = " + description + ",  failingUrl = " + failingUrl + ")", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onDownloadRequested(String url, String suggestedFilename, String mimeType, long contentLength, String contentDisposition, String userAgent) {
        Toast.makeText(mContext, "onDownloadRequested(url = " + url + ",  suggestedFilename = " + suggestedFilename + ",  mimeType = " + mimeType + ",  contentLength = " + contentLength + ",  contentDisposition = " + contentDisposition + ",  userAgent = " + userAgent + ")", Toast.LENGTH_LONG).show();

        /*if (AdvancedWebView.handleDownload(this, url, suggestedFilename)) {
         // download successfully handled
         }
         else {
         // download couldn't be handled because user has disabled download manager app on the device
         }*/
    }

    @Override
    public void onExternalPageRequest(String url) {
        Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
        startActivity(browserIntent);
    }

    @Override
    public void onPageFinished(String url) {
        mWebView.setVisibility(View.VISIBLE);
        progressBarContainer.animate()
            .alpha(0f)
            .setDuration(getResources().getInteger(android.R.integer.config_longAnimTime))
            .setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    super.onAnimationEnd(animation);
                    progressBarContainer.setVisibility(View.GONE);
                }
            });

        if (refreshLayout.isRefreshing()) {
            refreshLayout.setRefreshing(false);
        }
    }

    @SuppressLint("NewApi")
    @Override
    public void onResume() {
        super.onResume();
        Log.i(TAG, "onResume:");
        mWebView.onResume();
    }

    @SuppressLint("NewApi")
    @Override
    public void onPause() {
        super.onPause();
        Log.i(TAG, "onPause:");
        mWebView.onPause();  
    }

    @SuppressLint("NewApi")
    @Override
    public void onStop() {
        super.onStop();
        Log.i(TAG, "onStop:");

        /**
         * When the application falls into the background we want to stop the media stream
         * such that the camera is free to use by other apps.
         */
        mWebView.evaluateJavascript("if(window.localStream){window.localStream.stop();}", null);
    }

    @SuppressLint("NewApi")
    @Override
    public void onDestroy() {
        super.onDestroy();
        Log.i(TAG, "onResume:");

        mWebView.onDestroy();      
        // mContext.unregisterReceiver(processStatusReceiver);    
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        mWebView.onActivityResult(requestCode, resultCode, data);
    }


    public boolean isRunning() {
        isRunning = mWebView.canGoBack();
        return isRunning;
    }

    public void goBack() {
        mWebView.goBack();
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void changeUIColor(Integer color) {

        ValueAnimator anim = ValueAnimator.ofArgb(previsionThemeColor, color);
        anim.setEvaluator(new ArgbEvaluator());

        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    progressBar.getProgressDrawable().setColorFilter(new LightingColorFilter(0xFF000000, (Integer) valueAnimator.getAnimatedValue()));
                    setSystemBarColor((Integer) valueAnimator.getAnimatedValue());

                }
            });

        anim.setDuration(getResources().getInteger(android.R.integer.config_shortAnimTime));
        anim.start();
        refreshLayout.setColorSchemeColors(color, color, color);

    }

    private void setProgressBarColor(Integer color) {

        ValueAnimator anim = ValueAnimator.ofArgb(previsionThemeColor, color);
        anim.setEvaluator(new ArgbEvaluator());

        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator valueAnimator) {
                    progressBar.getProgressDrawable().setColorFilter(new LightingColorFilter(0xFF000000, (Integer) valueAnimator.getAnimatedValue()));                 
                }
            });

        anim.setDuration(getResources().getInteger(android.R.integer.config_shortAnimTime));
        anim.start();
        refreshLayout.setColorSchemeColors(color, color, color);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    private void setSystemBarColor(int color) {

        int clr;

        //this makes the color darker or uses nicer orange color

        if (color != Color.parseColor("#FF8B14")) {
            float[] hsv = new float[3];
            Color.colorToHSV(color, hsv);
            hsv[2] *= 0.8f;
            clr = Color.HSVToColor(hsv);
        } else {
            clr = Color.parseColor("#F47D20");
        }

        Window window = mActivity.getWindow();
        window.setStatusBarColor(clr);

    }

    private void crossFade(final View toHide, View toShow) {

        toShow.setAlpha(0f);
        toShow.setVisibility(View.VISIBLE);

        toShow.animate()
            .alpha(1f)
            .setDuration(shortAnimDuration)
            .setListener(null);

        toHide.animate()
            .alpha(0f)
            .setDuration(shortAnimDuration)
            .setListener(new AnimatorListenerAdapter() {
                @Override
                public void onAnimationEnd(Animator animation) {
                    toHide.setVisibility(View.GONE);
                }
            });
    }

    private WebChromeClient chromeClient = new WebChromeClient() {

        @Override
        public void onProgressChanged(WebView view, int progress) {

            //update the progressbar value
            ObjectAnimator animation = ObjectAnimator.ofInt(progressBar, "progress", progress);
            animation.setDuration(100); // 0.5 second
            animation.setInterpolator(new DecelerateInterpolator());
            animation.start();

        }

        @Override
        public Bitmap getDefaultVideoPoster() {
            if (getActivity() == null) {
                return null;
            }

            return BitmapFactory.decodeResource(getActivity().getApplicationContext().getResources(),
                                                R.drawable.cover_youtube);
        }

        @Override
        public void onShowCustomView(View view,
                                     WebChromeClient.CustomViewCallback callback) {
            // if a view already exists then immediately terminate the new one
            if (mCustomView != null) {
                onHideCustomView();
                return;
            }

            // 1. Stash the current state
            mCustomView = view;
            mOriginalSystemUiVisibility = getActivity().getWindow().getDecorView().getSystemUiVisibility();
            mOriginalOrientation = getActivity().getRequestedOrientation();

            // 2. Stash the custom view callback
            mCustomViewCallback = callback;

            // 3. Add the custom view to the view hierarchy
            FrameLayout decor = (FrameLayout) getActivity().getWindow().getDecorView();
            decor.addView(mCustomView, new FrameLayout.LayoutParams(
                              ViewGroup.LayoutParams.MATCH_PARENT,
                              ViewGroup.LayoutParams.MATCH_PARENT));


            // 4. Change the state of the window
            getActivity().getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_IMMERSIVE);
            getActivity().setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        }

        @Override
        public void onHideCustomView() {
            // 1. Remove the custom view
            FrameLayout decor = (FrameLayout) getActivity().getWindow().getDecorView();
            decor.removeView(mCustomView);
            mCustomView = null;

            // 2. Restore the state to it's original form
            getActivity().getWindow().getDecorView().setSystemUiVisibility(mOriginalSystemUiVisibility);
            getActivity().setRequestedOrientation(mOriginalOrientation);

            // 3. Call the custom view callback
            mCustomViewCallback.onCustomViewHidden();
            mCustomViewCallback = null;

        }
    };
}
