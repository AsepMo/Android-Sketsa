package com.web.client.engine.app.crashes.action;

import com.web.client.engine.app.crashes.viewmodel.CrashesViewModel;

public interface CrashListActions {
  void render(CrashesViewModel viewModel);

  void openCrashDetails(int crashId);
}
