package com.web.client.application;

import android.annotation.TargetApi;
import android.support.annotation.ColorInt;
import android.support.annotation.ColorRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import java.util.Arrays;
import java.util.ArrayList;
import java.lang.ref.WeakReference;

import com.web.client.R;
import com.web.client.engine.Themes;
import com.web.client.engine.app.dashboard.DashboardFragment;
import com.web.client.engine.app.adapters.DrawerAdapter;
import com.web.client.engine.app.models.DrawerItem;
import com.web.client.engine.app.models.SimpleItem;
import com.web.client.engine.app.models.SpaceItem;
import com.web.client.engine.app.config.Constants;
import com.web.client.engine.app.fragments.WebClientFragment;
import com.web.client.engine.app.fragments.WebEditorFragment;
import com.web.client.engine.app.fragments.WebServerFragment;
import com.web.client.engine.app.fragments.WebCameraFragment;
import com.web.client.engine.app.fragments.WebBrowserFragment;
import com.web.client.engine.app.fragments.WebDocumentFragment;
import com.web.client.engine.app.fragments.WebSettingFragment;
import com.web.client.engine.app.settings.Settings;
import com.web.client.engine.app.utils.ServiceUtils;
import com.web.client.engine.graphics.SystemBarTintManager;
import com.web.client.engine.widget.SpeakerBox;
import com.web.client.engine.widget.SlidingRootNav;
import com.web.client.engine.widget.SlidingRootNavBuilder;
import com.web.client.service.NetworkService;

public class ApplicationActivity extends ThemableActivity implements DrawerAdapter.OnItemSelectedListener, View.OnClickListener {
    
    public static String TAG = ApplicationActivity.class.getSimpleName();
    public static void start(Context c) {
        Intent mIntent = new Intent(c, ApplicationActivity.class);
        c.startActivity(mIntent);
    }
    
    private SpeakerBox speakerbox;
    private Toolbar mToolbar;
    private BroadcastReceiver networkStatusReceiver;
    
    private static final int POS_APP_WEB_CLIENT = 0;
    private static final int POS_APP_WEB_CAMERA = 1;
    private static final int POS_APP_WEB_BROWSER = 2;
    private static final int POS_APP_WEB_EDITOR = 3;
    private static final int POS_APP_FILE_TRANSFER = 5;
    private static final int POS_APP_WEB_SERVER = 6;
    private static final int POS_MORE_APPS = 7;

    private String[] screenTitles;
    private Drawable[] screenIcons;

    private SlidingRootNav slidingRootNav;
    private WebClientFragment mWebClient; 
    private WebCameraFragment mWebCamera;   
    private WebEditorFragment mWebEditor;
    
   
    private final Handler handler = new Handler();
    
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void onCreate(@Nullable Bundle savedInstanceState)
    {
        setTheme(R.style.AppTheme_NoActionBar);
        if (Themes.hasLollipop())
        {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        }
        else if (Themes.hasKitKat())
        {
            setTheme(R.style.AppTheme_Translucent);
        }
        setUpStatusBar();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);

        mToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);

        slidingRootNav = new SlidingRootNavBuilder(this)
            .withToolbarMenuToggle(mToolbar)
            .withMenuOpened(false)
            .withContentClickableWhenMenuOpened(false)
            .withSavedState(savedInstanceState)
            .withMenuLayout(R.layout.menu_application_drawer)
            .inject();

        screenIcons = loadScreenIcons();
        screenTitles = loadScreenTitles();

        DrawerAdapter adapter = new DrawerAdapter(Arrays.asList(
                                                      createItemFor(POS_APP_WEB_CLIENT).setChecked(true),
                                                      createItemFor(POS_APP_WEB_CAMERA),
                                                      createItemFor(POS_APP_WEB_BROWSER),
                                                      createItemFor(POS_APP_WEB_EDITOR),
                                                      new SpaceItem(48),
                                                      createItemFor(POS_APP_FILE_TRANSFER),
                                                      createItemFor(POS_APP_WEB_SERVER),
                                                      createItemFor(POS_MORE_APPS)));
        adapter.setListener(this);

        RecyclerView list = findViewById(R.id.list);
        list.setNestedScrollingEnabled(false);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);
        findViewById(R.id.about_layout).setOnClickListener(this);
        findViewById(R.id.action_profile).setOnClickListener(this);       
        findViewById(R.id.settings_layout).setOnClickListener(this);
        findViewById(R.id.exit_layout).setOnClickListener(this);

        adapter.setSelected(POS_APP_WEB_CLIENT);
        
        startNetworkService();
        networkStatusReceiver = new NetworkStatus();
        registerBroadcastReceiver();
        
        speakerbox = new SpeakerBox(getApplication());
        speakerbox.setActivity(this);
        speakerbox.setQueueMode(TextToSpeech.QUEUE_ADD);
        speakerbox.setQueueMode(TextToSpeech.QUEUE_FLUSH);
        speakerbox.requestAudioFocus();
        speakerbox.abandonAudioFocus();
        
        changeActionBarColor();
    }

    
    @Override
    protected void onResume() {
        super.onResume();
        Log.v(TAG, "onResume:");  
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v(TAG, "onPause:");
       // unregisterReceiver(networkStatusReceiver); 
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v(TAG, "onDestroy:");
        unregisterReceiver(networkStatusReceiver); 
    }
    
    @Override
    public void onItemSelected(int position) {

        if (position == POS_APP_WEB_CLIENT) {
            mWebClient = WebClientFragment.loadWeb(Constants.ASEPMO_URL);
            switchFragment(mWebClient);
        }
        if (position == POS_APP_WEB_CAMERA) {
            mWebCamera = new WebCameraFragment();       
            switchFragment(mWebCamera);
        }
        if (position == POS_APP_WEB_BROWSER) {
            switchFragment(WebBrowserFragment.newInstance("search"));
        }
        if (position == POS_APP_WEB_EDITOR) {
            mWebEditor = WebEditorFragment.loadWeb("Html Editor");
            switchFragment(mWebEditor);
        }
        if (position == POS_APP_FILE_TRANSFER) {
            switchFragment(new WebDocumentFragment());
        }
         if (position == POS_APP_WEB_SERVER) {
            switchFragment(new WebServerFragment());
        }
        if (position == POS_MORE_APPS) {
            //switchFragment(ArchiveFragment.newInstance(0));
        }
        slidingRootNav.closeMenu();

    }

    @Override
    public void onClick(View v) {
        String title = "";
        switch (v.getId()) {
            case R.id.about_layout:
                title = "About";

                break;
            case R.id.settings_layout:
                title = "Settings";
                startAction(ApplicationActivity.this, AppSettingsActivity.class);
                break;
            case R.id.action_profile:
                title = "Profile";
                startAction(ApplicationActivity.this, FTPClientActivity.class);           
                break; 
            case R.id.exit_layout:
                title = "Exit";
                finish();
                break;

        }
        slidingRootNav.closeMenu();     
        Toast.makeText(this, title, Toast.LENGTH_SHORT).show();
    }

    private DrawerItem createItemFor(int position) {
        return new SimpleItem(screenIcons[position], screenTitles[position])
            .withIconTint(color(R.color.textColorSecondary))
            .withTextTint(color(R.color.textColorPrimary))
            .withSelectedIconTint(color(R.color.selected_color_tint))
            .withSelectedTextTint(color(R.color.selected_color_tint));
    }

    private String[] loadScreenTitles() {
        return getResources().getStringArray(R.array.ld_activityScreenTitles);
    }

    private Drawable[] loadScreenIcons() {
        TypedArray ta = getResources().obtainTypedArray(R.array.ld_activityScreenIcons);
        Drawable[] icons = new Drawable[ta.length()];
        for (int i = 0; i < ta.length(); i++) {
            int id = ta.getResourceId(i, 0);
            if (id != 0) {
                icons[i] = ContextCompat.getDrawable(this, id);
            }
        }
        ta.recycle();
        return icons;
    }

    @ColorInt
    private int color(@ColorRes int res) {
        return ContextCompat.getColor(this, res);
    }

    public void switchFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    }

    @Override
    public void onBackPressed() {
        if (slidingRootNav.isMenuOpened()) {
            slidingRootNav.closeMenu();
        } else if (mWebClient.isAdded() && !mWebClient.isRunning()) {
            return;
        } 
        else{
            super.onBackPressed();
        }      
    } 
    
    public void startNetworkService() {
        ServiceUtils.killAllProcessorServices(ApplicationActivity.this);
        Intent mServiceIntent = new Intent(ApplicationActivity.this, NetworkService.class);
        //mServiceIntent.setAction(Constans.ACTION.START_PROCESS);        
        startService(mServiceIntent);
    }

    public void registerBroadcastReceiver() {
        IntentFilter statusIntentFilter = new IntentFilter(Constants.PROCESS_BROADCAST_ACTION);
        registerReceiver(networkStatusReceiver, statusIntentFilter);
    }

    private class NetworkStatus extends BroadcastReceiver {

        private NetworkStatus() {

        }

        @Override
        public void onReceive(Context context, Intent intent) {
            String statusKey = "";
            String statusData = "";
            if (intent.hasExtra(Constants.PROCESS_STATUS_KEY)) {
                statusKey = intent.getStringExtra(Constants.PROCESS_STATUS_KEY);
            }
            if (intent.hasExtra(Constants.PROCESS_STATUS_MESSAGE)) {
                statusData = intent.getStringExtra(Constants.PROCESS_STATUS_MESSAGE);
            }
            switch (statusKey) {
                case "offline":
                    Toast.makeText(ApplicationActivity.this, statusData, Toast.LENGTH_SHORT).show();
                    
                    break;
                case "online":
                    Toast.makeText(ApplicationActivity.this, statusData, Toast.LENGTH_SHORT).show();
                    
                    break;
                
                default:
                    Toast.makeText(ApplicationActivity.this, statusData, Toast.LENGTH_SHORT).show();
                    
            }
        }
    }
    
    private Drawable oldBackground;

    private void changeActionBarColor()
    {

        int color = AppSettingsActivity.getPrimaryColor(this);
        Drawable colorDrawable = new ColorDrawable(color);

        if (oldBackground == null)
        {
            getSupportActionBar().setBackgroundDrawable(colorDrawable);
        }
        else
        {
            TransitionDrawable td = new TransitionDrawable(new Drawable[] { oldBackground, colorDrawable });
            getSupportActionBar().setBackgroundDrawable(td);
            td.startTransition(200);
        }

        oldBackground = colorDrawable;

        setUpStatusBar();
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void setUpStatusBar()
    {
        // TODO: Implement this method
        int color = Themes.getStatusBarColor(AppSettingsActivity.getPrimaryColor(this));
        if (Themes.hasLollipop())
        {
            getWindow().setStatusBarColor(color);
        }
        else if (Themes.hasKitKat())
        {
            SystemBarTintManager systemBarTintManager = new SystemBarTintManager(this);
            systemBarTintManager.setTintColor(color);
            systemBarTintManager.setStatusBarTintEnabled(true);
        }
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    public void setUpDefaultStatusBar()
    {
        // TODO: Implement this method
        int color = ContextCompat.getColor(this, R.color.alertColor);
        if (Themes.hasLollipop())
        {
            getWindow().setStatusBarColor(color);
        }
        else if (Themes.hasKitKat())
        {
            SystemBarTintManager systemBarTintManager = new SystemBarTintManager(this);
            systemBarTintManager.setTintColor(Themes.getStatusBarColor(color));
            systemBarTintManager.setStatusBarTintEnabled(true);
        }
    }

    public static int getStatusBarHeight(Context context)
    {
        int result = 0;
        int resourceId = context.getResources().getIdentifier("status_bar_height", "dimen", "android");
        if (resourceId > 0)
        {
            result = context.getResources().getDimensionPixelSize(resourceId);
        }
        return result;
    }
    
    @Override
    public String getTag()
    {
        // TODO: Implement this method
        return TAG;
    }
}
