package com.web.client;

import android.support.v7.app.AppCompatDelegate;
import android.app.Application;
import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.web.client.BuildConfig;
import com.web.client.engine.Themes;
import com.web.client.engine.app.analytics.AnalyticsManager;
import com.web.client.engine.app.core.Sherlock;
import com.web.client.engine.app.core.investigation.AppInfo;
import com.web.client.engine.app.core.investigation.AppInfoProvider;
import com.web.client.engine.app.core.SherlockNotInitializedException;
import com.web.client.engine.app.utils.AppInfoUtil;
import com.web.client.engine.widget.soundPool.ISoundPoolLoaded;
import com.web.client.engine.widget.soundPool.SoundPoolManager;

public class AppController extends Application {

	private static AppController sInstance;
    private static Context mContext;
    
	static {
		AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
	}

	private static boolean isTelevision;

	@Override
	public void onCreate()
	{
		// TODO: Implement this method
		super.onCreate();
		if(!BuildConfig.DEBUG) {
            AnalyticsManager.intialize(getApplicationContext());
        }
        sInstance = this;
        mContext = this;
		isTelevision = Themes.isTelevision(this);
        try {

            Sherlock.init(this); //Initializing Sherlock
            Sherlock.setAppInfoProvider(new AppInfoProvider() {
                    @Override
                    public AppInfo getAppInfo() {
                        return new AppInfo.Builder()
                            .with("Version", AppInfoUtil.getAppVersion(getApplicationContext())) //You can get the actual version using "AppInfoUtil.getAppVersion(context)"
                            .with("BuildNumber", "221B")
                            .build();
                    }
                });

        } catch (SherlockNotInitializedException e) {
            e.printStackTrace();
        }
        SoundPool();
	}

	public static synchronized AppController getInstance() {
        return sInstance;
    }
    
    public static Context getContext() {
        return mContext;
    }
    
	public static boolean isTelevision() {
        return isTelevision;
    }
    
   public void SoundPool() {
        SoundPoolManager.CreateInstance();
        List<Integer> sounds = new ArrayList<Integer>();
        sounds.add(R.raw.sound1);
        sounds.add(R.raw.sound2);
        sounds.add(R.raw.add);
        sounds.add(R.raw.done);
        sounds.add(R.raw.sound_error);
        SoundPoolManager.getInstance().setSounds(sounds);
        try {
            SoundPoolManager.getInstance().InitializeSoundPool(getApplicationContext(), new ISoundPoolLoaded() {
                    @Override
                    public void onSuccess() {

                    }
                });
        } catch (Exception e) {
            e.printStackTrace();
        }

        SoundPoolManager.getInstance().setPlaySound(true);
    } 
}


