package com.video.evolution.engine.graphics;

public interface OnColorPickerListener {
    void onColorPicker(int color);
}
