package com.video.evolution.engine.widget.soundPool;

public interface ISoundPoolLoaded {
    public void onSuccess();
}
