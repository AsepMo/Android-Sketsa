package com.video.evolution.engine.app.theme;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AppCompatDelegate;
import android.support.v7.content.res.AppCompatResources;
import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;

import com.video.evolution.R;
import com.video.evolution.AppController;
import com.video.evolution.engine.app.settings.Settings;
import com.video.evolution.engine.app.settings.SharedPref;

public class Theme {

    public int mTheme = -1;
    public static String theme = "name_of_the_theme";
    public static final String THEME_PREFERENCES = "com.apps.dark.themepref";
    public static final String RECREATE_ACTIVITY = "com.apps.dark.recreateactivity";
    public static final String EXTRA_RECREATE = "recreate";
    public static final String THEME_SAVED = "com.apps.dark.savedtheme";
    public static final String DARKTHEME = "com.apps.dark.darktheme";
    public static final String LIGHTTHEME = "com.apps.dark.lighttheme";

    private static volatile Theme Instance = null;
    public static Theme getInstance() {
        Theme localInstance = Instance;
        if (localInstance == null) {
            synchronized (Theme.class) {
                localInstance = Instance;
                if (localInstance == null) {
                    Instance = localInstance = new Theme();
                }
            }
        }
        return localInstance;
    }

    public void setTheme(Activity c) {
        theme = c.getSharedPreferences(THEME_PREFERENCES, Context.MODE_PRIVATE).getString(THEME_SAVED, LIGHTTHEME);
        if (theme.equals(LIGHTTHEME)) {
          // mTheme = R.style.CustomStyle_LightTheme;
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO);
        } else {
          // mTheme = R.style.CustomStyle_DarkTheme;
            AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_YES);
        }
      c.setTheme(R.style.AppTheme_NoActionBar);
    }

    public void getTheme(AppCompatActivity c) {
        /*Note: the recreate_key's value is changed to false before calling recreate(), or we woudl have ended up in an infinite loop,
         as onResume() will be called on recreation, which will again call recreate() and so on....
         and get an ANR
         */
        if (c.getSharedPreferences(THEME_PREFERENCES, Context.MODE_PRIVATE).getBoolean(RECREATE_ACTIVITY, false)) {
            SharedPreferences.Editor editor = c.getSharedPreferences(THEME_PREFERENCES, Context.MODE_PRIVATE).edit();
            editor.putBoolean(RECREATE_ACTIVITY, false);
            editor.apply();
            c.recreate();
        }
    }
    
    public void setDefaultDir(String folder)
    {
        new SharedPref(AppController.getContext()).setWorkingFolder(folder);
    }
    
    public void getDefaultFolder(){
        AppController.getInstance().getAppPreferences();
    }
    
    public int getPrimaryColor(){
        return Settings.getPrimaryColor();
    }

    public void onBackPressed(AppCompatActivity activity) {
        SharedPreferences sharedPreferences = activity.getSharedPreferences(THEME_PREFERENCES, Context.MODE_PRIVATE);
        Drawable icon = null;
        //int bgColor;
        //int todoTextColor;
        if (sharedPreferences.getString(THEME_SAVED, LIGHTTHEME).equals(LIGHTTHEME)) {
            //bgColor = Color.WHITE;
            icon = AppCompatResources.getDrawable(activity, R.drawable.abc_ic_ab_back_material);     
            icon.setColorFilter(Color.BLACK, PorterDuff.Mode.SRC_ATOP);
        } else {
            //bgColor = Color.BLACK;  
            icon = AppCompatResources.getDrawable(activity, R.drawable.abc_ic_ab_back_material);     
            icon.setColorFilter(Color.WHITE, PorterDuff.Mode.SRC_ATOP);          
        }
        ActionBar mActionBar = activity.getSupportActionBar();   
        mActionBar.setHomeAsUpIndicator(icon);
        mActionBar.setDisplayHomeAsUpEnabled(true);

    }
}

