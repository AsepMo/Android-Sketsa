package com.video.evolution.engine.app.utils;

import android.support.annotation.Nullable;
import android.support.v4.app.ShareCompat;
import android.support.v4.provider.DocumentFile;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;

import java.io.File;
import java.io.FileFilter;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import com.video.evolution.engine.app.folders.FileMe;

public class FileUtils {
    private static final int BUFFER = 16384;
    private static final long ONE_KB = 1024;
    private static final BigInteger KB_BI = BigInteger.valueOf(ONE_KB);
    private static final BigInteger MB_BI = KB_BI.multiply(KB_BI);
    private static final BigInteger GB_BI = KB_BI.multiply(MB_BI);
    private static final BigInteger TB_BI = KB_BI.multiply(GB_BI);

    public final static int 
    KILOBYTE = 1024,
    MEGABYTE = KILOBYTE * 1024,
    GIGABYTE = MEGABYTE * 1024,
    MAX_BYTE_SIZE = KILOBYTE / 2,
    MAX_KILOBYTE_SIZE = MEGABYTE / 2,
    MAX_MEGABYTE_SIZE = GIGABYTE / 2;

    public static final String MIME_TYPE_ANY = "*/*";

    public static final FileFilter DEFAULT_FILE_FILTER = new FileFilter()
    {

        @Override
        public boolean accept(File pathname) {
            return pathname.isHidden() == false;
        }
    };

    /**
     * Compares files by name, where directories come always first
     */
    public static class FileNameComparator implements Comparator<File> {
        protected final static int 
        FIRST = -1,
        SECOND = 1;
        @Override
        public int compare(File lhs, File rhs) {
            if (lhs.isDirectory() || rhs.isDirectory()) {
                if (lhs.isDirectory() == rhs.isDirectory())
                    return lhs.getName().compareToIgnoreCase(rhs.getName());
                else if (lhs.isDirectory()) return FIRST;
                else return SECOND;
            }
            return lhs.getName().compareToIgnoreCase(rhs.getName());
        }       
    }

    /**
     * Compares files by extension. 
     * Falls back to sort by name if extensions are the same or one of the objects is a Directory
     * @author Michal
     *
     */
    public static class FileExtensionComparator extends FileNameComparator {
        @Override
        public int compare(File lhs, File rhs) {
            if (lhs.isDirectory() || rhs.isDirectory())
                return super.compare(lhs, rhs);

            String ext1 = FileMe.getFileExtension(lhs),
                ext2 = FileMe.getFileExtension(rhs);

            if (ext1.equals(ext2))
                return super.compare(lhs, rhs);
            else
                return ext1.compareToIgnoreCase(ext2);
        }
    }

    public static class FileSizeComparator extends FileNameComparator {
        private final boolean ascending = false;

        @Override
        public int compare(File lhs, File rhs) {
            if (lhs.isDirectory() || rhs.isDirectory())
                return super.compare(lhs, rhs);

            if (lhs.length() > rhs.length())
                return ascending ? SECOND : FIRST;
            else if (lhs.length() < rhs.length())
                return ascending ? FIRST : SECOND;
            else return super.compare(lhs, rhs);
        }
    }


    public static String formatFileSize(File file)
    {
        return formatFileSize(file.length());       
    }

    public static String formatFileSize(long size)
    {
        if (size < MAX_BYTE_SIZE)
            return String.format(Locale.ENGLISH, "%d bytes", size);
        else if (size < MAX_KILOBYTE_SIZE)
            return String.format(Locale.ENGLISH, "%.2f kb", (float)size / KILOBYTE);
        else if (size < MAX_MEGABYTE_SIZE)
            return String.format(Locale.ENGLISH, "%.2f mb", (float)size / MEGABYTE);
        else 
            return String.format(Locale.ENGLISH, "%.2f gb", (float)size / GIGABYTE);
    }

    public static String formatFileSize(Collection<File> files)
    {
        return formatFileSize(getFileSize(files));
    }

    public static long getFileSize(File... files)
    {
        if (files == null) return 0l;
        long size=0;
        for (File file : files)
        {
            if (file.isDirectory())
                size += getFileSize(file.listFiles());
            else size += file.length();
        }
        return size;
    }

    public static long getFileSize(Collection<File> files)
    {
        return getFileSize(files.toArray(new File[files.size()]));
    }

    //time conversion
    public static String timeConversion(long value) {
        String songTime;
        int dur = (int) value;
        int hrs = (dur / 3600000);
        int mns = (dur / 60000) % 60000;
        int scs = dur % 60000 / 1000;

        if (hrs > 0) {
            songTime = String.format("%02d:%02d:%02d", hrs, mns, scs);
        } else {
            songTime = String.format("%02d:%02d", mns, scs);
        }
        return songTime;
    }

    
    
}
