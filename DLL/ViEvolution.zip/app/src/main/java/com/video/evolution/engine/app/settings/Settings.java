package com.video.evolution.engine.app.settings;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.preference.PreferenceManager;

import com.video.evolution.AppController;
import com.video.evolution.engine.app.folders.FolderMe;

public class Settings {
    
    public static final String KEY_PRIMARY_COLOR = "primaryColor";
    public static final String KEY_ACCENT_COLOR = "accentColor";
    public static final String KEY_DEFAULT_DIR = "defaultDir";
    
    public static int getPrimaryColor()
    {
        return PreferenceManager.getDefaultSharedPreferences(AppController.getInstance().getBaseContext())
            .getInt(KEY_PRIMARY_COLOR, Color.parseColor("#0288D1"));
    }
    
    public static void setPrimaryColor(int color)
    {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(AppController.getInstance().getBaseContext());
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(KEY_PRIMARY_COLOR, color);
        editor.commit();
    }

    public static int getAccentColor()
    {
        return PreferenceManager.getDefaultSharedPreferences(AppController.getInstance().getBaseContext())
            .getInt(KEY_ACCENT_COLOR, Color.parseColor("#EF3A0F"));
    }

    public static void setAccentColor(int color)
    {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(AppController.getInstance().getBaseContext());
        SharedPreferences.Editor editor = preferences.edit();
        editor.putInt(KEY_ACCENT_COLOR, color);
        editor.commit();
    }

    public static String getDefaultDir()
    {
        return PreferenceManager.getDefaultSharedPreferences(AppController.getInstance().getBaseContext())
            .getString(KEY_DEFAULT_DIR, FolderMe.ZFOLDER);
    }

    public static void setDefaultDir(String dir)
    {
        SharedPreferences preferences = PreferenceManager.getDefaultSharedPreferences(AppController.getInstance().getBaseContext());
        SharedPreferences.Editor editor = preferences.edit();
        editor.putString(KEY_DEFAULT_DIR, dir);
        editor.commit();
    }
}
