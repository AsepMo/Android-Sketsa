package com.video.evolution.application;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.MenuItem;
import android.widget.Toast;

import com.video.evolution.R;
import com.video.evolution.engine.app.theme.Theme;
import com.video.evolution.engine.app.settings.SettingFragment;

public class ApplicationPreferences extends AppCompatActivity {
    
    public static String TAG = ApplicationPreferences.class.getSimpleName();
    public static void start(Context mContext){
        Intent mApplication = new Intent(mContext ,ApplicationPreferences.class);
        mContext.startActivity(mApplication);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {   
        Theme.getInstance().setTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application_settings);
        
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        toolbar.setTitle(R.string.app_name); 
        toolbar.setTitleTextColor(Theme.getInstance().getPrimaryColor());
        setSupportActionBar(toolbar);
        
        Theme.getInstance().onBackPressed(this);
        getFragmentManager().beginTransaction().replace(R.id.content_frame, new SettingFragment()).commit();
    }
    
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
                // close this activity when the user clicks on the back button (action bar)
            case android.R.id.home:
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
	}
}
