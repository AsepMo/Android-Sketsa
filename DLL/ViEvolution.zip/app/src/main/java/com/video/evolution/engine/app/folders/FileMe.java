package com.video.evolution.engine.app.folders;

import android.annotation.TargetApi;
import android.support.annotation.Nullable;
import android.support.v4.app.ShareCompat;
import android.support.v4.provider.DocumentFile;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.pm.PackageManager;
import android.content.pm.PackageInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.content.pm.ShortcutInfo;
import android.content.pm.ShortcutManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.Icon;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.BitmapDrawable;
import android.util.Log;
import android.text.TextUtils;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.storage.StorageManager;
import android.widget.Toast;

import org.apache.commons.io.FilenameUtils;

import java.io.File;
import java.io.FileFilter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Array;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigInteger;
import java.nio.channels.FileChannel;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.io.Writer;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;

import com.video.evolution.engine.app.preview.MimeTypes;
public class FileMe {
    public static final String APK = ".apk", MP4 = ".mp4", MP3 = ".mp3", JPG = ".jpg", JPEG = ".jpeg", PNG = ".png", DOC = ".doc", DOCX = ".docx", XLS = ".xls", XLSX = ".xlsx", PDF = ".pdf";
  
    static String[][] sMediaTypes ={
            {"3gp","video/3gpp"},
            {"apk","application/vnd.android.package-archive"},
            {"asf","video/x-ms-asf"},
            {"avi","video/x-msvideo"},
            {"bin","application/octet-stream"},
            {"bmp","image/bmp"},
            {"c","text/plain"},
            {"class","application/octet-stream"},
            {"conf","text/plain"},
            {"cpp","text/plain"},
            {"doc","application/msword"},
            {"docx","application/vnd.openxmlformats-officedocument.wordprocessingml.document"},
            {"xls","application/vnd.ms-excel"},
            {"xlsx","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"},
            {"exe","application/octet-stream"},
            {"gif","image/gif"},
            {"gtar","application/x-gtar"},
            {"gz","application/x-gzip"},
            {"h","text/plain"},
            {"htm","text/html"},
            {"html","text/html"},
            {"jar","application/java-archive"},
            {"java","text/plain"},
            {"jpeg","image/jpeg"},
            {"jpg","image/jpeg"},
            {"js","application/x-JavaScript"},
            {"log","text/plain"},
            {"m3u","audio/x-mpegurl"},
            {"m4a","audio/mp4a-latm"},
            {"m4b","audio/mp4a-latm"},
            {"m4p","audio/mp4a-latm"},
            {"m4u","video/vnd.mpegurl"},
            {"m4v","video/x-m4v"},
            {"mov","video/quicktime"},
            {"mp2","audio/x-mpeg"},
            {"mp3","audio/x-mpeg"},
            {"mp4","video/mp4"},
            {"mpc","application/vnd.mpohun.certificate"},
            {"mpe","video/mpeg"},
            {"mpeg","video/mpeg"},
            {"mpg","video/mpeg"},
            {"mpg4","video/mp4"},
            {"mpga","audio/mpeg"},
            {"msg","application/vnd.ms-outlook"},
            {"ogg","audio/ogg"},
            {"pdf","application/pdf"},
            {"png","image/png"},
            {"pps","application/vnd.ms-powerpoint"},
            {"ppt","application/vnd.ms-powerpoint"},
            {"pptx","application/vnd.openxmlformats-officedocument.presentationml.presentation"},
            {"prop","text/plain"},
            {"rc","text/plain"},
            {"rmvb","audio/x-pn-realaudio"},
            {"rtf","application/rtf"},
            {"sh","text/plain"},
            {"tar","application/x-tar"},
            {"tgz","application/x-compressed"},
            {"txt","text/plain"},
            {"wav","audio/x-wav"},
            {"wma","audio/x-ms-wma"},
            {"wmv","audio/x-ms-wmv"},
            {"wps","application/vnd.ms-works"},
            {"xml","text/plain"},
            {"z","application/x-compress"},
            {"zip","application/x-zip-compressed"},
            {"","*/*"}};

    /**
     * return the extension of the file
     * @param name name or path of the file
     * */
    public static String getExtension(String name) {
        int offset = name.lastIndexOf("/");//可能为路径,且路径中有"."
        String suffix = name.substring(offset+1, name.length());
        offset = suffix.lastIndexOf(".");
        if (offset > 0) {
            return suffix.substring(offset+1, suffix.length());
        }
        return "";
    }
    
    public static String getFileExtension(File file) {
        return getFileExtension(file.getName());
    }

    /**
     * Gets extension of the file name excluding the . character
     */
    public static String getFileExtension(String fileName) {
        if (fileName.contains("."))
            return fileName.substring(fileName.lastIndexOf('.') + 1);
        else 
            return "";
    }
    /**
     * launch the suitable activity according to the file name
     * */
    static public void callActivity(String path, Activity activity) {
        String extString = getExtension(path);
        int count = sMediaTypes.length;
        for(int i=0;i<count;i++)
        {
            if(extString.compareToIgnoreCase(sMediaTypes[i][0])==0)
            {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setDataAndType(Uri.parse("file://"+path), sMediaTypes[i][1]);
                activity.startActivity(intent);
                return;
            }
        }

    }
    
 public static File getFileDir(Context context) {
        return getFileDir(context, null);
    }

    public static File getFileDir(Context context, @Nullable String type) {
        File root = context.getFilesDir();
        if (TextUtils.isEmpty(type)) {
            return root;
        } else {
            File dir = new File(root, type);
            createDir(dir);
            return dir;
        }
    }

    public static boolean externalAvailable() {
        return Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState());
    }

    public static File getExternalDir(Context context) {
        return getExternalDir(context, null);
    }

    public static File getExternalDir(Context context, @Nullable String type) {
        if (externalAvailable()) {
            if (TextUtils.isEmpty(type)) {
                return context.getExternalFilesDir(null);
            }

            File dir = context.getExternalFilesDir(type);
            if (dir == null) {
                dir = context.getExternalFilesDir(null);
                dir = new File(dir, type);
                createDir(dir);
            }

            return dir;
        }
        throw new RuntimeException("External storage device is not available.");
    }

    public static File getRootDir() {
        return getRootDir(null);
    }

    public static File getRootDir(@Nullable String type) {
        if (externalAvailable()) {
            File root = new File(Storage.getInstance().getExternalStorageDirectory());
            File appRoot = new File(root, "AndPermission");
            createDir(appRoot);

            if (TextUtils.isEmpty(type)) {
                return appRoot;
            }

            File dir = new File(appRoot, type);
            createDir(dir);

            return dir;
        }
        throw new RuntimeException("External storage device is not available.");
    }

    
    /**
     * return the file name according to the path
     * */
    static public String pathToName(String path)//path that doesn't ended with '/'
    {
        if(path.equals("/"))
            return path;
        if(path.endsWith("/"))
            path=path.substring(0,path.length()-1);
        return (String) path.subSequence(path.lastIndexOf("/")+1,path.length());

    }
    
    public static void FileMe(Context c, String folder, String file){
        File fileToEdit = new File(c.getExternalFilesDir(folder).getAbsolutePath(), "video.dat");
        try {
            fileToEdit.getParentFile().mkdirs();

            FileOutputStream fos = new FileOutputStream(fileToEdit);
            Writer w = new BufferedWriter(new OutputStreamWriter(fos));
            try {
                w.write(file + "\n");
                w.flush();
                fos.getFD().sync();
            }
            finally {
                w.close();
            }
        }
        catch (IOException e) {
            Log.e(c.getClass().getSimpleName(), "Exception writing file", e);
        }
    }
    
    public static boolean createFile(File file) {
        if (file.exists()) {
            return !file.isDirectory();
        }

        try {
            if (file.createNewFile()) {
                return true;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            DocumentFile document = DocumentFile.fromFile(file.getParentFile());

            try {
                return document.createFile(MimeTypes.getMimeType(file), file.getName()) != null;
            } catch (Exception e) {
                e.printStackTrace();
                return false;
            }
        }
        return false;
    }

    public static boolean createDir(File folder) {
        if (folder.exists())
            return false;

        if (folder.mkdir())
            return true;
        else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                DocumentFile document = DocumentFile.fromFile(folder.getParentFile());
                if (document.exists())
                    return true;
            }

            /*if (SharedPref.rootAccess()) {
                return RootCommands.createRootdir(folder);
            }*/
        }

        return false;
    }
}
