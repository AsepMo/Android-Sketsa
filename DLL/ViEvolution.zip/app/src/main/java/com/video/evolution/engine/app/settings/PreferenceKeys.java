package com.video.evolution.engine.app.settings;

import android.content.res.Resources;
import com.video.evolution.R;

public class PreferenceKeys {
    public final String night_mode_pref_key;

    public PreferenceKeys(Resources resources) {
        night_mode_pref_key = resources.getString(R.string.pref_key_night_mode);
    }
}


