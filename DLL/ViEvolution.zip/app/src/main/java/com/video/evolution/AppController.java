package com.video.evolution;

import android.support.v7.app.AppCompatDelegate;
import com.singhajit.sherlock.core.Sherlock;
import com.singhajit.sherlock.core.investigation.AppInfo;
import com.singhajit.sherlock.core.investigation.AppInfoProvider;
import com.singhajit.sherlock.core.SherlockNotInitializedException;
import com.singhajit.sherlock.util.AppInfoUtil;

import com.video.evolution.application.ApplicationManager;
import com.video.evolution.engine.app.settings.SharedPref;

public class AppController extends ApplicationManager {
    private static AppController mInstance;
    private static SharedPref appPreferences = null;
    static {
       AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
   }
   
    @Override
    public void onCreate() {
        super.onCreate();

        mInstance = this;
    }

    public static synchronized AppController getInstance(){
        return mInstance;
    }

    @Override
    public void initAnalytics() {
        super.initAnalytics();
    }

    @Override
    public void initConfig() {
        super.initConfig();
    }

    @Override
    public void initCrashHandler() {
        super.initCrashHandler();
        try {
            Sherlock.init(this); //Initializing Sherlock
            Sherlock.setAppInfoProvider(new AppInfoProvider() {
                    @Override
                    public AppInfo getAppInfo() {
                        return new AppInfo.Builder()
                            .with("Version", AppInfoUtil.getAppVersion(getApplicationContext())) //You can get the actual version using "AppInfoUtil.getAppVersion(context)"
                            .with("BuildNumber", "1")
                            .build();
                    }
                });

        } catch (SherlockNotInitializedException e) {
            e.printStackTrace();
        } 
    }

    @Override
    public void initSoundManager() {
        super.initSoundManager();
    }
    
    public static SharedPref getAppPreferences()
    {
        if (appPreferences == null)
            appPreferences = SharedPref.loadPreferences(getContext());

        return appPreferences;
    }
}
