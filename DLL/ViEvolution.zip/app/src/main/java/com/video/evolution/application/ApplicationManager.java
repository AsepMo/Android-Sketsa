package com.video.evolution.application;

import android.app.Application;
import android.content.Context;

public class ApplicationManager extends Application {

    private static Context mContext;
    @Override
    public void onCreate() {
        super.onCreate();
        mContext = this;
        initAnalytics();
        initConfig();
        initCrashHandler();
        initSoundManager();
    }
   
    public static synchronized Context getContext(){
        return mContext;
    }
    public void initAnalytics(){}
    public void initConfig(){}
    public void initCrashHandler(){}
    public void initSoundManager(){}
}
