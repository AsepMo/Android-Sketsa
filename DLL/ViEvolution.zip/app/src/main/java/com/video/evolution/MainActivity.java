package com.video.evolution;

import android.support.annotation.ColorInt;
import android.support.annotation.ColorRes;
import android.support.annotation.Nullable;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.TransitionDrawable;
import android.app.Activity;
import android.content.DialogInterface;
import android.content.Context;
import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;
import android.os.Handler;
import android.view.Gravity;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import com.yanzhenjie.permission.Action;
import com.yanzhenjie.permission.AndPermission;
import com.yanzhenjie.permission.runtime.Permission;
import com.yanzhenjie.permission.runtime.PermissionDef;

import com.video.evolution.application.Application;
import com.video.evolution.application.ApplicationFragment;
import com.video.evolution.application.ApplicationPreferences;
import com.video.evolution.engine.app.theme.Theme;
import com.video.evolution.engine.app.folders.FolderMe;
import com.video.evolution.engine.app.folders.FileMe;
import com.video.evolution.engine.app.folders.Storage;
import com.video.evolution.engine.app.utils.ScreenUtils;
import com.video.evolution.engine.app.menu.DrawerAdapter;
import com.video.evolution.engine.app.menu.DrawerItem;
import com.video.evolution.engine.app.menu.SimpleItem;
import com.video.evolution.engine.app.menu.SpaceItem;
import com.video.evolution.engine.app.rationals.RuntimeRationale;
import com.video.evolution.engine.widget.VideoLayout;
import com.video.evolution.engine.widget.SlidingRootNav;
import com.video.evolution.engine.widget.SlidingRootNavBuilder;

public class MainActivity extends AppCompatActivity implements DrawerAdapter.OnItemSelectedListener {

    private static final String TAG = MainActivity.class.getSimpleName();
    public static void start(Context c)
    {
        Intent mApplication = new Intent(c, MainActivity.class);
        c.startActivity(mApplication);
    }
    
    private static final int POS_VIDEO_PLAYER = 0;
    private static final int POS_VIDEO_LIBRARY = 1;
    private static final int POS_VIDEO_FOLDER = 2;
    private static final int POS_VIDEO_DOWNLOAD = 3;
    private static final int POS_LOGOUT = 5;

    private String[] screenTitles;
    private Drawable[] screenIcons;

    private VideoLayout mVideoLayout;
    private SlidingRootNav slidingRootNav;
    private Handler mHandler = new Handler(); 
    private Runnable mFirstTimeRunner = new Runnable()
    {
        @Override 
        public void run() {
            mVideoLayout.setPathOrUrl("videolayout.mp4");     
        }
    }; 
    

    private View mCardLayout;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Theme.getInstance().setTheme(this);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);
		
		Toolbar mToolbar = (Toolbar)findViewById(R.id.toolbar);
		setSupportActionBar(mToolbar);
        
        slidingRootNav = new SlidingRootNavBuilder(this)
            .withToolbarMenuToggle(mToolbar)
            .withMenuOpened(false)
            .withContentClickableWhenMenuOpened(false)
            .withSavedState(savedInstanceState)
            .withMenuLayout(R.layout.menu_left_drawer)
            .inject();

        mVideoLayout = (VideoLayout)findViewById(R.id.videoLayout);
        mHandler.postDelayed(mFirstTimeRunner, 200);
        
        screenIcons = loadScreenIcons();
        screenTitles = loadScreenTitles();

        DrawerAdapter adapter = new DrawerAdapter(Arrays.asList(
                                                      createItemFor(POS_VIDEO_PLAYER).setChecked(true),
                                                      createItemFor(POS_VIDEO_LIBRARY),
                                                      createItemFor(POS_VIDEO_FOLDER),
                                                      createItemFor(POS_VIDEO_DOWNLOAD),
                                                      new SpaceItem(48),
                                                      createItemFor(POS_LOGOUT)));
        adapter.setListener(this);

        RecyclerView list = findViewById(R.id.list);
        list.setNestedScrollingEnabled(false);
        list.setLayoutManager(new LinearLayoutManager(this));
        list.setAdapter(adapter);

        adapter.setSelected(POS_VIDEO_PLAYER);
  
        
        mCardLayout = findViewById(R.id.cardview);
        ScreenUtils.setScaleAnimation(mCardLayout, 2000);
        
        requestPermissionStorage(Permission.Group.STORAGE);
    }

    public void requestPermissionStorage(@PermissionDef String... permissions) {
        AndPermission.with(MainActivity.this)
            .runtime()
            .permission(permissions)
            .rationale(new RuntimeRationale())
            .onGranted(new Action<List<String>>() {
                @Override
                public void onAction(List<String> permissions) {
                    Toast toast = Toast.makeText(MainActivity.this, getString(R.string.permission_successfully), 0);
                    toast.setDuration(3000);
                    toast.setGravity(Gravity.TOP, 100,100);
                    toast.show();
                    FolderMe.initVideoBox(MainActivity.this);
                    FileMe.FileMe(MainActivity.this, getString(R.string.app_name), "video.dat");
                }
            })
            .onDenied(new Action<List<String>>() {
                @Override
                public void onAction(@NonNull List<String> permissions) {
                    Toast.makeText(MainActivity.this, getString(R.string.permission_failure), Toast.LENGTH_SHORT).show();
                    if (AndPermission.hasAlwaysDeniedPermission(MainActivity.this, permissions)) {
                        //PermissionUtils.getInstance().showSettingDialog(MainActivity.this, permissions);
                    }
                }
            })
            .start();
    }
    
    @Override
    public void onItemSelected(int position) {

        if (position == POS_VIDEO_PLAYER) {
            showFragment(ApplicationFragment.createFor("Video Player"));
        }
        else if (position == POS_VIDEO_LIBRARY) {
           // showFragment(VideoLibraryFragment.createFor("Video Library"));
        }
        else if (position == POS_VIDEO_FOLDER) {
            //showFragment(VideoFolderFragment.createFor("Video Folder"));
        }
        else if (position == POS_VIDEO_DOWNLOAD) {
            //showFragment(VideoDownloadFragment.createFor("Video Download"));
        }

        else if (position == POS_LOGOUT) {
            Application.getInstance().exitApplication(this);
        }
        slidingRootNav.closeMenu();
    }

    private void showFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    }

    private DrawerItem createItemFor(int position) {
        return new SimpleItem(screenIcons[position], screenTitles[position])
            .withIconTint(color(R.color.textColorSecondary))
            .withTextTint(color(R.color.textColorPrimary))
            .withSelectedIconTint(color(R.color.colorAccent))
            .withSelectedTextTint(color(R.color.colorAccent));
    }

    private String[] loadScreenTitles() {
        return getResources().getStringArray(R.array.ld_activityScreenTitles);
    }

    private Drawable[] loadScreenIcons() {
        TypedArray ta = getResources().obtainTypedArray(R.array.ld_activityScreenIcons);
        Drawable[] icons = new Drawable[ta.length()];
        for (int i = 0; i < ta.length(); i++) {
            int id = ta.getResourceId(i, 0);
            if (id != 0) {
                icons[i] = ContextCompat.getDrawable(this, id);
            }
        }
        ta.recycle();
        return icons;
    }

    @ColorInt
    private int color(@ColorRes int res) {
        return ContextCompat.getColor(this, res);
    }

    @Override
    protected void onResume() {
        super.onResume();
        Theme.getInstance().getTheme(this);
        mVideoLayout.onResumeVideoLayout(); 
    }

    @Override
    public void onPause() {
        super.onPause();
        mHandler.removeCallbacks(mFirstTimeRunner);
        mVideoLayout.onPauseVideoLayout(); 
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(mFirstTimeRunner);
        mVideoLayout.onDestroyVideoLayout();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_application, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            // launch settings activity
            ApplicationPreferences.start(MainActivity.this);
            return true;
        } 

        return super.onOptionsItemSelected(item);
    }
}
