package com.thirtydegreesray.openhub.mvp.model.filter;

/**
 * Created by ThirtyDegreesRay on 2017/9/26 11:13:48
 */

public enum SortDirection {
    Desc, Asc
}
