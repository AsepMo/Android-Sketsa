

package com.thirtydegreesray.openhub.ui.activity;

/**
 * Created by ThirtyDegreesRay on 2017/10/21 12:59:52
 */

public interface MarkdownEditorCallback {
    String getText();

    boolean isTextChanged();
}
