package com.thirtydegreesray.openhub.mvp.model.filter;

/**
 * Created by ThirtyDegreesRay on 2018/1/5 12:00:14
 */

public enum TrendingSince {
    Daily, Weekly, Monthly
}
