package com.search.box.application;

import android.support.annotation.ColorInt;
import android.support.annotation.ColorRes;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.view.ViewPager;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import java.util.Arrays;
import java.util.ArrayList;
import java.lang.ref.WeakReference;

import com.search.box.R;
import com.search.box.engine.app.fragments.WebBrowserFragment;
import com.search.box.engine.widget.SpeakerBox;
import android.speech.tts.TextToSpeech;

public class ApplicationActivity extends AppCompatActivity {
    public static String TAG = ApplicationActivity.class.getSimpleName();
    public static void start(Context c) {
        Intent mIntent = new Intent(c, ApplicationActivity.class);
        c.startActivity(mIntent);
    }
    
    private SpeakerBox speakerbox;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);

        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        speakerbox = new SpeakerBox(getApplication());
        speakerbox.setActivity(this);
        speakerbox.setQueueMode(TextToSpeech.QUEUE_ADD);
        speakerbox.setQueueMode(TextToSpeech.QUEUE_FLUSH);
        speakerbox.requestAudioFocus();
        speakerbox.abandonAudioFocus();
        
        switchFragment(WebBrowserFragment.newInstance("AsepMo"));
    }

    public void switchFragment(Fragment fragment){
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    } 
}
