package com.search.box.application;

public class PrivacySettingsActivity {
    
}
