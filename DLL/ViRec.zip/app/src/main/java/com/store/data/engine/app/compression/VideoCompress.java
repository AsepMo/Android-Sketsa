package com.store.data.engine.app.compression;

import android.content.Context;
import android.os.Environment;

import java.net.URISyntaxException;
import java.io.File;

import com.store.data.engine.app.compression.MediaController;
import com.store.data.engine.app.tasks.VideoCompressTask;

public class VideoCompress {
    
    public static VideoCompressTask compressVideo(Context c, String srcPath, String destPath, ProgressListener listener) {
        VideoCompressTask task = new VideoCompressTask(c, listener);
        task.execute(srcPath, destPath);
        return task;
    }

    public static interface ProgressListener {

        void onStart();
        void onFinish(boolean result);
        void onProgress(float progress);

    }
    
    public static String getVideoFile() {
        
        return MediaController.cachedFile.getPath();
    }
    
    public static String getOutPut() {
        File outPutDir = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM), "record-video");
        if (!outPutDir.exists()) {
            outPutDir.mkdirs();
        } 
        return outPutDir.getAbsolutePath();
    }
}
