package com.store.data.engine.app.utils;

import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.content.Context;
import android.view.View;
import android.widget.Button;
import com.store.data.R;

public class ViewRecord {
    public static void setRecorder(ViewPager mViewPager, final Button rectangle_1,final Button rectangle_2) {   
        mViewPager.setOffscreenPageLimit(2);
        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {

                @Override
                public void onPageSelected(int position) {
                    // TODO Auto-generated method stub
                    switch (position) {
                        case 0:
                            rectangle_1
                                .setBackgroundResource(R.drawable.rectangle_bg_orange);
                            rectangle_2
                                .setBackgroundResource(R.drawable.rectangle_bg_white);
                            break;

                        case 1:
                            rectangle_1
                                .setBackgroundResource(R.drawable.rectangle_bg_white);
                            rectangle_2
                                .setBackgroundResource(R.drawable.rectangle_bg_orange);
                            break;

                        default:
                            break;
                    }
                }

                @Override
                public void onPageScrolled(int arg0, float arg1, int arg2) {
                    // TODO Auto-generated method stub

                }

                @Override
                public void onPageScrollStateChanged(int arg0) {
                    // TODO Auto-generated method stub

                }
            });
    }
    
    public static void setCurrentView(ViewPager mViewPager) {
        mViewPager.setCurrentItem(1);
    } 
}
