package com.store.data.application;

import android.Manifest;
import android.support.annotation.Nullable;
import android.support.annotation.NonNull;
import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.os.AsyncTask;
import android.util.Log;
import android.view.View;
import android.view.Gravity;
import android.widget.Toast;

import java.io.File;
import java.util.List;
import java.util.ArrayList;

import com.store.data.R;
import com.store.data.AppController;
import com.store.data.engine.app.tasks.DeleteTask;
import com.store.data.engine.app.utils.Utils;

public class Application {
    
    private static final String TAG = Application.class.getSimpleName();
    private static volatile Application Instance = null;
    private Context context;

    public static Application getInstance() {
        Application localInstance = Instance;
        if (localInstance == null) {
            synchronized (Application.class) {
                localInstance = Instance;
                if (localInstance == null) {
                    Instance = localInstance = new Application(AppController.getContext());
                }
            }
        }
        return localInstance;
    }

    private Application(Context context) {
        this.context = context;
        //FolderMe.initVideoBox(context);
        //FileMe.getInstance().FileMe(context, context.getString(R.string.app_name), "video.dat", "Welcome To ViSplash");
    }

    public static Application with(Context context) {
        return new Application(context);
    }
    
   /* public void setPermission(Activity act, String[] permissions, final OnActionPermissionListener mOnActionPermissionListener) {      
        PermissionsManager.getInstance().requestPermissionsIfNecessaryForResult(act, permissions, new PermissionsResultAction() {
                @Override
                public void onGranted() {
                    mOnActionPermissionListener.onGranted();
                }


                @Override
                public void onDenied(String permission) {
                    mOnActionPermissionListener.onDenied(permission);
                }
            });
    }

    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,  @NonNull int[] grantResults) {
        Log.i(TAG, "Activity-onRequestPermissionsResult() PermissionsManager.notifyPermissionsChange()");
        PermissionsManager.getInstance().notifyPermissionsChange(permissions, grantResults);
    }*/
    
    public void setOnApplicationTaskListener(final Activity act, final OnApplicationTaskListener listener) {

        DeleteTask task = new DeleteTask(act);
        task.setOnDeleteTaskListener(new DeleteTask.OnDeleteTaskListener(){
                @Override
                public void onPreExecute() {
                    listener.onPreExecute();
                }
                @Override
                public void onSuccess(List<String> result) {
                    listener.onSuccess(result); 
                }

                @Override
                public void onFailed() {
                    listener.onFailed(); 
                } 

                @Override
                public void isEmpty() {
                    listener.isEmpty();
                } 
            });
        task.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, new String[]{Utils.getFolderRecord(context)});    
    }
    
    public interface OnActionPermissionListener {
        void onGranted();
        void onDenied(String permission);
    }

    public interface OnApplicationTaskListener {
        void onPreExecute();
        void onSuccess(List<String> result);
        void onFailed();
        void isEmpty();
    }
}
