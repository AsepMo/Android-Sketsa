package com.store.data.engine.widget;


public interface ScrollDirectionListener {
    void onScrollDown();

    void onScrollUp();
}
