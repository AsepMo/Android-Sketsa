package com.store.data.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.support.v4.app.NotificationCompat;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.MediaRecorder;
import android.os.Build;
import android.os.IBinder;
import android.preference.PreferenceManager;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import com.store.data.R;
import com.store.data.application.ApplicationActivity;
import com.store.data.engine.app.data.AudioRecordDb;
import com.store.data.engine.app.settings.MySharedPreferences;

public class AudioRecordingService extends Service {

    private static final String LOG_TAG = AudioRecordingService.class.getSimpleName();
    private static final String CHANNEL_WHATEVER = "channel_whatever";
    private static final int NOTIFY_ID = 9906;
    private static final String BASE = "com.store.data.services.AudioRecordingService.";
    public static final String ACTION_SERVICE_READY = BASE + "ACTION_SERVICE_READY";
    public static final String ACTION_RECORD = BASE + "ACTION_RECORD";
    public static final String ACTION_STOP = BASE + "ACTION_STOP";
    public static final String ACTION_SHUTDOWN = BASE + "ACTION_SHUTDOWN";
    public static final String ACTION_QUERY_STATUS = BASE + "ACTION_QUERY_STATUS";
    public static final String ACTION_QUERY_STATUS_RESULT = BASE + "ACTION_QUERY_STATUS_RESULT";
    public static final String EXTRA_QUERY_RESULT_READY = BASE + "EXTRA_QUERY_RESULT_READY";
    public static final String EXTRA_QUERY_RESULT_RECORDING = BASE + "EXTRA_QUERY_RESULT_RECORDING";
    public static final String EXTRA_QUERY_RESULT_PAUSING = BASE + "EXTRA_QUERY_RESULT_PAUSING";
    public static final String EXTRA_QUERY_RESULT_SHUTDOWN = BASE + "EXTRA_QUERY_RESULT_SHUTDOWN";

    public static final String EXTRA_SERVICE_IS_READY = "EXTRA_SERVICE_IS_READY";
    public static final String EXTRA_VIDEO_NAME = "EXTRA_VIDEO_NAME";
    public static final String EXTRA_VIDEO_PATH = "EXTRA_VIDEO_PATH";
    public static final String EXTRA_VIDEO_DURATION = "EXTRA_VIDEO_DURATION";
    
    private boolean isForeground = false;
    
    private boolean recordOnNextStart = false;
    private AudioRecordingSession session = null;
    private AudioRecordDb mDataBase;
    @Override
    public IBinder onBind(Intent intent) {
        throw new IllegalStateException("go away");
    }

    public interface OnTimerChangedListener {
        void onTimerChanged(int seconds);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        mDataBase = new AudioRecordDb(getApplicationContext());
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (ACTION_SERVICE_READY.equals(intent.getAction())) {
            boolean service_is_ready = intent.getBooleanExtra(EXTRA_SERVICE_IS_READY, true);
            
            if (recordOnNextStart) {
                startRecorder();
            }

            foregroundify(!recordOnNextStart);
            recordOnNextStart = false;
            final Intent result = new Intent();
            result.setAction(ACTION_QUERY_STATUS_RESULT);    
            result.putExtra(EXTRA_QUERY_RESULT_READY, service_is_ready);
            sendBroadcast(result);
        } else if (ACTION_RECORD.equals(intent.getAction())) {        
            foregroundify(false);
            startRecorder();           
        } else if (ACTION_STOP.equals(intent.getAction())) {
            foregroundify(true);
            stopRecorder();       
        } else if (ACTION_SHUTDOWN.equals(intent.getAction())) {
            stopSelf();
            final Intent result = new Intent();
            result.setAction(ACTION_QUERY_STATUS_RESULT);
            result.putExtra(EXTRA_QUERY_RESULT_SHUTDOWN, true);
            sendBroadcast(result);
        }

        
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        
        stopRecorder();
        stopForeground(true);
        super.onDestroy();
    }


    private void foregroundify(boolean showRecord) {
        NotificationManager mgr = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            mgr.getNotificationChannel(CHANNEL_WHATEVER) == null) {
            mgr.createNotificationChannel(new NotificationChannel(CHANNEL_WHATEVER,
                                                                  "Whatever", NotificationManager.IMPORTANCE_DEFAULT));
        }

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_WHATEVER);

        b.setAutoCancel(true);
        //.setDefaults(Notification.DEFAULT_ALL);

        b.setContentTitle(getString(R.string.app_name))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setTicker(getString(R.string.app_name));

        if (showRecord) {
            b.addAction(R.drawable.ic_video_record,
                        getString(R.string.notify_record), buildPendingIntent(ACTION_RECORD));
        } else {
            b.addAction(R.drawable.ic_pause,
                        getString(R.string.notify_stop), buildPendingIntent(ACTION_STOP));
        }

        b.addAction(R.drawable.ic_play,
                    getString(R.string.notify_shutdown), buildPendingIntent(ACTION_SHUTDOWN));

        if (isForeground) {
            mgr.notify(NOTIFY_ID, b.build());
        } else {
            startForeground(NOTIFY_ID, b.build());
            isForeground = true;
        }
    }
    
    private PendingIntent buildPendingIntent(String action) {
        Intent i = new Intent(this, getClass());
        i.setAction(action);
        return(PendingIntent.getService(this, 0, i, 0));
    }
    
    public synchronized void startRecorder() {
        if (session == null) {        
            session = new AudioRecordingSession(this, mDataBase);
            session.createNotification();
            session.start();
            final Intent result = new Intent();
            result.setAction(ACTION_QUERY_STATUS_RESULT);
            result.putExtra(EXTRA_QUERY_RESULT_RECORDING, true);
            sendBroadcast(result);
        }
    }
    
    public synchronized void stopRecorder() {
        if (session != null) {
            session.stop();
            session = null; 
        }
    }
    
    

}

