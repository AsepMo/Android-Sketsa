package com.store.data.engine.app.adapters;

import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Matrix;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.media.MediaScannerConnection;
import android.media.ThumbnailUtils;
import android.provider.MediaStore;
import android.net.Uri;
import android.os.Environment;
import android.util.Base64;
import android.util.Log;
import android.text.format.DateUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import com.store.data.R;
import com.store.data.engine.app.models.RecordingItem;
import com.store.data.engine.app.fragments.AudioViewerFragment;
import com.store.data.engine.app.listeners.OnDatabaseChangedListener;
import com.store.data.engine.app.data.ScreenRecordDb;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class ScreenRecordAdapter extends RecyclerView.Adapter<ScreenRecordAdapter.HistoryViewHolder> implements OnDatabaseChangedListener {
    private String TAG = ScreenRecordAdapter.class.getSimpleName();
    private ScreenRecordDb mDatabase;

    private RecordingItem item;
    private Context mContext;
    private LinearLayoutManager llm;

    public ScreenRecordAdapter(Context context, LinearLayoutManager linearLayoutManager) {
        super();
        mContext = context;
        mDatabase = new ScreenRecordDb(mContext);
        mDatabase.setOnDatabaseChangedListener(this);
        llm = linearLayoutManager;
    }

    @Override
    public void onBindViewHolder(final HistoryViewHolder holder, final int position) {

        item = getItem(position);
        long itemDuration = item.getLength();

        long minutes = TimeUnit.MILLISECONDS.toMinutes(itemDuration);
        long seconds = TimeUnit.MILLISECONDS.toSeconds(itemDuration)
            - TimeUnit.MINUTES.toSeconds(minutes);

        // Set the text for textView
        Typeface fontuc = Typeface.createFromAsset(mContext.getAssets(), "fonts/uicksandregular.otf");
        holder.vTitle.setTypeface(fontuc);
        holder.vTitle.setText(item.getName());
        holder.vDuration.setText(String.format("%02d:%02d", minutes, seconds));
        Bitmap thumb = ThumbnailUtils.createVideoThumbnail(item.getFilePath(), MediaStore.Video.Thumbnails.MINI_KIND);
        Matrix matrix = new Matrix();
        Bitmap bitmap = Bitmap.createBitmap(thumb, 0, 0, thumb.getWidth(), thumb.getHeight(), matrix, true);

        holder.vThumbnails.setImageBitmap(bitmap);
        holder.playButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    RecordingItem vid = getItem(holder.getPosition());
                    File file = new File(vid.getFilePath());
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    intent.setDataAndType(Uri.fromFile(file), "video/*");
                    mContext.startActivity(intent);
                }
            });
        holder.shareButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    shareFileDialog(holder.getPosition());
                }
            });
        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    deleteFileDialog(holder.getPosition());
                }
            });
    }

    @Override
    public HistoryViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.
            from(parent.getContext()).
            inflate(R.layout.items_history_record, parent, false);

        mContext = parent.getContext();

        return new HistoryViewHolder(itemView);
    }

    public static class HistoryViewHolder extends RecyclerView.ViewHolder {
        protected ImageView vThumbnails;
        protected TextView vTitle;
        protected TextView vDuration;
        protected ImageButton playButton;
        protected ImageButton deleteButton;
        protected ImageButton shareButton;

        public HistoryViewHolder(View rowView) {
            super(rowView);
            vThumbnails = (ImageView) rowView.findViewById(R.id.ivFileThumbnail);
            vTitle = (TextView) rowView.findViewById(R.id.tvDate);
            vDuration = (TextView) rowView.findViewById(R.id.tvDuration);       
            playButton = (ImageButton) rowView.findViewById(R.id.btnPlay);
            shareButton = (ImageButton) rowView.findViewById(R.id.btnShare);
            deleteButton = (ImageButton) rowView.findViewById(R.id.btnDelete);
        }
    }

    @Override
    public int getItemCount() {
        return mDatabase.getCount();
    }

    public RecordingItem getItem(int position) {
        return mDatabase.getItemAt(position);
    }

    @Override
    public void onNewDatabaseEntryAdded() {
        //item added to top of the list
        notifyItemInserted(getItemCount() - 1);
        llm.scrollToPosition(getItemCount() - 1);
    }

    @Override
    //TODO
    public void onDatabaseEntryRenamed() {

    }

    public void remove(int position) {
        //remove item from database, recyclerview and storage

        //delete file from storage
        File file = new File(getItem(position).getFilePath());
        file.delete();

        Toast.makeText(
            mContext,
            String.format(
                mContext.getString(R.string.toast_file_delete),
                getItem(position).getName()
            ),
            Toast.LENGTH_SHORT
        ).show();

        mDatabase.removeItemWithId(getItem(position).getId());
        notifyItemRemoved(position);
    }

    //TODO
    public void removeOutOfApp(String filePath) {
        //user deletes a saved recording out of the application through another application
    }

    public void rename(int position, String name) {
        //rename a file

        String mFilePath = Environment.getExternalStorageDirectory().getAbsolutePath();
        mFilePath += "/SoundRecorder/" + name;
        File f = new File(mFilePath);

        if (f.exists() && !f.isDirectory()) {
            //file name is not unique, cannot rename file.
            Toast.makeText(mContext,
                           String.format(mContext.getString(R.string.toast_file_exists), name),
                           Toast.LENGTH_SHORT).show();

        } else {
            //file name is unique, rename file
            File oldFilePath = new File(getItem(position).getFilePath());
            oldFilePath.renameTo(f);
            mDatabase.renameItem(getItem(position), name, mFilePath);
            notifyItemChanged(position);
        }
    }

    public void shareFileDialog(int position) {
        Intent shareIntent = new Intent();
        shareIntent.setAction(Intent.ACTION_SEND);
        shareIntent.putExtra(Intent.EXTRA_STREAM, Uri.fromFile(new File(getItem(position).getFilePath())));
        shareIntent.setType("audio/mp4");
        mContext.startActivity(Intent.createChooser(shareIntent, mContext.getText(R.string.record_send_to)));
    }

    public void renameFileDialog(final int position) {
        // File rename dialog
        AlertDialog.Builder renameFileBuilder = new AlertDialog.Builder(mContext);

        LayoutInflater inflater = LayoutInflater.from(mContext);
        View view = inflater.inflate(R.layout.dialog_rename_file, null);

        final EditText input = (EditText) view.findViewById(R.id.new_name);

        renameFileBuilder.setTitle(mContext.getString(R.string.dialog_title_rename));
        renameFileBuilder.setCancelable(true);
        renameFileBuilder.setPositiveButton(mContext.getString(R.string.dialog_action_ok),
            new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    try {
                        String value = input.getText().toString().trim() + ".mp4";
                        rename(position, value);

                    } catch (Exception e) {
                        Log.e(TAG, "exception", e);
                    }

                    dialog.cancel();
                }
            });
        renameFileBuilder.setNegativeButton(mContext.getString(R.string.dialog_action_cancel),
            new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                }
            });

        renameFileBuilder.setView(view);
        AlertDialog alert = renameFileBuilder.create();
        alert.show();
    }

    public void deleteFileDialog(final int position) {
        // File delete confirm
        AlertDialog.Builder confirmDelete = new AlertDialog.Builder(mContext);
        confirmDelete.setTitle(mContext.getString(R.string.dialog_title_delete));
        confirmDelete.setMessage(mContext.getString(R.string.dialog_text_delete));
        confirmDelete.setCancelable(true);
        confirmDelete.setPositiveButton(mContext.getString(R.string.dialog_action_yes),
            new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    try {
                        //remove item from database, recyclerview, and storage
                        remove(position);

                    } catch (Exception e) {
                        Log.e(TAG, "exception", e);
                    }

                    dialog.cancel();
                }
            });
        confirmDelete.setNegativeButton(mContext.getString(R.string.dialog_action_no),
            new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    dialog.cancel();
                }
            });

        AlertDialog alert = confirmDelete.create();
        alert.show();
    }

    public String BitMapToString(Bitmap bitmap) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] b = baos.toByteArray();
        String temp = Base64.encodeToString(b, Base64.DEFAULT);
        return temp;
    }

    private Bitmap loadImageFromStorage(String path) {
        Bitmap b = null;
        try {
            File f = new File(path);
            b = BitmapFactory.decodeStream(new FileInputStream(f));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        return b;

    }
}
