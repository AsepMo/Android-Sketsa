package com.store.data.application;

public class ApplicationCamera {
    
    public static String TAG = ApplicationCamera.class.getSimpleName();
    
}