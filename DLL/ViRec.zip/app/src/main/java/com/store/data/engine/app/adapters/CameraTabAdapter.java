package com.store.data.engine.app.adapters;

import java.util.ArrayList;
import java.util.List;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.view.View;
import android.view.ViewGroup;

import com.store.data.engine.app.fragments.CameraRecordFragment;
import com.store.data.engine.app.fragments.CameraHistoryRecord;

public class CameraTabAdapter extends android.support.v4.app.FragmentPagerAdapter {
    private String[] titles = { "Camera","History Record" };

    public CameraTabAdapter(FragmentManager fm) {
        super(fm);
        // TODO Auto-generated constructor stub
    }

    @Override
    public Fragment getItem(int position) {
        // TODO Auto-generated method stub
        switch(position){
            case 0:{
                    return CameraRecordFragment.newInstance(position);
                }
            case 1:{
                    return CameraHistoryRecord.newInstance(position);
                }
        }
        return null;
    }


    @Override
    public int getCount() {
        return titles.length;
    }

    @Override
    public CharSequence getPageTitle(int position) {
        return titles[position];
    }
}

