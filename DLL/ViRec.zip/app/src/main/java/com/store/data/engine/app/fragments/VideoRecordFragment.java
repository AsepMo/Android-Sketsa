package com.store.data.engine.app.fragments;

import android.support.v4.app.Fragment;
import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Environment;
import android.os.Bundle;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.io.FileUtils;

import com.store.data.R;
import com.store.data.application.ApplicationActivity;
import com.store.data.application.ApplicationVideoPreview;
import com.store.data.engine.app.recorder.CameraView;
import com.store.data.engine.app.recorder.listener.CameraListener;
import com.store.data.engine.app.recorder.listener.ErrorListener;
import com.store.data.engine.app.recorder.listener.RecordStateListener;
import com.store.data.engine.app.recorder.listener.SimpleClickListener;
import com.store.data.engine.app.recorder.util.ExtractVideoInfoUtil;
import com.store.data.engine.app.recorder.util.FileUtil;
import com.store.data.engine.app.compression.VideoCompress;
import com.store.data.engine.app.utils.Utils;
import com.store.data.engine.app.data.VideoRecordDb;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.net.URISyntaxException;

public class VideoRecordFragment extends Fragment {

    private static final String ARG_POSITION = "position";
    private static final String TAG = VideoRecordFragment.class.getSimpleName();
    
    private CameraView mCameraView;
    private int position;
    private VideoRecordDb mDataBase;
    private long mStartingTimeMillis = 0;
    private long mElapsedMillis = 0;
    private ProgressDialog mProgressDialog;
    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    public static VideoRecordFragment newInstance(int position) {
        VideoRecordFragment f = new VideoRecordFragment();
        Bundle b = new Bundle();
        b.putInt(ARG_POSITION, position);
        f.setArguments(b);

        return f;
    }

    public VideoRecordFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        position = getArguments().getInt(ARG_POSITION);
        mDataBase = new VideoRecordDb(getActivity());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_video_record, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mCameraView = (CameraView)view.findViewById(R.id.jcameraview);

        mCameraView.setSaveVideoPath(Utils.getFolderRecord(getActivity()));
        mCameraView.setMinDuration(3000); 
        mCameraView.setDuration(10000); 
        mCameraView.setFeatures(CameraView.BUTTON_STATE_ONLY_RECORDER);
        mCameraView.setTip("Tekan Selama, 3~10 detik");
        mCameraView.setRecordShortTip(" Tekan Selama 3~10 detik");
        mCameraView.setMediaQuality(CameraView.MEDIA_QUALITY_MIDDLE);
        mCameraView.setErrorLisenter(new ErrorListener() {
                @Override
                public void onError() {               
                    Log.e(TAG, "camera error");
                    Intent intent = new Intent();
                    getActivity().setResult(103, intent);
                    getActivity().finish();
                }

                @Override
                public void AudioPermissionError() {
                    Toast.makeText(getActivity(), "Permission Audio Denied?", Toast.LENGTH_SHORT).show();
                }
            });

        mProgressDialog = new ProgressDialog(getActivity());
        mCameraView.setCameraLisenter(new CameraListener() {
                @Override
                public void captureSuccess(Bitmap bitmap) {               
                    Log.d(TAG, "bitmap = " + bitmap.getWidth());
                }

                @Override
                public void recordSuccess(String url, Bitmap firstFrame) {               
                    Log.d(TAG, "url:" + url);
                    File file = new File(url);
                    
                    try {
                     
                        String inputPath = Utils.getFilePath(getActivity(), Uri.fromFile(file));
                     
                        VideoCompress.compressVideo(getActivity(), inputPath, VideoCompress.getOutPut(), new VideoCompress.ProgressListener(){
                                @Override
                                public void onStart() {
                                    mProgressDialog.setMessage("Please wait..");
                                    mProgressDialog.show();
                                }
                                @Override
                                public void onFinish(boolean result) {

                                    if (result) {

                                       ExtractVideoInfoUtil extractVideoInfoUtil = new ExtractVideoInfoUtil(VideoCompress.getVideoFile());
                                        Bitmap bitmap = extractVideoInfoUtil.extractFrame();
                                        String firstFrameFilePath = FileUtil.saveBitmap(VideoCompress.getOutPut(), bitmap);
                                        if (bitmap != null && !bitmap.isRecycled()) {
                                            bitmap.recycle();
                                            bitmap = null;
                                        }
                                        Log.d(TAG, "FirstFrame FilePath: " + firstFrameFilePath);

                                        mProgressDialog.dismiss();

                                        try {
                                            mDataBase.addRecording(new File(VideoCompress.getVideoFile()).getName(), VideoCompress.getVideoFile(), mElapsedMillis);                                    
                                        } catch (Exception e) {
                                            Log.e(TAG, "exception", e);
                                        }
                                        ApplicationVideoPreview.startActivity(getActivity(), VideoCompress.getVideoFile(), firstFrameFilePath);                                        
                                    } else {

                                        Utils.writeFile(getActivity(), "Failed Compress!!!" + new SimpleDateFormat("HH:mm:ss").format(new Date()));
                                    }
                                }

                                @Override
                                public void onProgress(float percent) {
                                    mProgressDialog.setMessage(String.valueOf(percent) + "%");
                                }

                            });

                    } catch (URISyntaxException e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();                               
                    }

                    // Toast.makeText(getActivity(), "url: " + url, Toast.LENGTH_SHORT).show();               
                }
            });
        mCameraView.setLeftClickListener(new SimpleClickListener() {
                @Override
                public void onClick() {
                    ApplicationActivity atc = (ApplicationActivity)getActivity();
                    // atc.setCurrentView();
                }
            });
        mCameraView.setRightClickListener(new SimpleClickListener() {
                @Override
                public void onClick() {
                    Toast.makeText(getActivity(), "Right", Toast.LENGTH_SHORT).show();
                }
            });
        mCameraView.setRecordStateListener(new RecordStateListener() {
                @Override
                public void recordStart() {
                    mStartingTimeMillis = System.currentTimeMillis();  
                }

                @Override
                public void recordEnd(long time) {
                    mElapsedMillis = (System.currentTimeMillis() - mStartingTimeMillis);

                    Log.d(TAG, "录制完毕，录制时长：" + time);
                }

                @Override
                public void recordCancel() {

                }


            });
    }

    
    @Override
    public void onResume() {
        super.onResume();
        mCameraView.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        mCameraView.onPause();
        mCameraView.removeAllViews();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
    }

}
