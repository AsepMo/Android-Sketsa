package com.store.data.engine.app.fragments;

import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.FileObserver;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


import com.store.data.R;
import com.store.data.engine.app.adapters.CameraRecordAdapter;

public class CameraHistoryRecord extends Fragment{
    private static final String ARG_POSITION = "position";
    private static final String TAG = CameraHistoryRecord.class.getSimpleName();

    private int position;
    private CameraRecordAdapter mCameraRecordAdapter;
    boolean sortOrderAscending = true;

    public static CameraHistoryRecord newInstance(int position) {
        CameraHistoryRecord f = new CameraHistoryRecord();
        Bundle b = new Bundle();
        b.putInt(ARG_POSITION, position);
        f.setArguments(b);

        return f;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        position = getArguments().getInt(ARG_POSITION);
       // observer.startWatching();
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_history_record, container, false);
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView mTitle = (TextView) view.findViewById(R.id.textViewLay1);
        Typeface typeFaces = Typeface.createFromAsset(getActivity().getAssets(), "fonts/capture.ttf");
        mTitle.setTypeface(typeFaces);
        mTitle.setText("Records \n\n");

        ImageButton filterButton = (ImageButton) view.findViewById(R.id.ibFilter);

        RecyclerView mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        //newest to oldest order (database stores from oldest to newest)
        llm.setReverseLayout(true);
        llm.setStackFromEnd(true);

        mRecyclerView.setLayoutManager(llm);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mCameraRecordAdapter = new CameraRecordAdapter(getActivity(), llm);
        mRecyclerView.setAdapter(mCameraRecordAdapter); 
        filterButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sortOrderAscending = !sortOrderAscending;
                    mCameraRecordAdapter.notifyDataSetChanged();
                }
            });
    }

   /* FileObserver observer = new FileObserver(android.os.Environment.getExternalStorageDirectory().toString() + "/SoundRecorder") {
        // set up a file observer to watch this directory on sd card
        @Override
        public void onEvent(int event, String file) {
            if(event == FileObserver.DELETE){
                // user deletes a recording file out of the app

                String filePath = android.os.Environment.getExternalStorageDirectory().toString()
                    + "/SoundRecorder" + file + "]";

                Log.d(TAG, "File deleted ["
                      + android.os.Environment.getExternalStorageDirectory().toString()
                      + "/SoundRecorder" + file + "]");

                // remove file from database and recyclerview
                mAudioRecordAdapter.removeOutOfApp(filePath);
            }
        }
    };*/
}




