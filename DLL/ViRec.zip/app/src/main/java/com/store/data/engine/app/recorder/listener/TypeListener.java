package com.store.data.engine.app.recorder.listener;

public interface TypeListener {
    void cancel();

    void confirm();
}
