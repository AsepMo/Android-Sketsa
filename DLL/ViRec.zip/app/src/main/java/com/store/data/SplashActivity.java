package com.store.data;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.os.Bundle;
import android.os.Handler;

import java.io.File;
import java.util.List;
import java.util.Locale;

import com.store.data.application.Application;
import com.store.data.application.ApplicationActivity;

public class SplashActivity extends AppCompatActivity {

    private Handler mHandler = new Handler();
    private Runnable mRunner = new Runnable(){
        @Override
        public void run(){
            Application.with(SplashActivity.this).setOnApplicationTaskListener(SplashActivity.this, new Application.OnApplicationTaskListener(){
                    @Override
                    public void onPreExecute() {
                        
                    }

                    @Override
                    public void onSuccess(List<String> result) {
                        ApplicationActivity.start(SplashActivity.this);  
                        SplashActivity.this.finish();                                  
                    }

                    @Override
                    public void onFailed() {
                        
                    }

                    @Override
                    public void isEmpty() {

                    } 
                    
                });                                                                
       
            
        }
    };
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme_NoActionBar);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
		
		Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
		setSupportActionBar(toolbar);
        mHandler.postDelayed(mRunner, 2000);
    }

    @Override
    protected void onPause() {
        super.onPause();
        mHandler.removeCallbacks(mRunner);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(mRunner);
    }
}
