package com.store.data.engine.app.recorder.listener;

public interface ErrorListener {
    void onError();

    void AudioPermissionError();
}
