package com.store.data.engine.app.fragments;

import android.support.v4.app.Fragment;
import android.app.Activity;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;

import com.store.data.R;
import com.store.data.services.AudioRecordingService;
import com.store.data.receivers.AudioRecording;
import com.store.data.receivers.AudioRecordingReceiver;
import com.store.data.engine.widget.FloatingActionButton;
import com.store.data.engine.widget.ViRecord;

import java.io.File;
import android.content.IntentFilter;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link RecordFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class AudioRecordFragment extends Fragment {
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_POSITION = "position";
    private static final String TAG = AudioRecordFragment.class.getSimpleName();

    private static final boolean DEBUG = false;
    private AudioRecordingReceiver recordingStatusReceiver; 
    private int position;
    
    //Recording controls
    private FloatingActionButton mRecordButton = null;
    private Button mPauseButton = null;

    private TextView mRecordingPrompt;
    private int mRecordPromptCount = 0;

    private boolean mStartRecording = true;
    private boolean mPauseRecording = true;

    private Chronometer mChronometer = null;
    long timeWhenPaused = 0; //stores time when user clicks pause button

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    public static AudioRecordFragment newInstance(int position) {
        AudioRecordFragment f = new AudioRecordFragment();
        Bundle b = new Bundle();
        b.putInt(ARG_POSITION, position);
        f.setArguments(b);

        return f;
    }

    public AudioRecordFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        position = getArguments().getInt(ARG_POSITION);
        
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View recordView = inflater.inflate(R.layout.fragment_audio_record, container, false);

        mChronometer = (Chronometer) recordView.findViewById(R.id.chronometer);
        //update recording prompt text
        mRecordingPrompt = (TextView) recordView.findViewById(R.id.recording_status_text);

        mRecordButton = (FloatingActionButton) recordView.findViewById(R.id.btnRecord);
        mRecordButton.setColorNormal(getResources().getColor(R.color.colorPrimary));
        mRecordButton.setColorPressed(getResources().getColor(R.color.colorPrimaryDark));
        mRecordButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    boolean isScreenRecord = ViRecord.isScreenRecordingRunning(getActivity());
                    if (!isScreenRecord) {
                        ViRecord.killScreenRecordingServices(getActivity());
                        onRecord(mStartRecording);
                        mStartRecording = !mStartRecording;
                    } else {
                        onRecord(mStartRecording);
                        mStartRecording = !mStartRecording;
                    }
                }
            });

        mPauseButton = (Button) recordView.findViewById(R.id.btnPause);
        mPauseButton.setVisibility(View.GONE); //hide pause button before recording starts
        mPauseButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onPauseRecord(mPauseRecording);
                    mPauseRecording = !mPauseRecording;
                }
            });

        recordingStatusReceiver = new AudioRecordingReceiver();  
        recordingStatusReceiver.setOnAudioRecordingListener(new AudioRecordingReceiver.OnAudioRecordingListener(){
            @Override
            public void onServiceReady(String message){
                
            }           
        });
        if (ViRecord.isServiceRunning(getActivity(), AudioRecordingService.class)) {

        } else {
            startAudioRecording();
        }
        
        registerBroadcastReceiver();
        return recordView;
    }

    @Override
    public void onResume() {
        super.onResume();
        startAudioRecording();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        getActivity().unregisterReceiver(recordingStatusReceiver);
    }
    
    public void registerBroadcastReceiver() {
        IntentFilter statusIntentFilter = new IntentFilter(AudioRecording.RECORDING_BROADCAST_ACTION);
        getActivity().registerReceiver(recordingStatusReceiver, statusIntentFilter);
    }
    
    public void startAudioRecording() {
        Intent i = new Intent(getActivity(), AudioRecordingService.class);
        i.setAction(AudioRecordingService.ACTION_SERVICE_READY);
        i.putExtra(AudioRecordingService.EXTRA_SERVICE_IS_READY, true);
        getActivity().startService(i);      
    }

    // Recording Start/Stop
    //TODO: recording pause
    private void onRecord(boolean start) {

        Intent intent = new Intent(getActivity(), AudioRecordingService.class);

        if (start) {
            // start recording
            mRecordButton.setImageResource(R.drawable.ic_microphone_off);
            //mPauseButton.setVisibility(View.VISIBLE);
            Toast.makeText(getActivity(), R.string.toast_recording_start, Toast.LENGTH_SHORT).show();
            File folder = new File(Environment.getExternalStorageDirectory() + "/SoundRecorder");
            if (!folder.exists()) {
                //folder /SoundRecorder doesn't exist, create the folder
                folder.mkdir();
            }

            //start Chronometer
            mChronometer.setBase(SystemClock.elapsedRealtime());
            mChronometer.start();
            mChronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
                    @Override
                    public void onChronometerTick(Chronometer chronometer) {
                        if (mRecordPromptCount == 0) {
                            mRecordingPrompt.setText(getString(R.string.record_in_progress) + ".");
                        } else if (mRecordPromptCount == 1) {
                            mRecordingPrompt.setText(getString(R.string.record_in_progress) + "..");
                        } else if (mRecordPromptCount == 2) {
                            mRecordingPrompt.setText(getString(R.string.record_in_progress) + "...");
                            mRecordPromptCount = -1;
                        }

                        mRecordPromptCount++;
                    }
                });

            //start RecordingService
            getActivity().startService(intent);
            //keep screen on while recording
            getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            mRecordingPrompt.setText(getString(R.string.record_in_progress) + ".");
            mRecordPromptCount++;

        } else {
            //stop recording
            mRecordButton.setImageResource(R.drawable.ic_microphone);
            //mPauseButton.setVisibility(View.GONE);
            mChronometer.stop();
            mChronometer.setBase(SystemClock.elapsedRealtime());
            timeWhenPaused = 0;
            mRecordingPrompt.setText(getString(R.string.record_prompt));

            getActivity().stopService(intent);
            //allow the screen to turn off again once recording is finished
            getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    //TODO: implement pause recording
    private void onPauseRecord(boolean pause) {
        if (pause) {
            //pause recording
            mPauseButton.setCompoundDrawablesWithIntrinsicBounds
            (R.drawable.ic_play , 0 , 0 , 0);
            mRecordingPrompt.setText((String)getString(R.string.record_resume_button).toUpperCase());
            timeWhenPaused = mChronometer.getBase() - SystemClock.elapsedRealtime();
            mChronometer.stop();
        } else {
            //resume recording
            mPauseButton.setCompoundDrawablesWithIntrinsicBounds
            (R.drawable.ic_pause , 0 , 0 , 0);
            mRecordingPrompt.setText((String)getString(R.string.record_pause_button).toUpperCase());
            mChronometer.setBase(SystemClock.elapsedRealtime() + timeWhenPaused);
            mChronometer.start();
        }
    }
}
