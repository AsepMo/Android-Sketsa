package com.store.data.engine.app.tasks;

import android.content.Context;
import android.os.AsyncTask;

import java.io.File;
import java.net.URISyntaxException;
import com.store.data.engine.app.compression.VideoCompress;
import com.store.data.engine.app.compression.MediaController;
import com.store.data.engine.app.listeners.SlimProgressListener;

/**
 * A asyncTask to convert video
 **/
public class VideoCompressTask extends AsyncTask<Object, Float, Boolean> {
  
    private Context mContext;
    private VideoCompress.ProgressListener mListener;

    public VideoCompressTask(Context mContext, VideoCompress.ProgressListener mListener) {
        this.mContext = mContext;
        this.mListener = mListener;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();
        if (mListener != null) {
            mListener.onStart();
        }
    }

    @Override
    protected Boolean doInBackground(Object... paths) {
        return new MediaController().convertVideo((String)paths[0], new File((String)paths[1]), new SlimProgressListener() {
                @Override
                public void onProgress(float percent) {
                    publishProgress(percent);
                }
            }, 720, 480, 900000);
    }

    @Override
    protected void onProgressUpdate(Float... percent) {
        super.onProgressUpdate(percent);
        if (mListener != null) {
            mListener.onProgress(percent[0]);
        }
    }

    @Override
    protected void onPostExecute(Boolean result) {
        super.onPostExecute(result);
        if (mListener != null) {
            if (result) {
                mListener.onFinish(true);
            } else {
                mListener.onFinish(false);
            }
        }
    }
}
