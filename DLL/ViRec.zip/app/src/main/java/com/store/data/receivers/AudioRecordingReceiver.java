package com.store.data.receivers;

import android.content.Context;
import android.content.Intent;
import android.content.BroadcastReceiver;

public class AudioRecordingReceiver extends BroadcastReceiver{

    public static String TAG = AudioRecordingReceiver.class.getSimpleName();

    private OnAudioRecordingListener listener;
    public interface OnAudioRecordingListener
    {
        void onServiceReady(String message);
    }
    
    public void setOnAudioRecordingListener(OnAudioRecordingListener listener){
        this.listener = listener;
    }
    
    @Override
    public void onReceive(Context pContext, Intent pIntent) {
        String statusKey = "";
        String statusData = "";
        if (pIntent.hasExtra(AudioRecording.RECORDING_STATUS_KEY)) {
            statusKey = pIntent.getStringExtra(AudioRecording.RECORDING_STATUS_KEY);
        }
        if (pIntent.hasExtra(AudioRecording.RECORDING_STATUS_MESSAGE)) {
            statusData = pIntent.getStringExtra(AudioRecording.RECORDING_STATUS_MESSAGE);
        }
        switch(statusKey){
            case AudioRecording.SERVICE_IS_READY:
                listener.onServiceReady(statusData);
                break;
                
        }
    }

}

