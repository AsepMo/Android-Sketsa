package com.store.data.engine.app.listeners;

public interface SlimProgressListener {

    void onProgress(float percent);
}
