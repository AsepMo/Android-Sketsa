package com.store.data.engine.app.fragments;

import android.support.v4.app.Fragment;
import android.app.Activity;
import android.app.ActivityManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.SystemClock;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.Chronometer;
import android.widget.TextView;
import android.widget.Toast;

import com.store.data.R;
import com.store.data.application.ApplicationActivity;
import com.store.data.application.ApplicationVideoPreview;
import com.store.data.engine.app.recorder.util.ExtractVideoInfoUtil;
import com.store.data.engine.app.recorder.util.FileUtil;
import com.store.data.engine.app.compression.VideoCompress;
import com.store.data.engine.app.utils.Utils;
import com.store.data.engine.app.data.ScreenRecordDb;
import com.store.data.engine.widget.FloatingActionButton;
import com.store.data.services.ScreenCaptureService;
import com.store.data.services.ScreenRecordingService;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.net.URISyntaxException;

/**
 * A simple {@link Fragment} subclass.
 * Activities that contain this fragment must implement the
 * to handle interaction events.
 * Use the {@link RecordFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class ScreenRecordFragment extends Fragment {
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_POSITION = "position";
    private static final String TAG = ScreenRecordFragment.class.getSimpleName();
    private static final String STATE_RESULT_CODE = "result_code";
    private static final String STATE_RESULT_DATA = "result_data";

    private static final boolean DEBUG = false;
    private static final int REQUEST_MEDIA_PROJECTION = 1;
    private int position;
    private int mResultCode;
    private Intent mResultData;

    private MediaProjectionManager mMediaProjectionManager;

    private ScreenRecordDb mDataBase;
    private ProgressDialog mProgressDialog;
    

    //Recording controls
    private FloatingActionButton mRecordButton = null;
    private Button mPauseButton = null;

    private TextView mRecordingPrompt;
    private int mRecordPromptCount = 0;

    private boolean mStartService = true;
    private boolean mStartRecording = true;
    private boolean mPauseRecording = true;

    private Chronometer mChronometer = null;
    long timeWhenPaused = 0; //stores time when user clicks pause button

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    public static ScreenRecordFragment newInstance(int position) {
        ScreenRecordFragment f = new ScreenRecordFragment();
        Bundle b = new Bundle();
        b.putInt(ARG_POSITION, position);
        f.setArguments(b);

        return f;
    }

    public ScreenRecordFragment() {
    }

    private MyBroadcastReceiver mReceiver;
    private Handler mHandlerScreenRecorder = new Handler();
    private Runnable mRunnerScreenRecorder = new Runnable()
    {
        @Override
        public void run() {
            //Request Screen recording permission
            startActivityForResult(mMediaProjectionManager.createScreenCaptureIntent(), REQUEST_MEDIA_PROJECTION);   
        }
    };


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (savedInstanceState != null) {
            mResultCode = savedInstanceState.getInt(STATE_RESULT_CODE);
            mResultData = savedInstanceState.getParcelable(STATE_RESULT_DATA);
        }
        position = getArguments().getInt(ARG_POSITION);
        mDataBase = new ScreenRecordDb(getActivity());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View recordView = inflater.inflate(R.layout.fragment_screen_record, container, false);

        mChronometer = (Chronometer) recordView.findViewById(R.id.chronometer);
        //update recording prompt text
        mRecordingPrompt = (TextView) recordView.findViewById(R.id.recording_status_text);

        mRecordButton = (FloatingActionButton) recordView.findViewById(R.id.btnRecord);
        mRecordButton.setColorNormal(getResources().getColor(R.color.colorPrimary));
        mRecordButton.setColorPressed(getResources().getColor(R.color.colorPrimaryDark));
        mRecordButton.setEnabled(false);

        mPauseButton = (Button) recordView.findViewById(R.id.btnPause);
        mPauseButton.setVisibility(View.GONE); //hide pause button before recording starts
        mPauseButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {        
                    onPauseRecord(mPauseRecording);
                    mPauseRecording = !mPauseRecording;            
                }
            });

        if (mReceiver == null) {
            mReceiver = new MyBroadcastReceiver();
		}

        if (isServiceRunning(ScreenRecordingService.class)) {
            Log.d(TAG, "service is running"); 

        } else {
            mHandlerScreenRecorder.postDelayed(mRunnerScreenRecorder, 3000);
        }
        mProgressDialog = new ProgressDialog(getActivity());
        return recordView;
    }

    private boolean isServiceRunning(Class<?> serviceClass) {
        Activity activity = getActivity();
        ActivityManager manager = (ActivityManager) activity.getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                return true;
            }
        }
        return false;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Activity activity = getActivity();

        mMediaProjectionManager = (MediaProjectionManager)activity.getSystemService(Context.MEDIA_PROJECTION_SERVICE);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        if (mResultData != null) {
            outState.putInt(STATE_RESULT_CODE, mResultCode);
            outState.putParcelable(STATE_RESULT_DATA, mResultData);
        }
    }


    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        if (requestCode == REQUEST_MEDIA_PROJECTION) {
            if (resultCode != Activity.RESULT_OK) {
                Log.i(TAG, "User cancelled");
                Toast.makeText(getActivity(), R.string.record_user_cancelled, Toast.LENGTH_SHORT).show();
                return;
            }
            Activity activity = getActivity();
            if (activity == null) {
                return;
            }
            Log.i(TAG, "Starting screen capture");
            mResultCode = resultCode;
            mResultData = data;
            Intent i = new Intent(getActivity(), ScreenRecordingService.class);
            i.putExtra(ScreenRecordingService.EXTRA_RESULT_CODE, mResultCode);
            i.putExtra(ScreenRecordingService.EXTRA_RESULT_INTENT, mResultData);
            getActivity().startService(i);      
        }
    }


    @Override
    public void onResume() {
        super.onResume();
        if (DEBUG) Log.v(TAG, "onResume:");
        if (isServiceRunning(ScreenRecordingService.class)) {
            Log.d(TAG, "service is running"); 
            startScreenRecord();
        } else {
            startScreenService();
        }
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(ScreenRecordingService.ACTION_QUERY_STATUS_RESULT);
        getActivity().registerReceiver(mReceiver, intentFilter);
    }

    @Override
    public void onPause() {
        super.onPause();
        if (DEBUG) Log.v(TAG, "onPause:");
        getActivity().	unregisterReceiver(mReceiver);
        mHandlerScreenRecorder.removeCallbacks(mRunnerScreenRecorder);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mHandlerScreenRecorder.removeCallbacks(mRunnerScreenRecorder);
    }

    private void startScreenRecord() {
        mRecordButton.setImageResource(R.drawable.ic_play);  
        mRecordButton.setEnabled(true);
        mRecordButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    onStartRecord(mStartService);
                    mStartService = !mStartService;                                      
                }
            });
        File folder = new File(Environment.getExternalStorageDirectory() + "/ScreenRecord");
        if (!folder.exists()) {
            //folder /SoundRecorder doesn't exist, create the folder
            folder.mkdir();
        }     
    }

    private void startScreenService() {
        mRecordButton.setImageResource(R.drawable.ic_screen_record);    
        mRecordButton.setEnabled(true);
        mRecordButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mHandlerScreenRecorder.postDelayed(mRunnerScreenRecorder, 3000);                           
                }
            });
    }

    // Recording Start/Stop
    //TODO: recording pause
    private void onRecord(boolean start) {     
        if (start) {
            // start recording
            mRecordButton.setImageResource(R.drawable.ic_pause);
            mRecordButton.setEnabled(true);
            Toast.makeText(getActivity(), R.string.toast_recording_start, Toast.LENGTH_SHORT).show();

            //start Chronometer
            mChronometer.setBase(SystemClock.elapsedRealtime());
            mChronometer.start();
            mChronometer.setOnChronometerTickListener(new Chronometer.OnChronometerTickListener() {
                    @Override
                    public void onChronometerTick(Chronometer chronometer) {
                        if (mRecordPromptCount == 0) {
                            mRecordingPrompt.setText(getString(R.string.record_in_progress) + ".");
                        } else if (mRecordPromptCount == 1) {
                            mRecordingPrompt.setText(getString(R.string.record_in_progress) + "..");
                        } else if (mRecordPromptCount == 2) {
                            mRecordingPrompt.setText(getString(R.string.record_in_progress) + "...");
                            mRecordPromptCount = -1;
                        }

                        mRecordPromptCount++;
                    }
                });

            //keep screen on while recording
            getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            mRecordingPrompt.setText(getString(R.string.record_in_progress) + ".");
            mRecordPromptCount++;
            
        } else {
            //stop recording
            mRecordButton.setImageResource(R.drawable.ic_play);
            mRecordButton.setEnabled(true);
            mChronometer.stop();
            mChronometer.setBase(SystemClock.elapsedRealtime());
            timeWhenPaused = 0;
            mRecordingPrompt.setText(getString(R.string.record_prompt));
            
            //allow the screen to turn off again once recording is finished
            getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    //TODO: implement pause recording
    private void onPauseRecord(boolean pause) {
        if (pause) {
            //pause recording
            mPauseButton.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_play , 0 , 0 , 0);
            mRecordingPrompt.setText((String)getString(R.string.record_resume_button).toUpperCase());
            timeWhenPaused = mChronometer.getBase() - SystemClock.elapsedRealtime();
            mChronometer.stop();
        } else {
            //resume recording
            mPauseButton.setCompoundDrawablesWithIntrinsicBounds
            (R.drawable.ic_pause , 0 , 0 , 0);
            mRecordingPrompt.setText((String)getString(R.string.record_pause_button).toUpperCase());
            mChronometer.setBase(SystemClock.elapsedRealtime() + timeWhenPaused);
            mChronometer.start();
        }
    }

    private void onStartRecord(boolean isStarted) {
        if (isStarted) {
            //start Recording.. 
            final Intent intent = new Intent(getActivity(), ScreenRecordingService.class);
            intent.setAction(ScreenRecordingService.ACTION_RECORD);
            getActivity().startService(intent);    
        } else {
            final Intent intent = new Intent(getActivity(), ScreenRecordingService.class);
            intent.setAction(ScreenRecordingService.ACTION_STOP);
            getActivity().startService(intent);
        }
    }

    private class MyBroadcastReceiver extends BroadcastReceiver {

        @Override
        public void onReceive(final Context context, final Intent intent) {
            if (DEBUG) Log.v(TAG, "onReceive:" + intent);
            final String action = intent.getAction();
            if (ScreenRecordingService.ACTION_QUERY_STATUS_RESULT.equals(action)) {
                final boolean isReady = intent.getBooleanExtra(ScreenRecordingService.EXTRA_QUERY_RESULT_READY, false);      
                final boolean isRecording = intent.getBooleanExtra(ScreenRecordingService.EXTRA_QUERY_RESULT_RECORDING, false);
                final boolean isPausing = intent.getBooleanExtra(ScreenRecordingService.EXTRA_QUERY_RESULT_PAUSING, false);
                final boolean isShutDown = intent.getBooleanExtra(ScreenRecordingService.EXTRA_QUERY_RESULT_SHUTDOWN, false);

                if (isReady) {
                    startScreenRecord();
                    Toast.makeText(context, "RECORDING SERVICE IS READY", Toast.LENGTH_SHORT).show();
                } else if (isRecording) {
                    onRecord(mStartRecording);
                    mStartRecording = !mStartRecording;
                    
                    Toast.makeText(getActivity(), "Recording Started..", Toast.LENGTH_SHORT).show();
                } else if (isPausing) {
                    onRecord(mStartRecording);
                    mStartRecording = !mStartRecording;
                    final String videoName = intent.getStringExtra(ScreenRecordingService.EXTRA_VIDEO_NAME);                
                    final String videoPath = intent.getStringExtra(ScreenRecordingService.EXTRA_VIDEO_PATH);                             
                    final long videoDuration= intent.getLongExtra(ScreenRecordingService.EXTRA_VIDEO_DURATION, 0);                
                    File file = new File(videoPath);
                    
                    try {
                        String inputPath = Utils.getFilePath(getActivity(), Uri.fromFile(file));
                        VideoCompress.compressVideo(getActivity(), inputPath, VideoCompress.getOutPut(), new VideoCompress.ProgressListener(){
                                @Override
                                public void onStart() {
                                    mProgressDialog.setMessage("Please wait..");
                                    mProgressDialog.show();
                                }
                                @Override
                                public void onFinish(boolean result) {

                                    if (result) {

                                        ExtractVideoInfoUtil extractVideoInfoUtil = new ExtractVideoInfoUtil(VideoCompress.getVideoFile());
                                        Bitmap bitmap = extractVideoInfoUtil.extractFrame();
                                        String firstFrameFilePath = FileUtil.saveBitmap(VideoCompress.getOutPut(), bitmap);
                                        if (bitmap != null && !bitmap.isRecycled()) {
                                            bitmap.recycle();
                                            bitmap = null;
                                        }
                                        Log.d(TAG, "FirstFrame FilePath: " + firstFrameFilePath);

                                        mProgressDialog.dismiss();

                                        try {
                                            mDataBase.addRecording(videoName, videoPath, videoDuration);                                    
                                        } catch (Exception e) {
                                            Log.e(TAG, "exception", e);
                                        }
                                        ApplicationVideoPreview.startActivity(getActivity(), VideoCompress.getVideoFile(), firstFrameFilePath);                                        
                                    } else {

                                        Utils.writeFile(getActivity(), "Failed Compress!!!" + new SimpleDateFormat("HH:mm:ss").format(new Date()));
                                    }
                                }

                                @Override
                                public void onProgress(float percent) {
                                    mProgressDialog.setMessage(String.valueOf(percent) + "%");
                                }

                            });

                    } catch (URISyntaxException e) {
                        e.printStackTrace();
                        Toast.makeText(getActivity(), e.getMessage(), Toast.LENGTH_SHORT).show();                               
                    }

                    Toast.makeText(context, videoPath, Toast.LENGTH_SHORT).show();
                } else if (isShutDown) {
                    startScreenService();
                    Toast.makeText(context, "RECORDING IS SHUTDOWN", Toast.LENGTH_SHORT).show();
                }    
            }
        }
    }

}
