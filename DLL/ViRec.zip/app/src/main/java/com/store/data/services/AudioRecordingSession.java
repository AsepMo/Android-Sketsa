package com.store.data.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.support.v4.app.NotificationCompat;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.Context;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.AudioManager;
import android.media.MediaRecorder;
import android.media.MediaScannerConnection;
import android.media.ToneGenerator;
import android.media.projection.MediaProjection;
import android.net.Uri;
import android.os.Environment;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import com.store.data.R;
import com.store.data.engine.app.data.AudioRecordDb;
import com.store.data.engine.app.settings.MySharedPreferences;
import com.store.data.application.ApplicationActivity;

public class AudioRecordingSession implements MediaScannerConnection.OnScanCompletedListener {
    private static final String LOG_TAG = AudioRecordingSession.class.getSimpleName();

    public static final int VIRT_DISPLAY_FLAGS = DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY |  DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC;
    private String mFileName = null;
    private String mFilePath = null;

    private MediaRecorder mRecorder = null;

    private AudioRecordDb mDataBase;

    private long mStartingTimeMillis = 0;
    private long mElapsedMillis = 0;
    private int mElapsedSeconds = 0;
    private OnTimerChangedListener onTimerChangedListener = null;
    private static final SimpleDateFormat mTimerFormat = new SimpleDateFormat("mm:ss", Locale.getDefault());

    private Timer mTimer = null;
    private TimerTask mIncrementTimerTask = null;
    
    private final Context ctxt;
    private final ToneGenerator beeper;
    public interface OnTimerChangedListener {
        void onTimerChanged(int seconds);
    }
    
    public void setFileNameAndPath(Context c) {
        int count = 0;
        File f;

        do{
            count++;

            mFileName = c.getString(R.string.record_default_file_name)
                + "_" + (mDataBase.getCount() + count) + ".mp3";
            mFilePath = Environment.getExternalStorageDirectory().getAbsolutePath();
            mFilePath += "/SoundRecord/" + mFileName;

            f = new File(mFilePath);
        }while (f.exists() && !f.isDirectory());
    }
    
    public AudioRecordingSession(Context ctxt, AudioRecordDb mDataBase) {
        this.ctxt = ctxt.getApplicationContext();
        this.mDataBase = mDataBase;
        this.beeper = new ToneGenerator(AudioManager.STREAM_NOTIFICATION, 100);

    }

    public void start() {
        setFileNameAndPath(ctxt);
        try{
            mRecorder = new MediaRecorder();
            mRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
            mRecorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
            mRecorder.setOutputFile(mFilePath);
            mRecorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC);
            mRecorder.setAudioChannels(1);
            if (MySharedPreferences.getPrefHighQuality(ctxt)) {
                mRecorder.setAudioSamplingRate(44100);
                mRecorder.setAudioEncodingBitRate(192000);
            }

            try {
                mRecorder.prepare();
                mRecorder.start();
                mStartingTimeMillis = System.currentTimeMillis();

                startTimer();
                //startForeground(1, createNotification());

            } catch (IOException e) {
                Log.e(LOG_TAG, "prepare() failed");
            }
        } catch(Exception e){

        }
    }
    
    public void stop() {
        mRecorder.stop();
        mElapsedMillis = (System.currentTimeMillis() - mStartingTimeMillis);
        mRecorder.release();
        Toast.makeText(ctxt, ctxt.getString(R.string.toast_recording_finish) + " " + mFilePath, Toast.LENGTH_LONG).show();

        //remove notification
        if (mIncrementTimerTask != null) {
            mIncrementTimerTask.cancel();
            mIncrementTimerTask = null;
        }

        mRecorder = null;

        try {
            mDataBase.addRecording(mFileName, mFilePath, mElapsedMillis);

        } catch (Exception e){
            Log.e(LOG_TAG, "exception", e);
        }
    }
    
    private void startTimer() {
        mTimer = new Timer();
        mIncrementTimerTask = new TimerTask() {
            @Override
            public void run() {
                mElapsedSeconds++;
                if (onTimerChangedListener != null)
                    onTimerChangedListener.onTimerChanged(mElapsedSeconds);
                NotificationManager mgr = (NotificationManager) ctxt.getSystemService(Context.NOTIFICATION_SERVICE);
                mgr.notify(1, createNotification());
            }
        };
        mTimer.scheduleAtFixedRate(mIncrementTimerTask, 1000, 1000);
    }
    

    //TODO:
    public Notification createNotification() {
        NotificationCompat.Builder mBuilder =
            new NotificationCompat.Builder(ctxt)
            .setSmallIcon(R.drawable.ic_microphone)
            .setContentTitle(ctxt.getString(R.string.notification_recording))
            .setContentText(mTimerFormat.format(mElapsedSeconds * 1000))
            .setOngoing(true);

        mBuilder.setContentIntent(PendingIntent.getActivities(ctxt, 0,
                                                              new Intent[]{new Intent(ctxt, ApplicationActivity.class)}, 0));

        return mBuilder.build();
    }
    
    @Override
    public void onScanCompleted(String path, Uri uri) {
        beeper.startTone(ToneGenerator.TONE_PROP_NACK);
    }
}
