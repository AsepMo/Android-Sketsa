package com.store.data.services;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.support.v4.app.NotificationCompat;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.text.TextUtils;

import com.store.data.R;
import com.store.data.application.ApplicationActivity;
import com.store.data.engine.app.data.ScreenRecordDb;
import com.store.data.engine.app.settings.MySharedPreferences;
import android.annotation.TargetApi;

public class ScreenRecordingService extends Service {

    private static final boolean DEBUG = false;
	public static String TAG = ScreenRecordingService.class.getSimpleName();

    private static final String CHANNEL_WHATEVER = "channel_whatever";
    private static final int NOTIFY_ID = 9906;
    
    private static final String BASE = "com.store.data.services.ScreenRecordingService.";
    public static final String ACTION_RECORD = BASE + "ACTION_RECORD";
    public static final String ACTION_STOP = BASE + "ACTION_STOP";
    public static final String ACTION_SHUTDOWN = BASE + "ACTION_SHUTDOWN";
    public static final String ACTION_QUERY_STATUS = BASE + "ACTION_QUERY_STATUS";
    public static final String ACTION_QUERY_STATUS_RESULT = BASE + "ACTION_QUERY_STATUS_RESULT";
    public static final String EXTRA_QUERY_RESULT_READY = BASE + "EXTRA_QUERY_RESULT_READY";
    public static final String EXTRA_QUERY_RESULT_RECORDING = BASE + "EXTRA_QUERY_RESULT_RECORDING";
    public static final String EXTRA_QUERY_RESULT_PAUSING = BASE + "EXTRA_QUERY_RESULT_PAUSING";
    public static final String EXTRA_QUERY_RESULT_SHUTDOWN = BASE + "EXTRA_QUERY_RESULT_SHUTDOWN";
    
    public static final String EXTRA_RESULT_CODE = "resultCode";
    public static final String EXTRA_RESULT_INTENT = "resultIntent";
    public static final String EXTRA_VIDEO_NAME = "EXTRA_VIDEO_NAME";
    public static final String EXTRA_VIDEO_PATH = "EXTRA_VIDEO_PATH";
    public static final String EXTRA_VIDEO_DURATION = "EXTRA_VIDEO_DURATION";
    
    private boolean isForeground=false;
    private int resultCode;
    private Intent resultData;
    private boolean recordOnNextStart = false;
    private ScreenRecordingSession session = null;
    private ScreenRecordDb mDataBase;
    @Override
    public void onCreate() {
        super.onCreate();
        mDataBase = new ScreenRecordDb(getApplicationContext());
    }
    
    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        if (i.getAction() == null) {
            resultCode = i.getIntExtra(EXTRA_RESULT_CODE, 1337);
            resultData = i.getParcelableExtra(EXTRA_RESULT_INTENT);

            if (recordOnNextStart) {
                startRecorder();
            }
            
            foregroundify(!recordOnNextStart);
            recordOnNextStart = false;
            final Intent result = new Intent();
            result.setAction(ACTION_QUERY_STATUS_RESULT);    
            result.putExtra(EXTRA_QUERY_RESULT_READY, true);
            sendBroadcast(result);
        } else if (ACTION_RECORD.equals(i.getAction())) {
            if (resultData != null) {
                foregroundify(false);
                startRecorder();          
            } else {
                Intent ui =  new Intent(this, ApplicationActivity.class);
                ui.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(ui);
                recordOnNextStart = true;
            }
        } else if (ACTION_STOP.equals(i.getAction())) {
            foregroundify(true);
            stopRecorder();       
        } else if (ACTION_SHUTDOWN.equals(i.getAction())) {
            stopSelf();
            final Intent result = new Intent();
            result.setAction(ACTION_QUERY_STATUS_RESULT);
            result.putExtra(EXTRA_QUERY_RESULT_SHUTDOWN, true);
            sendBroadcast(result);
        }

        return(START_NOT_STICKY);
    }

    @Override
    public void onDestroy() {
        stopRecorder();
        stopForeground(true);

        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        throw new IllegalStateException("go away");
    }

    private void foregroundify(boolean showRecord) {
        NotificationManager mgr=
            (NotificationManager)getSystemService(NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O &&
            mgr.getNotificationChannel(CHANNEL_WHATEVER) == null) {
            mgr.createNotificationChannel(new NotificationChannel(CHANNEL_WHATEVER,
                                                                  "Whatever", NotificationManager.IMPORTANCE_DEFAULT));
        }

        NotificationCompat.Builder b = new NotificationCompat.Builder(this, CHANNEL_WHATEVER);

        b.setAutoCancel(true);
            //.setDefaults(Notification.DEFAULT_ALL);

        b.setContentTitle(getString(R.string.app_name))
            .setSmallIcon(R.mipmap.ic_launcher)
            .setTicker(getString(R.string.app_name));

        if (showRecord) {
            b.addAction(R.drawable.ic_video_record,
                        getString(R.string.notify_record), buildPendingIntent(ACTION_RECORD));
        } else {
            b.addAction(R.drawable.ic_pause,
                        getString(R.string.notify_stop), buildPendingIntent(ACTION_STOP));
        }

        b.addAction(R.drawable.ic_play,
                    getString(R.string.notify_shutdown), buildPendingIntent(ACTION_SHUTDOWN));

        if (isForeground) {
            mgr.notify(NOTIFY_ID, b.build());
        } else {
            startForeground(NOTIFY_ID, b.build());
            isForeground = true;
        }
    }

    private PendingIntent buildPendingIntent(String action) {
        Intent i = new Intent(this, getClass());
        i.setAction(action);
        return(PendingIntent.getService(this, 0, i, 0));
    }

    public synchronized void startRecorder() {
        if (session == null) {
            MediaProjectionManager mgr = (MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            MediaProjection projection =  mgr.getMediaProjection(resultCode, resultData);

            session = new ScreenRecordingSession(this, new ScreenRecordingConfig(this),projection, mDataBase);
            session.start();
            final Intent result = new Intent();
            result.setAction(ACTION_QUERY_STATUS_RESULT);
            result.putExtra(EXTRA_QUERY_RESULT_RECORDING, true);
            sendBroadcast(result);
        }
    }

    public synchronized void stopRecorder() {
        if (session != null) {
            session.stop();
            session = null; 
        }
    }
}

