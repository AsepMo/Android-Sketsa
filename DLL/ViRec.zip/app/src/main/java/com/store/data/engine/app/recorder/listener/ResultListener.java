package com.store.data.engine.app.recorder.listener;

public interface ResultListener {
    void callback();
}
