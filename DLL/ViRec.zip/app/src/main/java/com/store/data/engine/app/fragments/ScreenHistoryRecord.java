package com.store.data.engine.app.fragments;

import android.support.v4.app.Fragment;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.FileObserver;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;


import com.store.data.R;
import com.store.data.engine.app.adapters.ScreenRecordAdapter;

public class ScreenHistoryRecord extends Fragment {
    private static final String ARG_POSITION = "position";
    private static final String TAG = ScreenHistoryRecord.class.getSimpleName();

    private int position;
    public static ScreenHistoryRecord newInstance(int position) {
        ScreenHistoryRecord f = new ScreenHistoryRecord();
        Bundle b = new Bundle();
        b.putInt(ARG_POSITION, position);
        f.setArguments(b);
        return f;
    }


    private ScreenRecordAdapter adapter;
    private RecyclerView historyList;
    boolean sortOrderAscending = true;

    public ScreenHistoryRecord() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        position = getArguments().getInt(ARG_POSITION);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_history_record, container, false);
    }


    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        TextView mTitle = (TextView) view.findViewById(R.id.textViewLay1);
        Typeface typeFaces = Typeface.createFromAsset(getActivity().getAssets(), "fonts/capture.ttf");
        mTitle.setTypeface(typeFaces);
        mTitle.setText("Records \n\n");

        ImageButton filterButton = (ImageButton) view.findViewById(R.id.ibFilter);
        historyList = (RecyclerView) view.findViewById(R.id.recyclerView);

        RecyclerView mRecyclerView = (RecyclerView) view.findViewById(R.id.recyclerView);
        mRecyclerView.setHasFixedSize(true);
        LinearLayoutManager llm = new LinearLayoutManager(getActivity());
        llm.setOrientation(LinearLayoutManager.VERTICAL);

        //newest to oldest order (database stores from oldest to newest)
        llm.setReverseLayout(true);
        llm.setStackFromEnd(true);

        mRecyclerView.setLayoutManager(llm);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        adapter = new ScreenRecordAdapter(getActivity(), llm);
        mRecyclerView.setAdapter(adapter);

        filterButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    sortOrderAscending = !sortOrderAscending;
                    adapter.notifyDataSetChanged();
                }
            });

    }

    /* FileObserver observer = new FileObserver(android.os.Environment.getExternalStorageDirectory().toString() + "/SoundRecorder") {
     // set up a file observer to watch this directory on sd card
     @Override
     public void onEvent(int event, String file) {
     if(event == FileObserver.DELETE){
     // user deletes a recording file out of the app

     String filePath = android.os.Environment.getExternalStorageDirectory().toString()
     + "/SoundRecorder" + file + "]";

     Log.d(LOG_TAG, "File deleted ["
     + android.os.Environment.getExternalStorageDirectory().toString()
     + "/SoundRecorder" + file + "]");

     // remove file from database and recyclerview
     mAudioRecordAdapter.removeOutOfApp(filePath);
     }
     }
     };*/
}
