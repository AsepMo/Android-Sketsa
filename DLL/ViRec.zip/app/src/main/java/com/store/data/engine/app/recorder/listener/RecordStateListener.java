package com.store.data.engine.app.recorder.listener;

public interface RecordStateListener {

    void recordStart();

    void recordEnd(long time);

    void recordCancel();
}
