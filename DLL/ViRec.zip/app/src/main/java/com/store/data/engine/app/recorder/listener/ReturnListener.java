package com.store.data.engine.app.recorder.listener;

public interface ReturnListener {
    void onReturn();
}
