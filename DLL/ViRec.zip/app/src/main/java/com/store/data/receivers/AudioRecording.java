package com.store.data.receivers;

import android.app.ActivityManager;
import android.content.Context;

import java.io.File;
import java.util.List;

public class AudioRecording {
    
    public static final String BASE = "com.store.data.services.AudioRecordingService.";
    public static final String RECORDING_BROADCAST_ACTION = BASE + ".BROADCAST";
    public static final String RECORDING_STATUS_KEY = BASE +".STATUS_KEY";
    public static final String RECORDING_STATUS_MESSAGE = BASE + ".STATUS_MESSAGE";
    public static final String RECORDING_FILE_PATH = BASE + ".FILE_PATH";
    public static final String RECORDING_FILE_NAME = BASE +".FILE_NAME";
    public static final int RECORDING_NOTIFICATION_ID = 1;

    public static final String SERVICE_IS_READY = "SERVICE_IS_READY";
    
    public interface ACTION {
        String LAUNCH_RECORDING_SERVICE = BASE + ".action.LAUNCH_RECORDING_SERVICE";     
        String START_RECORDING = BASE + ".action.START_RECORDING";
        String STOP_RECORDING = BASE + ".action.STOP_RECORDING";
        String SHUTDOWN_SERVICE = BASE + ".action.SHUTDOWN_SERVICE";
    }

    public static void killAllProcessorServices(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = am.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo next : runningAppProcesses) {
            String processName = context.getPackageName() + ":service";
            if (next.processName.equals(processName)) {
                android.os.Process.killProcess(next.pid);
                break;
            }
        }
    }

    public static boolean isProcessorServiceRunning(Context context) {
        ActivityManager am = (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
        List<ActivityManager.RunningAppProcessInfo> runningAppProcesses = am.getRunningAppProcesses();
        for (ActivityManager.RunningAppProcessInfo next : runningAppProcesses) {
            String processName = context.getPackageName() + ":service";
            if (next.processName.equals(processName)) {
                return true;
            }
        }
        return false;
    }

}

