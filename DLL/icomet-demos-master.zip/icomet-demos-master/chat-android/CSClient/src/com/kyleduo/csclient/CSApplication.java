package com.kyleduo.csclient;

import android.app.Application;

public class CSApplication extends Application {
	public String uname = "";
}
