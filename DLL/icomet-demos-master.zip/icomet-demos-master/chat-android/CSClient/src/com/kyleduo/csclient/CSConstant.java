package com.kyleduo.csclient;

public class CSConstant {
	public static String ACTION_MESSAGE_ARRIVED = "com.kyleduo.csclient.action.MESSAGE_ARRIVED";
	
//	public static String BASE_URL = "http://10.0.2.2/chat";
	public static String BASE_URL = "http://www.ideawu.com/icomet/chat";
}
