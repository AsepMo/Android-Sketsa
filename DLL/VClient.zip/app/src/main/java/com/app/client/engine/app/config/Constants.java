package com.app.client.engine.app.config;

public class Constants {
    //the SERVER_PORT is initialized which must correspond to the port of the client
    public static final int SERVER_PORT = 5050;
    public static final String SERVER_IP = "192.168.43.1";
    
}
