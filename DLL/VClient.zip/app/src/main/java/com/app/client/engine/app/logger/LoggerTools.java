package com.app.client.engine.app.logger;

import android.app.Activity;
import android.app.FragmentManager;

import java.util.ArrayList;
import java.util.List;

import com.app.client.R;

public class LoggerTools {

    public final static boolean devToolsEnabled = true;

    /**
     * Builder class for {@link DevToolFragment}
     */
    public static class Builder {

        private List<LoggerFunction> mFunctions = new ArrayList<>();

        private LoggerFragment fragment;
        private Activity activity;

        private LoggerFragment.DevToolTheme mTheme = LoggerFragment.DevToolTheme.DARK;
        private Integer mTextSize = null;
        private float startX = 0;
        private float starty = 0;

        /**
         * Constructor
         *
         * @param activity the activity the DevTool will be linked to.
         */
        public Builder(Activity activity) {
            fragment = new LoggerFragment();
            this.activity = activity;
        }

        /**
         * Add function to the function list. This will generate a button on the tool's panel.
         *
         * @param function will be called on the matching button click, and the return String
         *                 of the function will be logged in the console as soon as the function
         *                 ended.
         * @return this to allow chaining.
         */
        public Builder addFunction(LoggerFunction function) {
            if (function != null) {
                function.setDevToolFragment(fragment);
                this.mFunctions.add(function);
            }
            return this;
        }
        
        public Builder log(String log){
            fragment.log(log);
            return this;
        }
        
        /**
         * Set the theme of the debug tool. The theme will be applied on build() call.
         *
         * @param theme can be {@code DevToolTheme.LIGHT} or {@code DevToolTheme.DARK}.
         *              The default theme is {@code DevToolTheme.DARK}
         * @return this to allow chaining.
         */
        public Builder setTheme(LoggerFragment.DevToolTheme theme) {
            this.mTheme = theme;
            return this;
        }

        /**
         * Set te console text size. By default the text size is 12sp.
         *
         * @param sp the console text size in sp.
         *
         * @return this to allow chaining.
         */
        public Builder setTextSize(int sp){
            this.mTextSize = sp;
            return this;
        }


        /**
         * Set the initial position of the debug tool. The tool is displayed (0,0) by default.
         * @param x
         * @param y
         * @return this to allow chaining.
         */
        public Builder displayAt(float x, float y) {
            this.startX = x;
            this.starty = y;
            return this;
        }

        /**
         * Build the tool and show it.
         *
         * @return this to allow chaining.
         */
        public Builder build() {
            if (devToolsEnabled) {
                if (mFunctions != null && mFunctions.size() > 0)
                    fragment.setFunctionList(mFunctions);

                if (mTextSize != null)
                    fragment.setConsoleTextSize(mTextSize);

                fragment.displayAt(startX, starty);

                try {
                    FragmentManager fragmentManager = activity.getFragmentManager();
                    fragmentManager.beginTransaction()
                            .add(android.R.id.content, fragment)
                            .commit();
                } catch (Exception exception) {
                    exception.printStackTrace();
                }

                fragment.setTheme(mTheme);
            }
            return this;
        }

        /**
         * Get the {@link DevToolFragment} instance created by the builder.
         */
        public LoggerFragment getTool() {
            return fragment;
        }
    }

}
