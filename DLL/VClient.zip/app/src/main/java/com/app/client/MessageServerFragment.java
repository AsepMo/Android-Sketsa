package com.app.client;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Environment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;

import com.app.client.engine.views.MessageWindow;
import com.app.client.engine.app.tasks.ServerThread;

public class MessageServerFragment extends Fragment implements View.OnClickListener{

    public static String TAG = MessageServerFragment.class.getSimpleName();

    private static final String EXTRA_TEXT = "text"; 
    private MessageWindow mMessagesWindow;
    //here it sets the Thread initially to null
    Thread serverThread = null;
    private ServerThread mServerThread;
    public static MessageServerFragment createFor(String text) {
        MessageServerFragment fragment = new MessageServerFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_app_message_server, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {

        final String text = getArguments().getString(EXTRA_TEXT);

        mMessagesWindow = (MessageWindow) view.findViewById(R.id.send_mesage);
        view.findViewById(R.id.start_server).setOnClickListener(this);
  
        //this initiates the serverthread defined later and starts the thread
        mServerThread = new ServerThread(getActivity());
        mServerThread.setOnServerThreadListener(new ServerThread.OnServerThreadListener(){
                @Override
                public void onConnect(String message, int color) {
                    if (null == message || message.trim().isEmpty()) {
                        message = "<Empty Message>";
                    }  
                    mMessagesWindow.serverMessage(message, color);
                }

                @Override
                public void onDisConnect(String message, int color) {                 
                    if (null == message || message.trim().isEmpty()) {
                        message = "<Empty Message>";
                    }  
                    mMessagesWindow.serverMessage(message, color);       
                }

                @Override
                public void onMessage(String message, int color) {               
                    if (null == message || message.trim().isEmpty()) {
                        message = "<Empty Message>";
                    }  
                    mMessagesWindow.clientMessage(message, color);
                } 

                @Override
                public void onError(String message, int color) {
                    if (null == message || message.trim().isEmpty()) {
                        message = "<Empty Message>";
                    }  
                    mMessagesWindow.serverMessage(message, color);    
                }   
            });
        mMessagesWindow.setOnMessageListener(new MessageWindow.OnMessageListener(){
            @Override
            public void onMessage(String message) {
                mServerThread.sendMessage(message);
            }
        });
        Toast.makeText(getActivity(), text, Toast.LENGTH_SHORT).show();
    }

    //onClick method to handle clicking events whether to start up the  server or
    //send a message to the client
    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.start_server:
                //this initiates the serverthread defined later and starts the thread
                mServerThread.execute();
                view.setVisibility(View.GONE);
                break;
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (null != serverThread) {
            mServerThread.sendMessage("Disconnect");       
            serverThread.interrupt();
            serverThread = null;
        }
    }

    

    String getTime() {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        return sdf.format(new Date());
    }

}

