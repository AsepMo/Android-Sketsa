package com.app.client.engine.app.tasks;

import android.support.v4.content.ContextCompat;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Handler;
import android.util.Log;

import java.net.Socket;
import java.net.ServerSocket;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.BufferedWriter;
import java.io.OutputStreamWriter;
import java.io.BufferedReader;
import java.io.InputStreamReader;

import com.app.client.R;
import com.app.client.engine.app.config.Constants;
import com.app.client.engine.app.config.Command;

public class ServerThread extends AsyncTask<Void, Void, Void> {

    public static String TAG = ServerThread.class.getSimpleName();
    
    private ServerSocket serverSocket;
    private Socket socket;
    private BufferedReader input;

    private int greenColor;
    private int redColor;
    private int blueColor;
    private int yellowColor;
    
    private OnServerThreadListener mOnServerThreadListener;
    public void setOnServerThreadListener(OnServerThreadListener mOnServerThreadListener) {
        this.mOnServerThreadListener = mOnServerThreadListener;
    }

    public interface OnServerThreadListener {
        void onConnect(String connect, int color);
        void onDisConnect(String disconnect, int color);
        void onMessage(String message, int color);
        void onError(String msg, int color);
    }

    public ServerThread(Context context) {
        greenColor = ContextCompat.getColor(context, R.color.text_color_green);
        redColor = ContextCompat.getColor(context, R.color.text_color_red);
        blueColor = ContextCompat.getColor(context, R.color.text_color_blue); 
        yellowColor = ContextCompat.getColor(context, R.color.text_color_yellow); 
    }

    protected Void doInBackground(Void... params) {
        Runnable run = new Runnable() {
            public void run() {

                try {
                    serverSocket = new ServerSocket(Constants.SERVER_PORT);

                } catch (IOException e) {
                    e.printStackTrace();
                    if (mOnServerThreadListener != null)
                        mOnServerThreadListener.onError("Error Connecting to Client!!", redColor);                             
                }

                //communicates to client and displays error if communication fails
                if (null != serverSocket) {
                    while (!Thread.currentThread().isInterrupted()) {
                        try {
                            socket = serverSocket.accept();
                            try {
                                input = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                            } catch (IOException e) {
                                e.printStackTrace();
                                if (mOnServerThreadListener != null)
                                    mOnServerThreadListener.onError("Error Connecting to Client!!", redColor);                             
                            } 
                            
                            if (mOnServerThreadListener != null)
                                mOnServerThreadListener.onConnect("Connected to Client!!", greenColor);
                            
                            Runnable runner = new Runnable() {
                                @Override
                                public void run() {

                                    while (!Thread.currentThread().isInterrupted()) {
                                        try {

                                            //checks to see if the client is still connected and displays disconnected if disconnected
                                            String read = input.readLine();
                                            if (null == read || Command.MESSAGE_CLIENT_DISCONNECT.contentEquals(read)) {
                                                Thread.interrupted();
                                                // isRunningTask = false;
                                                read = "Offline...."; 
                                                if (mOnServerThreadListener != null)
                                                    mOnServerThreadListener.onDisConnect(read, yellowColor);                                            
                                                break;
                                            } else if (null == read || "Exit".contentEquals(read)) {

                                            }

                                            if (mOnServerThreadListener != null)
                                                mOnServerThreadListener.onMessage(read, blueColor);

                                        } catch (IOException e) {
                                            e.printStackTrace();
                                        }
                                    }
                                }
                            };


                            new Thread(runner).start();
                        } catch (IOException e) {
                            e.printStackTrace();
                            if (mOnServerThreadListener != null)
                                mOnServerThreadListener.onError("Error Communicating to Client :" + e.getMessage(), redColor);                                                    
                        }
                    }
                }

            }
        };
        new Thread(run).start();  
        Log.e(TAG, "Service was killed");
        return null;
    }

    public void sendMessage(final String message) {
        try {
            if (null != socket) {
                new Thread(new Runnable() {
                        @Override
                        public void run() {
                            PrintWriter out = null;
                            try {
                                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(socket.getOutputStream())), true);                                               
                            } catch (IOException e) {
                                e.printStackTrace();
                            }
                            out.println(message);
                        }
                    }).start();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    } 

}

