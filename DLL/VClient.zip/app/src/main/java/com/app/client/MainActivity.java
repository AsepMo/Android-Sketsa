package com.app.client;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import com.app.client.engine.app.debugkit.DevTool;
import com.app.client.engine.app.debugkit.DebugFunction;
import com.app.client.engine.app.debugkit.DevToolFragment;
import com.app.client.engine.app.logger.LoggerTools;
import com.app.client.engine.app.logger.LoggerFunction;
import com.app.client.engine.app.logger.LoggerFragment;
import android.app.Activity;

public class MainActivity extends AppCompatActivity { 

    private static int mTextSize = 12;
    private DevToolFragment.DevToolTheme mTheme = DevToolFragment.DevToolTheme.DARK;
    private static LoggerFragment.DevToolTheme mLogTheme = LoggerFragment.DevToolTheme.DARK;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        setTheme(R.style.AppTheme_NoActionBar);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar mToolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        switchFragment(MessageServerFragment.createFor("Server"));
    }

    public void switchFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    } 

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Client")
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                   // startActivity(new Intent(MainActivity.this, SimpleSampleActivity.class));
                    switchFragment(MessageClientFragment.createFor("Client"));
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        menu.add("Server")
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    switchFragment(MessageServerFragment.createFor("Server")); 
                  //  startActivity(new Intent(MainActivity.this, MoreCustomizationSampleActivity.class));           
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);  
        return super.onCreateOptionsMenu(menu);
    }
    
    public void onDebugkit() {
        final DevTool.Builder builder = new DevTool.Builder(MainActivity.this);

        builder.addFunction(new DebugFunction("Do some stuff") {
                @Override
                public String call() throws Exception {
                    return "This function has a title";
                }
            })
            .addFunction(new DebugFunction.Clear("Clear"))
            .addFunction(new DebugFunction("Make ShPrf") {
                @Override
                public String call() throws Exception {

                    return "Preferences file has been created.";
                }
            }).addFunction(new DebugFunction("Do some stuff") {
                @Override
                public String call() throws Exception {
                    return "This function has a title";
                }
            });


        builder.setTextSize(mTextSize)
            .displayAt(50, 200)
            .setTheme(mTheme)
            .build();
    }

    public static void onLogger(Activity c, final String logger) {
        final LoggerTools.Builder builder = new LoggerTools.Builder(c);
        
        builder.addFunction(new LoggerFunction.Clear("Clear"));
        builder.setTextSize(mTextSize)
            .log(logger)
            .displayAt(50, 200)
            .setTheme(mLogTheme)
            .build();
    }
}
