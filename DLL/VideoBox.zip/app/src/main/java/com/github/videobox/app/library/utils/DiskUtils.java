package com.github.videobox.app.library.utils;

import android.content.Context;
import android.os.Environment;

import java.io.File;


public class DiskUtils {
	
	public static String getCacheDir(final Context context, final String uniqueName) {
		final String cachePath =
				(Environment.MEDIA_MOUNTED.equals(Environment.getExternalStorageState())
				 && !Environment.isExternalStorageRemovable()	// これが使えるのはAPI9以上
				) ? context.getExternalCacheDir().getPath() : context.getCacheDir().getPath();
		return cachePath + File.separator + uniqueName;
	}
}
