package com.github.videobox.app.library.utils;

import android.support.annotation.RequiresApi;
import android.support.design.widget.Snackbar;
import android.support.v4.app.NotificationCompat;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v7.content.res.AppCompatResources;
import android.support.v7.widget.Toolbar;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Activity;
import android.app.Dialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.Intent.ShortcutIconResource;
import android.content.pm.ActivityInfo;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Rect;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.AnimationDrawable;
import android.media.MediaMetadataRetriever;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;
import android.util.Log;
import android.text.TextWatcher;
import android.text.Editable;
import android.util.DisplayMetrics;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.Animation.AnimationListener;
import android.view.animation.AnimationUtils;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.ImageButton;
import android.widget.EditText;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Timer;
import java.util.TimerTask;
import java.util.Calendar;
import java.util.List;
import java.util.Arrays;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import com.github.videobox.R;
import com.github.videobox.app.dialogs.OptionsMenu;
import com.github.videobox.app.dialogs.interfaces.OnMenuItemClickListener;
import com.github.videobox.app.dialogs.interfaces.OnMenuItemLongClickListener;
import com.github.videobox.app.dialogs.animations.MenuParams;
import com.github.videobox.app.dialogs.models.MenuObject;
import com.github.videobox.VideoPlayerActivity;
import com.github.videobox.VideoBoxApplication;

public class VideoPlayerUtils {

    private Context mContext;
    private OnItemClickListener mOnItemClickListener;
    private OnItemLongClickListener mOnItemLongClickListener;
    private OptionsMenu mMenuDialogFragment;
    public static String VideoUrl = "https://r3---sn-npoeenl7.googlevideo.com/videoplayback?expire=1624199405&ei=jfzOYMeeC_3ujuMPjZmm0Ac&ip=103.147.170.202&id=o-APVi8pVQO5l2y8dyYkjmIuknSvwTgbawQhEfzrpP4ypD&itag=18&source=youtube&requiressl=yes&vprv=1&mime=video%2Fmp4&ns=4h4xl2IyXtublx53fj06qEgF&gir=yes&clen=20850244&ratebypass=yes&dur=225.326&lmt=1540375200352406&fexp=24001373,24007246&c=WEB&txp=5531432&n=QWA7tyJTs72dX5f5N&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cvprv%2Cmime%2Cns%2Cgir%2Cclen%2Cratebypass%2Cdur%2Clmt&sig=AOq0QJ8wRgIhANnkGkVI82NKeYh1uYAECxZJzvAvDXffwm6fPNtLq09kAiEAkE__7E7Wd_scAZYIJUs7fQOpKSz8Ao32f5Dpz8cmwu8%3D&title=Girls%27%20Generation%20%E5%B0%91%E5%A5%B3%E6%99%82%E4%BB%A3%20%27MR.%20TAXI%27%20MV%20(JPN%20Ver.)&rm=sn-pivhx-n8vs7s,sn-axqs7s&req_id=422a297db627a3ee&redirect_counter=2&cms_redirect=yes&ipbypass=yes&mh=Eb&mip=223.255.230.23&mm=29&mn=sn-npoeenl7&ms=rdu&mt=1624177486&mv=m&mvi=3&pl=24&lsparams=ipbypass,mh,mip,mm,mn,ms,mv,mvi,pl&lsig=AG3C_xAwRQIhAO-I1TxK7MUxqbNmwE50yCAxh2O2xfazLDwZikCnd6cnAiANYEuS7h5WaVdPMdxu_L19367yx_LCnqilX8SPJ64FBA%3D%3D";
    public VideoPlayerUtils(Context context) {
        mContext = context;
    }

    public static void setActivity(Context context, Class<?> mClass)
    {
        Intent intent = new Intent(context, mClass);
        context.startActivity(intent);
    }
    
    public void setMenuFragment(final Activity activity, List<MenuObject> getOptionsMenu) {
        MenuParams menuParams = new MenuParams();
        menuParams.setActionBarSize((int) activity.getResources().getDimension(R.dimen.toolbar_height));
        menuParams.setMenuObjects(getOptionsMenu);
        menuParams.setClosableOutside(false);
        mMenuDialogFragment = OptionsMenu.newInstance(menuParams);
        if (activity.getFragmentManager().findFragmentByTag(OptionsMenu.TAG) == null) {
            mMenuDialogFragment.show(activity.getFragmentManager(), OptionsMenu.TAG);
        }
        mMenuDialogFragment.setItemClickListener(new OnMenuItemClickListener(){
                @Override
                public void onMenuItemClick(View clickedView, int position) {
                    if (mOnItemClickListener != null) {
                        mOnItemClickListener.onItemClick(clickedView, position);
                    }
                }
            });
        mMenuDialogFragment.setItemLongClickListener(new OnMenuItemLongClickListener(){
                @Override
                public void onMenuItemLongClick(View clickedView, int position) {

                    Toast.makeText(activity, "Clicked on position: " + position, Toast.LENGTH_SHORT).show();
                }
            });
    }

    public void onMenuDismiss(Activity activity) {
        mMenuDialogFragment.dismiss();
    }
    
    public void onBackPressed(Activity activity) {
        if (mMenuDialogFragment != null && mMenuDialogFragment.isAdded()) {
            mMenuDialogFragment.dismiss();
        } else {
            activity.finish();
        }
    }
    
    public void setOnItemClickListener(OnItemClickListener mOnItemClickListener) {
        this.mOnItemClickListener = mOnItemClickListener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener mOnItemLongClickListener) {
        this.mOnItemLongClickListener = mOnItemLongClickListener;
    }

    public static List<MenuObject> getOptionsMenu() {

        List<MenuObject> menuObjects = new ArrayList<>();

        MenuObject close = new MenuObject();
        close.setResource(R.drawable.ic_close_circle_outline);

        MenuObject videoInfo = new MenuObject("Info");
        videoInfo.setResource(R.drawable.ic_information_outline);

        MenuObject videoPlayer = new MenuObject("Video");
        videoPlayer.setResource(R.drawable.ic_video_player_black_24);

        MenuObject videoFolder = new MenuObject("Folder");
        videoFolder.setResource(R.drawable.ic_folder_black_24);

        MenuObject recorder = new MenuObject("Recorder");
        recorder.setResource(R.drawable.ic_video);

        MenuObject more = new MenuObject("More");
        more.setResource(R.drawable.ic_menu_more);

        menuObjects.add(close);
        menuObjects.add(videoInfo);
        menuObjects.add(videoPlayer);
        menuObjects.add(videoFolder);
        menuObjects.add(recorder);   
        menuObjects.add(more);    
        return menuObjects;
    }

    public static List<MenuObject> getMoreMenu() {

        List<MenuObject> menuObjects = new ArrayList<>();

        MenuObject close = new MenuObject();
        close.setResource(R.drawable.ic_close_circle_outline);

        MenuObject videoInfo = new MenuObject("Movie");
        videoInfo.setResource(R.drawable.ic_movie);

        MenuObject videoPlayer = new MenuObject("3D");
        videoPlayer.setResource(R.drawable.ic_video_3d);

        MenuObject videoFolder = new MenuObject("Editor");
        videoFolder.setResource(R.drawable.ic_movie_edit);

        MenuObject recorder = new MenuObject("Share");
        recorder.setResource(R.drawable.ic_share);

        MenuObject more = new MenuObject("Manage");
        more.setResource(R.drawable.ic_settings);

        menuObjects.add(close);
        menuObjects.add(videoInfo);
        menuObjects.add(videoPlayer);
        menuObjects.add(videoFolder);
        menuObjects.add(recorder);   
        menuObjects.add(more);    
        return menuObjects;
    }

    public static final String SNACKBAR = "SNACKBAR";

    public static void setOrientation(Activity mActivity, String url) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        retriever.setDataSource(url);
        String width = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH);
        String height = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT);
        String resolusi = width + "x" + height;
        if (resolusi.equals("330x480")) {
            mActivity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);                 
        } else if (resolusi.equals("406x720")) {
            mActivity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);                 
        } else if (resolusi.equals("576x1024")) {
            mActivity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);                 
        } else if (resolusi.equals("1920x1080")) {
            mActivity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);                 
        } else {
            mActivity.setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);                 
        }
    }

    public static int[] getVideoDimensions(String path) throws FileNotFoundException {
        File file = new File(path);
        if (!file.exists()) {
            throw new FileNotFoundException();
        }

        MediaMetadataRetriever retriever = new MediaMetadataRetriever();

        try {
            retriever.setDataSource(path);
            Bitmap bitmap = retriever.getFrameAtTime();

            int[] dimensions = new int[2];

            if (bitmap != null) {
                dimensions[0] = bitmap.getWidth() > 0 ? bitmap.getWidth() : 1;
                dimensions[1] = bitmap.getHeight() > 0 ? bitmap.getHeight() : 1;
            }
            return dimensions;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return new int[]{1, 1};
    }

    @SuppressWarnings("inlineValue")
    public static TextView setToolbarTypeface(Toolbar toolbar) {
        for (int i = 0; i < toolbar.getChildCount(); i++) {
            View view = toolbar.getChildAt(i);
            if (view instanceof TextView) {
                TextView textView = (TextView) view;
                if (textView.getText().equals(toolbar.getTitle())) {
                    final Typeface typeface = Typeface.createFromAsset(VideoBoxApplication.getContext().getAssets(), "roboto_mono_medium.ttf");  
                    textView.setTypeface(typeface);
                    return textView;
                }
            }
        }
        return null;
    }

    public static void setDarkStatusBarIcons(final View v) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            v.post(new Runnable() {
                    @Override
                    @RequiresApi(api = Build.VERSION_CODES.M)
                    public void run() {
                        v.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
                    }
                });
        }
    }

    public static void setLightStatusBarIcons(final View v) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            v.post(new Runnable() {
                    @Override
                    public void run() {
                        v.setSystemUiVisibility(0);
                    }
                });
        }
    }

    @SuppressWarnings("unused")
    public static boolean areStatusBarIconsDark(final View v) {
        return Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && v.getSystemUiVisibility() != 0;
    }

    public static void showSnackbar(Snackbar snackbar) {
        snackbar.getView().setTag(SNACKBAR);
        TextView textView = snackbar.getView()
            .findViewById(android.support.design.R.id.snackbar_text);
        final Typeface typeface = Typeface.createFromAsset(VideoBoxApplication.getContext().getAssets(), "roboto_mono_medium.ttf");  

        textView.setTypeface(typeface);
        snackbar.show();
    }

    public static Snackbar getPermissionDeniedSnackbar(final View rootView) {
        Snackbar snackbar = Snackbar.make(rootView,
                                          R.string.read_permission_denied,
                                          Snackbar.LENGTH_INDEFINITE);
        snackbar.getView().setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View view) {
                    Toast.makeText(rootView.getContext(), R.string.read_permission_denied, Toast.LENGTH_SHORT).show();
                    return false;
                }
            });
        return snackbar;
    }

    public static void colorToolbarOverflowMenuIcon(Toolbar toolbar, int color) {
        //set Toolbar overflow icon color
        Drawable drawable = toolbar.getOverflowIcon();
        if (drawable != null) {
            drawable = DrawableCompat.wrap(drawable);
            DrawableCompat.setTint(drawable.mutate(), color);
            toolbar.setOverflowIcon(drawable);
        }
    }

    //int[left, top, right, bottom]
    public static int[] getScreenSize(Activity context) {
        Rect displayRect = new Rect();
        context.getWindow().getDecorView().getWindowVisibleDisplayFrame(displayRect);
        return new int[]{
            displayRect.left, displayRect.top,
            displayRect.right, displayRect.bottom};
    }

    public static float getAnimatorSpeed(Context context) {
        PowerManager powerManager = (PowerManager)
            context.getSystemService(Context.POWER_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP
            && powerManager.isPowerSaveMode()) {
            // Animations are disabled in power save mode, so just show a toast instead.
            return 0.0f;
        }
        return android.provider.Settings.Global.getFloat(context.getContentResolver(),
                                                         android.provider.Settings.Global.ANIMATOR_DURATION_SCALE, 1.0f);
    }

    public static Locale getLocale(Context context) {
        Locale locale;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {
            locale = context.getResources().getConfiguration().getLocales().get(0);
        } else {
            locale = context.getResources().getConfiguration().locale;
        }
        return locale;
    }

    public static int dpToPx(Context context, int dp) {
        DisplayMetrics displayMetrics = context.getResources().getDisplayMetrics();
        return Math.round(dp * (displayMetrics.xdpi / DisplayMetrics.DENSITY_DEFAULT));
    }
    //time conversion
    public static String timeConversion(long value) {
        String songTime;
        int dur = (int) value;
        int hrs = (dur / 3600000);
        int mns = (dur / 60000) % 60000;
        int scs = dur % 60000 / 1000;

        if (hrs > 0) {
            songTime = String.format("%02d:%02d:%02d", hrs, mns, scs);
        } else {
            songTime = String.format("%02d:%02d", mns, scs);
        }
        return songTime;
    }

    public static String getShowTime(long milliseconds) {
        /*
         // 获取日历函数
         Calendar calendar = Calendar.getInstance();
         calendar.setTimeInMillis(milliseconds);
         SimpleDateFormat dateFormat = null;
         // 判断是否大于60分钟，如果大于就显示小时。设置日期格式
         if (milliseconds / 60000 > 60) {
         dateFormat = new SimpleDateFormat("hh:mm:ss");
         } else {
         dateFormat = new SimpleDateFormat("00:mm:ss");
         }
         return dateFormat.format(calendar.getTime());
         */
        //abhiank209 (pr #10)
        return String.format("%02d:%02d:%02d",
                             TimeUnit.MILLISECONDS.toHours(milliseconds),
                             TimeUnit.MILLISECONDS.toMinutes(milliseconds) -
                             TimeUnit.HOURS.toMinutes(TimeUnit.MILLISECONDS.toHours(milliseconds)),
                             TimeUnit.MILLISECONDS.toSeconds(milliseconds) -
                             TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(milliseconds)));
    }

    public static void startImageAnim(ImageView Img, int anim) {
        Img.setVisibility(View.VISIBLE);
        try {
            Img.setImageResource(anim);
            AnimationDrawable animationDrawable = (AnimationDrawable) Img.getDrawable();
            animationDrawable.start();
        } catch (ClassCastException e) {
            e.printStackTrace();
        }
    }

    public static void stopImageAnim(ImageView Img) {
        try {
            AnimationDrawable animationDrawable = (AnimationDrawable) Img.getDrawable();
            animationDrawable.stop();
        } catch (ClassCastException e) {
            e.printStackTrace();
        }
        Img.setVisibility(View.GONE);
    }


    //缓冲动画控制
    /*public static void setBufferVisibility(ImageView imgBuffer, boolean Visible) {
        if (Visible) {
            imgBuffer.setVisibility(View.VISIBLE);
            startImageAnim(imgBuffer, R.drawable.loading);
        } else {
            stopImageAnim(imgBuffer);
            imgBuffer.setVisibility(View.GONE);
        }
    }*/

    /**
     * Check whether the device is connected, and if so, whether the connection
     * is wifi or mobile (it could be something else).
     */
    public static void checkNetworkConnection(Context c, ImageButton imgNetwork) {
        // BEGIN_INCLUDE(connect)
        ConnectivityManager connMgr = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeInfo = connMgr.getActiveNetworkInfo();
        if (activeInfo != null && activeInfo.isConnected()) {
            boolean wifiConnected = activeInfo.getType() == ConnectivityManager.TYPE_WIFI;
            boolean mobileConnected = activeInfo.getType() == ConnectivityManager.TYPE_MOBILE;
            if (wifiConnected) {
                imgNetwork.setImageResource(R.drawable.ic_wifi);           
            } else if (mobileConnected) {
                imgNetwork.setImageResource(R.drawable.ic_access_point_network);  
            }
        } else {
            imgNetwork.setImageResource(R.drawable.ic_close_network);
        }
        // END_INCLUDE(connect)
    }

    public static void setNetworkVisibility(ImageView imgNetwork, boolean Visible) {
        if (Visible) {
            imgNetwork.setImageResource(R.drawable.ic_access_point_network);
            imgNetwork.setVisibility(View.VISIBLE);

        } else {

            imgNetwork.setVisibility(View.GONE);
        }
    }

    public static String getFilename(final String path) {
        return path.substring(path.lastIndexOf("/") + 1);
    }

    

    public static void showDialog(final Activity activity) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.video_player_post_layout);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        final EditText et_post = dialog.findViewById(R.id.et_post);
        final Button bt_submit = dialog.findViewById(R.id.bt_submit);
        ImageButton bt_photo = dialog.findViewById(R.id.bt_photo);
        ImageButton bt_link = dialog.findViewById(R.id.bt_link);
        ImageButton bt_setting = dialog.findViewById(R.id.bt_setting);

        bt_photo.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(activity, "PHOTO", Toast.LENGTH_SHORT).show();
                }
            });

        bt_link.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(activity, "ATTACH", Toast.LENGTH_SHORT).show();
                }
            });

        bt_setting.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(activity, "MENU", Toast.LENGTH_SHORT).show();
                }
            });

        et_post.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                    bt_submit.setEnabled(et_post.length() > 0);

                    bt_submit.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Toast.makeText(activity, et_post.getText().toString(), Toast.LENGTH_SHORT).show();
                            }
                        });
                }

                @Override
                public void afterTextChanged(Editable s) {

                }
            });

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    }

    public static void showInfoDialog(final Activity activity, String resId, String title, String duration) {
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.video_player_info_layout);
        dialog.setCancelable(true);

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT;

        final ImageView videoIcon = dialog.findViewById(R.id.video_icon);
        
        Glide.with(activity)
            .load(resId)
            .apply(new RequestOptions().placeholder(R.drawable.video_placeholder).error(R.drawable.video_placeholder))
            .into(videoIcon);
        final ImageView videoThumb = dialog.findViewById(R.id.video_thumbnail);
        
        Glide.with(activity)
            .load(resId)
            .apply(new RequestOptions().placeholder(R.drawable.video_placeholder).error(R.drawable.video_placeholder))
            .into(videoThumb);    
        final TextView videoTitle = dialog.findViewById(R.id.video_title);
        videoTitle.setText(title);
        final TextView videoDuration = dialog.findViewById(R.id.video_duration);
        videoDuration.setText(duration);

        dialog.show();
        dialog.getWindow().setAttributes(lp);
    
        }
        
    public static class AnimationImp implements AnimationListener {

        @Override
        public void onAnimationEnd(Animation animation) {

        }

        @Override
        public void onAnimationRepeat(Animation animation) {
        }

        @Override
        public void onAnimationStart(Animation animation) {
        }
    }
    
    public interface OnItemClickListener {
        void onItemClick(View clickedView, int position); 
    }

    public interface OnItemLongClickListener {
        void onItemLongClick(View clickedView, int position); 
    }
}

