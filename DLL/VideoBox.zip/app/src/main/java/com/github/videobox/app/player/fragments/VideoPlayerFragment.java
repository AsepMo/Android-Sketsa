package com.github.videobox.app.player.fragments;

import android.support.v4.app.Fragment;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.MediaStore;
import android.media.MediaMetadataRetriever;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.BatteryManager;
import android.os.Process;
import android.util.Log;
import android.text.method.LinkMovementMethod;
import android.text.format.Formatter;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Toast;

import org.json.JSONException;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.ArrayList;
import java.util.List;

import com.danikula.videocache.CacheListener;
import com.danikula.videocache.HttpProxyCacheServer;
import java.io.File;

import com.github.videobox.R;
import com.github.videobox.VideoBoxApplication;
import com.github.videobox.VideoPlayerActivity;
import com.github.videobox.app.dialogs.OptionsMenu;
import com.github.videobox.app.dialogs.interfaces.OnMenuItemClickListener;
import com.github.videobox.app.dialogs.interfaces.OnMenuItemLongClickListener;
import com.github.videobox.app.dialogs.animations.MenuParams;
import com.github.videobox.app.dialogs.models.MenuObject;
import com.github.videobox.app.dialogs.VideoListDialog;
import com.github.videobox.app.library.models.VideoData;
import com.github.videobox.app.library.adapters.VideoAdapter;
import com.github.videobox.app.library.utils.VideoPlayerUtils;
import com.github.videobox.app.player.VideoPlayer;
import com.github.videobox.app.player.VideoPlayer.OnVideoPlayerListener;
import com.github.videobox.app.analytics.Analytics;
import com.github.videobox.app.streaming.utils.NetworkUtil;
import com.github.videobox.widget.MrToast;

public class VideoPlayerFragment extends Fragment implements OnVideoPlayerListener, CacheListener {

    private VideoPlayer mPlayer;
    private VideoPlayerUtils mVideoPlayerUtils;
    private VideoListDialog mVideoLibraryDialog;
    public static final String ACTION = "android.net.conn.CONNECTIVITY_CHANGE";
    
    private Handler mHandleWarning = new Handler();
    private Runnable mWarningRunner = new Runnable(){
        @Override
        public void run() {
            MrToast.showToast(getActivity(), R.drawable.ic_android, "VideoBox Info", "Mohon Diri Untuk Menutup Proses");     
            mHandleProcess.postDelayed(mKillProcessRunner, 100);     
        }
    };

    private Handler mHandleProcess = new Handler();
    private Runnable mKillProcessRunner = new Runnable(){
        @Override
        public void run() {
            MrToast.showToast(getActivity(), R.drawable.ic_android, "VideoBox Info", "Mohon Diri Untuk Menutup Proses");    
            killProcess();
        }
    };

    private static final String LOG_TAG = "VideoFragment";

    //private static String url = "";
    public static final String DATE_FORMAT = "dd/MM/yyyy HH:mm:ss";
    /**
     * Method to convert bits per second to MB/s
     *
     * @param bps float bitsPerSecond
     * @return float
     */
    private float bitsToMb(float bps) {
        return bps / (1024 * 1024);
    }

    public static VideoPlayerFragment newInstance(VideoPlayer mPlayer) {
        VideoPlayerFragment fragment = new VideoPlayerFragment();

        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_video_player, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mPlayer = (VideoPlayer)view.findViewById(R.id.video_player);     
        mPlayer.setOnVideoPlayerListener(this);
        mPlayer.setWindowInsets();
        
        mVideoPlayerUtils =  new VideoPlayerUtils(getActivity());
    }

    private void startVideo() {
        HttpProxyCacheServer proxy = VideoBoxApplication.getProxy(getActivity());
        proxy.registerCacheListener(this, VideoPlayer.VIDEO_DRIVE_URL);
        String proxyUrl = proxy.getProxyUrl(VideoPlayer.VIDEO_DRIVE_URL);
        Log.d(LOG_TAG, "Use proxy url " + proxyUrl + " instead of original url " + VideoPlayer.VIDEO_URL);
        mPlayer.setVideoPath(proxyUrl);
        checkCachedState();
    }

    private void checkCachedState() {
        HttpProxyCacheServer proxy = VideoBoxApplication.getProxy(getActivity());
        boolean fullyCached = proxy.isCached(VideoPlayer.VIDEO_URL);
        setCachedState(fullyCached);
        if (fullyCached) {
            //progressBar.setSecondaryProgress(100);
        }
    }

    private void setCachedState(boolean cached) {
        //int statusIconId = cached ? R.drawable.ic_cloud_done : R.drawable.ic_cloud_download;
        //cacheStatusImageView.setImageResource(statusIconId);
    }

    @Override
    public void onCacheAvailable(File cacheFile, String url, int percentsAvailable) {
        //progressBar.setSecondaryProgress(percentsAvailable);
        setCachedState(percentsAvailable == 100);
        Log.d(LOG_TAG, String.format("onCacheAvailable. percents: %d, file: %s, url: %s", percentsAvailable, cacheFile, url));
    }

    @Override
    public void onNavigationIconClick(View v) {
        getActivity().finish();
    }

    @Override
    public void onVideoPlaying(VideoPlayer mMediaPlayer, String title, String thumbnail, String path) {

        MrToast.showToast(getActivity(), thumbnail, title, path);             
    }

    @Override
    public void onVideoPlaylist(View v) {
        mVideoLibraryDialog = VideoListDialog.newInstance(mPlayer);     
        if (getActivity().getFragmentManager().findFragmentByTag(VideoListDialog.TAG) == null) {
            mVideoLibraryDialog.show(getActivity().getFragmentManager(), VideoListDialog.TAG);
        }
    }

    @Override
    public void onVideoComplete(VideoPlayer mp) {
        mPlayer.pauseVideo();
    }

    @Override
    public void onVideoOrientation(View v) {
        //mPlayer.getScreenOrientation(getActivity());
    }

    @Override
    public void onVideoConnection(View v) {
    }

    @Override
    public void onVideoMenu(View v) {

    }

    @Override
    public void onVideoError(VideoPlayer player, Exception e) {
    }

    @Override
    public void onStart() {
        super.onStart();

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_BATTERY_CHANGED);
        f.addAction(ACTION);
        getActivity().registerReceiver(onBattery, f);
    }

    @Override
    public void onStop() {
        getActivity().unregisterReceiver(onBattery);
        super.onStop();
    }


    private BroadcastReceiver onBattery = new BroadcastReceiver() {
        boolean flag = false;
        
        @Override
        public void onReceive(Context context, Intent intent) {
            // String action = intent.getAction();
            int status = NetworkUtil.getConnectivityStatusString(context);
            if(status == NetworkUtil.NETWORK_STATUS_NOT_CONNECTED) {
                mPlayer.getVideoPlaylist();
                flag = true;
            }else{
                startVideo();
            }
            int pct = 100 * intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 1) / intent.getIntExtra(BatteryManager.EXTRA_SCALE, 1);
            if (Integer.toString(pct).equals("30")) {
                MrToast.showToast(getActivity(), R.drawable.ic_battery, "Peringatan..!", "Battery Anda Sekitar " + Integer.toString(pct) + "%");
            } 
            if (Integer.toString(pct).equals("25")) {
                MrToast.showToast(getActivity(), R.drawable.ic_battery, "Peringatan..!", "Battery Anda Sekitar " + Integer.toString(pct) + "%");

                mHandleWarning.postDelayed(mWarningRunner, 100);        
            }
            switch (intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1)) {
                case BatteryManager.BATTERY_STATUS_CHARGING:
                    MrToast.showToast(getActivity(), R.drawable.ic_battery_charging, "Perhatian..!", "Battery Charging");                
                    break;

                case BatteryManager.BATTERY_STATUS_FULL:
                    int plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);

                    if (plugged == BatteryManager.BATTERY_PLUGGED_AC || plugged == BatteryManager.BATTERY_PLUGGED_USB) {
                        MrToast.showToast(getActivity(), R.drawable.ic_battery_charging, "Perhatian..!", "Battery Charging");                                 
                    } else {
                        MrToast.showToast(getActivity(), R.drawable.ic_battery_charging, "Perhatian..!", "Battery Plugged USB");                
                    }
                    break;
                    /*case BatteryManager.BATTERY_STATUS_DISCHARGING:
                     MrToast.showToast(getActivity(), R.drawable.ic_battery_charging, "Perhatian..!", "Battery Discharging");                               
                     break;
                     case BatteryManager.BATTERY_STATUS_NOT_CHARGING:
                     MrToast.showToast(getActivity(), R.drawable.ic_battery_charging, "Perhatian..!", "Battery Not Charging");                               
                     break;*/  
            }
        }
    };

    public void killProcess() {
        new Handler().postDelayed(new Runnable(){
                @Override
                public void run() {
                    MrToast.showToast(getActivity(), R.drawable.ic_android, "VideoBox Info", "Selamat Tinggal!Isi Baterainya Dulu,Ya...");                  
                    Process.killProcess(Process.myPid()); 
                }

            }, 200);        
    }

    @Override
    public void onPause() {
        super.onPause();
        
        mHandleWarning.removeCallbacks(mWarningRunner);
        mHandleProcess.removeCallbacks(mKillProcessRunner);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mPlayer.onDestroy();
        VideoBoxApplication.getProxy(getActivity()).unregisterCacheListener(this);
        mHandleWarning.removeCallbacks(mWarningRunner);
        mHandleProcess.removeCallbacks(mKillProcessRunner);
    }
}
