package com.github.videobox;

import android.annotation.TargetApi;
import android.support.v7.app.AppCompatActivity;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.BatteryManager;
import android.os.Process;
import android.os.Build;

import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.MotionEvent;
import android.view.WindowInsets;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Toast;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.gplibs.magicsurfaceview.MagicUpdater;
import com.gplibs.magicsurfaceview.MagicUpdaterListener;

import com.github.videobox.app.dialogs.OptionsMenu;
import com.github.videobox.app.dialogs.interfaces.OnMenuItemClickListener;
import com.github.videobox.app.dialogs.interfaces.OnMenuItemLongClickListener;
import com.github.videobox.app.dialogs.animations.MenuParams;
import com.github.videobox.app.dialogs.models.MenuObject;
import com.github.videobox.app.dialogs.VideoListDialog;
import com.github.videobox.app.player.VideoPlayer;
import com.github.videobox.app.player.VideoPlayer.OnVideoPlayerListener;
import com.github.videobox.app.library.models.VideoData;
import com.github.videobox.app.library.utils.VideoPlayerUtils;
import com.github.videobox.app.library.fragments.VideoLibraryFragment;
import com.github.videobox.app.common.Api;
import com.github.videobox.app.common.Direction;
import com.github.videobox.app.common.SystemBarTintManager;
import com.github.videobox.app.common.MagicActivity;
import com.github.videobox.app.updater.VortexAnimUpdater;
import com.github.videobox.widget.MrToast;

import static com.github.videobox.app.library.fragments.VideoLibraryFragment.videoArrayList;

public class VideoPlayerActivity extends MagicActivity implements VideoPlayer.OnVideoPlayerListener {

    public static String TAG = VideoPlayerActivity.class.getSimpleName();   
    //private MagicSurfaceView mSurfaceView;
    private VideoPlayer mPlayer;
    private VideoPlayerUtils mVideoPlayerUtils;
    private VideoListDialog mVideoLibraryDialog;
    private Integer video_index;

    public final static String ACTION_VIDEO_VIEW = "com.github.videobox.action.VIDEO_VIEW";
    public final static String ACTION_VIDEO_PLAYER = "com.github.videobox.action.VIDEO_PLAYER";

    public static String VIDEO = "video";
    public static String VIDEO_INDEX= "video_index";
    private String currentVideo;

    private final int VIDEO_INFO = 1;
    private final int VIDEO_PLAYER = 2;
    private final int VIDEO_FOLDER = 3;
    private final int VIDEO_RECORDER = 4;
    private final int VIDEO_MORE = 5;

    private final int VIDEO_MOVIE = 1;
    private final int VIDEO_3D = 2;
    private final int VIDEO_EDITOR = 3;
    private final int VIDEO_SHARE= 4;
    private final int VIDEO_MANAGE = 5;
    private Handler mHandler;
    private Runnable mRunner = new Runnable(){
        @Override
        public void run() {
            onMoreMenu();
        }
    };

    public static void startVideoViewer(Context context, String video) {
        Intent intent = new Intent(context, VideoPlayerActivity.class);
        intent.setAction(ACTION_VIDEO_VIEW);
        intent.putExtra(VIDEO, video);
        context.startActivity(intent);
    }

    public static void startVideoPlayer(Context context, Integer video) {
        Intent intent = new Intent(context, VideoPlayerActivity.class);
        intent.setAction(ACTION_VIDEO_PLAYER);
        intent.putExtra(VIDEO_INDEX, video);
        context.startActivity(intent);
    }

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if (Api.hasLollipop()) {
            getWindow().setStatusBarColor(R.color.colorPrimaryDark);
        } else if (Api.hasKitKat()) {
            SystemBarTintManager systemBarTintManager = new SystemBarTintManager(this);
            systemBarTintManager.setTintColor(Api.getStatusBarColor(getColor(R.color.colorPrimaryDark)));
            systemBarTintManager.setStatusBarTintEnabled(true);
        }
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_player);
        //setTitle("VideoBox");
        hidePageTitleBar();
        // mSurfaceView = (MagicSurfaceView) findViewById(R.id.surface_view);
        mPlayer = (VideoPlayer)findViewById(R.id.video_player);
        mPlayer.getPlaylist();
        mPlayer.setOnVideoPlayerListener(this);
        String action = getIntent().getAction();
        if (action != null && action.equals(ACTION_VIDEO_VIEW)) {
            currentVideo = getIntent().getStringExtra(VIDEO);
            if (TextUtils.isEmpty(currentVideo)) {
                MrToast.showToast(this, R.mipmap.ic_launcher, getString(R.string.app_name), "Tidak Ada Video Yang Dapat DiPutar Atau Url Rusak");       
            } else {
                mPlayer.setVideoPath(currentVideo);
            }         
        } else if (action != null && action.equals(ACTION_VIDEO_PLAYER)) {
            video_index = getIntent().getIntExtra(VIDEO_INDEX, 0); 
            if (TextUtils.isEmpty(Integer.toString(video_index))) {
                mPlayer.setPlaylist(videoArrayList, Integer.valueOf(videoArrayList.get(0).getVideoPath()));                         
            } else {
                mPlayer.setPlaylist(videoArrayList, video_index);           
            }                  
        } 
        mPlayer.showOrHideSystemUi(true);
        mPlayer.setWindowInsets();
        mVideoPlayerUtils =  new VideoPlayerUtils(this);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        mPlayer.setWindowInsets();
    }
    
    @Override
    public void onNavigationIconClick(View v) {
        VideoPlayerActivity.this.finish();
    }

    @Override
    public void onVideoPlaying(VideoPlayer mMediaPlayer, String title, String thumbnail, String path) {
           
    }

    @Override
    public void onVideoPlaylist(View v) {
        mVideoLibraryDialog = VideoListDialog.newInstance(mPlayer);     
        if (getFragmentManager().findFragmentByTag(VideoListDialog.TAG) == null) {
            mVideoLibraryDialog.show(getFragmentManager(), VideoListDialog.TAG);
        }
    }

    @Override
    public void onVideoComplete(VideoPlayer mp) {
        
    }
    
    @Override
    public void onVideoOrientation(View v) {
        mPlayer.getScreenOrientation(VideoPlayerActivity.this);
    }

    @Override
    public void onVideoConnection(View v) {
    }

    @Override
    public void onVideoMenu(View v) {
        mVideoPlayerUtils.setMenuFragment(this, VideoPlayerUtils.getOptionsMenu());
        mVideoPlayerUtils.setOnItemClickListener(new VideoPlayerUtils.OnItemClickListener(){
                @Override
                public void onItemClick(View clickedView, int position) {
                    switch (position) {
                        case VIDEO_INFO:
                            break;
                        case VIDEO_PLAYER:

                            break;  
                        case VIDEO_FOLDER:
                            VideoPlayerUtils.setActivity(VideoPlayerActivity.this, VideoFolderActivity.class);
                            break; 
                        case VIDEO_RECORDER:
                            break; 
                        case VIDEO_MORE:
                            mHandler = new Handler();
                            mHandler.postDelayed(mRunner, 100);
                            break;    
                    }
                    Toast.makeText(VideoPlayerActivity.this, "Clicked on position: " + position, Toast.LENGTH_SHORT).show();
                }
            });
        mVideoPlayerUtils.setOnItemLongClickListener(new VideoPlayerUtils.OnItemLongClickListener(){
                @Override
                public void onItemLongClick(View clickedView, int position) {
                    Toast.makeText(VideoPlayerActivity.this, "Clicked on position: " + position, Toast.LENGTH_SHORT).show();
                }
            });
    }

    @Override
    public void onVideoError(VideoPlayer player, Exception e) {
    }

    public void onMoreMenu() {

        mVideoPlayerUtils.setMenuFragment(this, VideoPlayerUtils.getMoreMenu());
        mVideoPlayerUtils.setOnItemClickListener(new VideoPlayerUtils.OnItemClickListener(){
                @Override
                public void onItemClick(View clickedView, int position) {
                    switch (position) {
                        case VIDEO_MOVIE:
                            break;
                        case VIDEO_3D:
                            break;  
                        case VIDEO_EDITOR:
                            VideoEditorActivity.startVideoEditor(VideoPlayerActivity.this);
                            break; 
                        case VIDEO_SHARE:
                            break; 
                        case VIDEO_MANAGE:
                            break;    
                    }
                    Toast.makeText(VideoPlayerActivity.this, "Clicked on position: " + position, Toast.LENGTH_SHORT).show();
                }
            });
        mVideoPlayerUtils.setOnItemLongClickListener(new VideoPlayerUtils.OnItemLongClickListener(){
                @Override
                public void onItemLongClick(View clickedView, int position) {
                    Toast.makeText(VideoPlayerActivity.this, "Clicked on position: " + position, Toast.LENGTH_SHORT).show();
                }
            });
    }



    @Override
    public void onPause() {
        super.onPause();

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mPlayer.onDestroy();
    }

    
    @Override
    protected MagicUpdater getPageUpdater(boolean isHide) {
        //return new MacWindowAnimUpdater(isHide, Direction.RIGHT, 0.184f, false);
        return new VortexAnimUpdater(isHide);
    }
}
