package com.github.videobox.app.analytics;

import java.util.Calendar;
import java.util.Date;

public class RandomEvent {
    
    public static String TAG = RandomEvent.class.getSimpleName();
    public Date when = Calendar.getInstance().getTime();
    public String value;

    public RandomEvent(String value) {
        this.value = value;
    }
}


