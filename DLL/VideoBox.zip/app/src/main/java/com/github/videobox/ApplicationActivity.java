package com.github.videobox;

import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;

import com.github.videobox.app.player.fragments.VideoPlayerFragment;
import com.github.videobox.app.library.fragments.VideoLibraryFragment;
import com.github.videobox.app.common.Api;
import com.github.videobox.app.common.Direction;
import com.github.videobox.app.common.SystemBarTintManager;
import com.github.videobox.app.common.MagicActivity;
import com.github.videobox.app.updater.VortexAnimUpdater;
import com.github.videobox.app.library.models.VideoData;
import com.github.videobox.widget.soundPool.SoundPoolManager;
import com.github.videobox.widget.TabDrawer;
import com.github.videobox.widget.model.Tab;
import com.github.videobox.widget.model.TabDrawerData;
import com.github.videobox.widget.model.TabListItem;
import com.gplibs.magicsurfaceview.MagicSurface;
import com.gplibs.magicsurfaceview.MagicSurfaceView;
import com.gplibs.magicsurfaceview.MagicUpdater;
import com.gplibs.magicsurfaceview.MagicUpdaterListener;

public class ApplicationActivity extends MagicActivity {

    private Context context;
    private Activity activity;
    
    private TabDrawer tabDrawer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        context = this;
        activity = this;
        hidePageTitleBar();
        
    }

    private TabDrawerData prepareTabArray() {
        return new TabDrawerData()
            // Simple
            .setTabIconColors(
            Color.parseColor("#3199ff"),
            Color.parseColor("#ffffff"),
            Color.parseColor("#CCCCCC")
        )
            .setTabTitleSize(12)
            .setTabTitleColors(
            ContextCompat.getColor(context, R.color.tabTitle),
            ContextCompat.getColor(context, R.color.tabTitle_selected),
            Color.parseColor("#CCCCCC")
        )
            .setTabBackgroundColors(
            ContextCompat.getColor(context, R.color.tabBackground),
            ContextCompat.getColor(context, R.color.tabBackground_selected),
            Color.parseColor("#455A64")
        )
            .setTabListItemTitleColors(Color.parseColor("#ffffff"))
            .setTabListItemTitleSize(16)

            .addTab(new Tab()
                    .setTitle("Menu")
                    .setIconImage(R.drawable.ic_view_list)
                    .addTabListItem(new TabListItem("Home", R.drawable.ic_home_white_24dp))
                    .addTabListItem(new TabListItem("Player", R.drawable.ic_video_player))
                    .addTabListItem(new TabListItem("Library", R.drawable.ic_library_video))
                    .addTabListItem(new TabListItem("Folder", R.drawable.ic_folder))
                    .addTabListItem(new TabListItem("Recorder", R.drawable.ic_camera))
                    )

            .addTab(new Tab()
                    .setTitle("Queue")
                    .setIconImage(R.drawable.ic_format_list_checks)
                    //.setDrawerListColumnNumber(2)
                    .addTabListItem(new TabListItem("Add To Queue", R.drawable.ic_add_box_white_24dp))
                    .addTabListItem(new TabListItem("History", R.drawable.ic_history))
                    .addTabListItem(new TabListItem("Favorite", R.drawable.ic_heart)))

            .addTab(new Tab()
                    .setTitle("Chat")
                    .setIconImage(R.drawable.n_chat)
                    //.setDrawerListColumnNumber(2)
                    .addTabListItem(new TabListItem("Friends", R.drawable.ic_face_white_24dp))
                    .addTabListItem(new TabListItem("Add Friend", R.drawable.ic_person_add_white_24dp))
                    .addTabListItem(new TabListItem("Start Group Chat", R.drawable.ic_people_white_24dp))
                    .addTabListItem(new TabListItem("Funny Moments", R.drawable.ic_sentiment_very_satisfied_white_24dp)))


            .addTab(new Tab()
                    .setTitle("Reports")
                    .setIconImage(R.drawable.n_report)
                    .addTabListItem(new TabListItem("Completed Jobs", R.drawable.ic_event_available_white_24dp))
                    .addTabListItem(new TabListItem("Cancelled Jobs", R.drawable.ic_event_busy_white_24dp))
                    .addTabListItem(new TabListItem("Customer Feedbacks", R.drawable.ic_feedback_white_24dp))
                    .addTabListItem(new TabListItem("Documents", R.drawable.ic_description_white_24dp))
                    .addTabListItem(new TabListItem("Battery Monitor", R.drawable.ic_battery)))


            .addTab(new Tab()
                    .setTitle("Settings")
                    .setIconImage(R.drawable.n_settings)
                    .addTabListItem(new TabListItem("General", R.drawable.ic_settings_white_24dp))
                    .addTabListItem(new TabListItem("My Account", R.drawable.ic_lock_white_24dp))
                    .addTabListItem(new TabListItem("Accesibility", R.drawable.ic_accessibility_white_24dp))
                    .addTabListItem(new TabListItem("Notifications", R.drawable.ic_notifications_white_24dp))
                    .addTabListItem(new TabListItem("Bookmarks", R.drawable.ic_collections_bookmark_white_24dp))
                    .addTabListItem(new TabListItem("Shared Folders", R.drawable.ic_folder_shared_white_24dp))
                    .addTabListItem(new TabListItem("Cast to TV", R.drawable.ic_cast_white_24dp))
                    .addTabListItem(new TabListItem("Other Applications", R.drawable.ic_apps_white_24dp)));             

    }

    public void prepareTabDrawer() { prepareTabDrawer(false); }

    public void prepareTabDrawer(boolean additional) {
        TabDrawerData tabDrawerDataTemp = prepareTabArray();

        // Clone 3 tabs to the end to fill space when it is Left or Right TabDrawer
        if (additional) {
            TabDrawerData tabDrawerDataTemp2 = prepareTabArray();
            tabDrawerDataTemp.addTab(tabDrawerDataTemp2.getTab(3).setTitle("Add 1"));
            tabDrawerDataTemp.addTab(tabDrawerDataTemp2.getTab(2).setTitle("Add 2"));
            tabDrawerDataTemp.addTab(tabDrawerDataTemp2.getTab(1).setTitle("Add 3"));
        }

        final TabDrawerData tabDrawerData = tabDrawerDataTemp;

        tabDrawer = new TabDrawer(context, activity, R.id.tabDrawer, tabDrawerData) {
            @Override
            public void onTabDrawerClicked(int tabPosition, int itemPosition) {
                super.onTabDrawerClicked(tabPosition, itemPosition);

                String text = tabDrawerData.getTab(tabPosition).getTitle();
                if (text == null) text = "... MORE ...";

                /*if (tabDrawerData.getTab(tabPosition).hasItems()) {
                 if (tabDrawerData.getTab(tabPosition).getTabItemList().get(itemPosition).getTitle() != null)
                 text += " -> " + tabDrawerData.getTab(tabPosition).getTabItemList().get(itemPosition).getTitle();

                 text += " - ( " + tabPosition + ", " + itemPosition + " )";
                 } else
                 text += " - ( " + tabPosition + " )";


                 Toast toast = Toast.makeText(context, text, Toast.LENGTH_SHORT);
                 toast.show();*/

                if (tabPosition == 0) {

                    if (itemPosition == 0) {
                        showFragment(new VideoBoxFragment());
                    } 
                    if (itemPosition == 1) {
                        showFragment(new VideoPlayerFragment());
                    }
                    if (itemPosition == 2) {
                        showFragment(new VideoLibraryFragment());
                    }
                    if (itemPosition == 3) {
                        showActivity(VideoFolderActivity.class);
                    }
                    if (itemPosition == 4) {
                        //showFragment(new VideoRecorderFragment());
                    }
                } 
                if (tabPosition == 1) {

                    if (itemPosition == 0) {
                        //showFragment(new EditorFragment());
                    } 
                    if (itemPosition == 1) {
                        
                    }     
                }
                if (tabPosition == 2) {

                    if (itemPosition == 0) {
                        //showFragment(new VideoRecorderFragment());
                    }                 
                }
                if (tabPosition == 3) {

                    if (itemPosition == 0) {

                    }  
                    if (itemPosition == 1) {

                    }
                    if (itemPosition == 2) {

                    }   
                    if (itemPosition == 3) {

                    }    
                    if (itemPosition == 4) {
                        //showFragment(new BroadcastMonitorFragment());
                    }    
                }
                if (tabPosition == 4) {

                    if (itemPosition == 0) {
                        //showActivity(SettingsActivity.class);
                    }                 
                }
            }
        };

        tabDrawer.initialize();
    }


    public void showActivity(Class<?> mClass) {
        Intent intent = new Intent(this, mClass);
        startActivity(intent);
    }

    public void showFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    }

    @Override
    public void onBackPressed() {
        if (tabDrawer.isDrawerOpen())
            tabDrawer.closeDrawer();
        else
            super.onBackPressed();
    }
    
    @Override
    protected MagicUpdater getPageUpdater(boolean isHide) {
        return new VortexAnimUpdater(isHide);
    }
}
