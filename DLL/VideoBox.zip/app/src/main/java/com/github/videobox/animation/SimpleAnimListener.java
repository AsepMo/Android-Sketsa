package com.github.videobox.animation;

import android.view.animation.Animation;

public abstract class SimpleAnimListener implements Animation.AnimationListener {

    @Override
    public void onAnimationRepeat(Animation animation) {

    }

    @Override
    public void onAnimationStart(Animation animation) {

    }
}

