package com.github.videobox.app.library.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.LinearLayout;
import android.widget.BaseAdapter;
import android.widget.TextView;
import android.widget.ImageView;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup.MarginLayoutParams;
import android.widget.Toast;

import com.github.videobox.R;

public class VideoEditorAdapter extends BaseAdapter
{

    // Declare Variables
    Context context;
    String[] title,message;
    String[] number;
    LayoutInflater inflater;
    // Declare Variables
    /**
     * Internal Views
     */
    View mLineView;
    TextView mTitleText;
    TextView mSummaryText;
    TextView mDoneIconView;
    LinearLayout mPointFrame;
    LinearLayout mRightContainer;  
    View mMarginBottomView;


    public VideoEditorAdapter(Context context, String[] title, String[] message, String[] number)
    {
        this.context = context;
        this.title = title;
        this.message = message;
        this.number = number;
    }

    @Override
    public int getCount()
    {
        return title.length;
    }


    @Override
    public Object getItem(int position)
    {
        return null;
    }

    @Override
    public long getItemId(int position)
    {
        return 0;
    }

    public View getView(int position, View convertView, ViewGroup parent)
    {
        inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        View inflateView = inflater.inflate(R.layout.item_video_editor_layout, parent, false);

        mLineView = inflateView.findViewById(R.id.stepper_line);
        mTitleText = inflateView.findViewById(R.id.stepper_title);
        mSummaryText = inflateView.findViewById(R.id.stepper_summary);
        mPointFrame = inflateView.findViewById(R.id.stepper_point_frame);
        mRightContainer = inflateView.findViewById(R.id.stepper_right_layout);
        mDoneIconView = inflateView.findViewById(R.id.stepper_done_icon);
        mMarginBottomView = inflateView.findViewById(R.id.stepper_margin_bottom);

        // Set title top margin
        mTitleText.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override
                public void onGlobalLayout() {
                    int singleLineHeight = mTitleText.getMeasuredHeight();
                    int topMargin = (mPointFrame.getMeasuredHeight() - singleLineHeight) / 2;
                    // Only update top margin when it is positive, preventing titles being truncated.
                    if (topMargin > 0) {
                        ViewGroup.MarginLayoutParams mlp = (MarginLayoutParams) mTitleText.getLayoutParams();
                        mlp.topMargin = topMargin;
                    }
                }
            });

        // Capture position and set to the ImageView
        mDoneIconView.setText(number[position]);
        mTitleText.setText(title[position]);
        mSummaryText.setText(message[position]);

        return inflateView;
    }
}

