package com.github.videobox;

import android.annotation.TargetApi;
import android.graphics.Color;
import android.content.Intent;
import android.content.Context;
import android.os.Bundle;
import android.os.Build;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.TextView;

import com.github.videobox.app.editor.VideoEditorFragment;
import com.github.videobox.app.common.Api;
import com.github.videobox.app.common.Direction;
import com.github.videobox.app.common.SystemBarTintManager;
import com.github.videobox.app.common.MagicActivity;
import com.github.videobox.app.updater.VortexAnimUpdater;
import com.gplibs.magicsurfaceview.MagicUpdater;
import com.gplibs.magicsurfaceview.MagicUpdaterListener;

public class VideoEditorActivity extends MagicActivity
{
    public static String TAG = VideoEditorActivity.class.getSimpleName();   
    //private MagicSurfaceView mSurfaceView;
    public static void startVideoEditor(Context context) {
        Intent intent = new Intent(context, VideoEditorActivity.class);
        context.startActivity(intent);
    }
    
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        //int color = Api.getStatusBarColor(SettingsActivity.getPrimaryColor(this));
        if (Api.hasLollipop())
        {
            getWindow().setStatusBarColor(R.color.colorPrimaryDark);
        }
        else if (Api.hasKitKat())
        {
            SystemBarTintManager systemBarTintManager = new SystemBarTintManager(this);
            systemBarTintManager.setTintColor(Api.getStatusBarColor(getColor(R.color.colorPrimaryDark)));
            systemBarTintManager.setStatusBarTintEnabled(true);
        }
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_editor);
        //setTitle("VideoBox");
        hidePageTitleBar();
       // mSurfaceView = (MagicSurfaceView) findViewById(R.id.surface_view);
       getSupportFragmentManager()
       .beginTransaction()
       .replace(R.id.video_content_frame, new VideoEditorFragment())
       .commit();
     }
     
    // 设置Page转场动画
    @Override
    protected MagicUpdater getPageUpdater(boolean isHide) {
        //return new MacWindowAnimUpdater(isHide, Direction.RIGHT, 0.184f, false);
        return new VortexAnimUpdater(isHide);
    }
}
