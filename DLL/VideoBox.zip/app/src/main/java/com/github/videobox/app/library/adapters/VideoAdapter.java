package com.github.videobox.app.library.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageView;

import java.util.ArrayList;
import java.util.List;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import com.github.videobox.R;
import com.github.videobox.app.library.models.VideoData;
import com.github.videobox.app.dialogs.utils.Utils;
import com.github.videobox.widget.BannerLayout;

public class VideoAdapter extends RecyclerView.Adapter<VideoAdapter.viewHolder> {

    private Context mContext;
    private ArrayList<VideoData> urlList;

    private OnItemClickListener mOnItemClickListener;
    private OnItemLongClickListener mOnItemLongClickListener;
    private BannerLayout.OnBannerItemClickListener onBannerItemClickListener;

    public void setOnBannerItemClickListener(BannerLayout.OnBannerItemClickListener onBannerItemClickListener) {
        this.onBannerItemClickListener = onBannerItemClickListener;
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        mOnItemClickListener = listener;
    }

    public void setOnItemLongClickListener(OnItemLongClickListener listener) {
        mOnItemLongClickListener = listener;
    }

    public VideoAdapter(Context context, ArrayList<VideoData> urlList) {
        this.mContext = context;
        this.urlList = urlList; 
    }

    @Override
    public VideoAdapter .viewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(mContext).inflate(R.layout.video_library_items, viewGroup, false);
        return new viewHolder(view);
    }

    @Override
    public void onBindViewHolder(final VideoAdapter .viewHolder holder, final int position) {
        final VideoData video = urlList.get(position);   
        if (urlList == null || urlList.isEmpty())
            return;
        final int P = position % urlList.size();

        holder.title.setText(video.getVideoTitle());
        
        Glide.with(mContext)
            .load(video.getVideoThumbnail())
            .apply(new RequestOptions().placeholder(R.drawable.video_placeholder).error(R.drawable.video_placeholder))
            .into(holder.thumb);
            
        holder.duration.setText(video.getVideoDuration());
        holder.date.setText(video.getVideoDate());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {             
                    if (mOnItemClickListener != null)
                        mOnItemClickListener.onItemClick(P, v);
                    if (onBannerItemClickListener != null) {
                        onBannerItemClickListener.onItemClick(P);
                    } 
                }
            });
    }

    @Override
    public int getItemCount() {
        if (urlList != null) {
            return urlList.size();
        }
        return 0;
    }


    public class viewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView duration;
        TextView date;
        ImageView thumb;
        public viewHolder(View itemView) {
            super(itemView);
            title = (TextView) itemView.findViewById(R.id.video_title);
            duration = (TextView) itemView.findViewById(R.id.video_duration);
            date = (TextView) itemView.findViewById(R.id.video_last_modified);    
            thumb = (ImageView) itemView.findViewById(R.id.video_thumbnail);
            itemView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        if (mOnItemClickListener != null)
                            mOnItemClickListener.onItemClick(getAdapterPosition(), v);                 
                    }
                });
            itemView.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View v) {
                        if (mOnItemLongClickListener != null)
                            mOnItemLongClickListener.onItemLongClick(getAdapterPosition(), v);
                        return true;
                    }
                });
        }

    }

    public interface OnItemClickListener {
        void onItemClick(int position, View v);
    }

    public interface OnItemLongClickListener {
        boolean onItemLongClick(int position, View v);
    }
}


