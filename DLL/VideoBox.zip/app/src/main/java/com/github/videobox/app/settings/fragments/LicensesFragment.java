package com.github.videobox.app.settings.fragments;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;

import com.github.videobox.R;

public class LicensesFragment extends DialogFragment {
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater dialogInflater = getActivity().getLayoutInflater();
        View openSourceLicensesView = dialogInflater.inflate(R.layout.layout_video_licensi, null);

        AlertDialog.Builder dialogBuilder = new AlertDialog.Builder(getActivity());
        dialogBuilder.setView(openSourceLicensesView)
            .setTitle((getString(R.string.dialog_title_licenses)))
            .setNeutralButton(android.R.string.ok, null);

        return dialogBuilder.create();
    }
}

