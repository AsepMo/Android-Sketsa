package com.github.videobox.app.library.fragments;

import android.Manifest;
import android.support.v4.app.Fragment;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.provider.MediaStore;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.widget.Toast;

import org.json.JSONException;

import java.io.IOException;
import java.util.ArrayList;

import com.github.videobox.R;

import com.github.videobox.app.library.models.VideoData;
import com.github.videobox.app.library.adapters.VideoAdapter;
import com.github.videobox.app.library.utils.VideoPlayerUtils;
import com.github.videobox.app.library.utils.VideoKit;
import com.github.videobox.widget.VideoLayout;

import com.github.videobox.VideoPlayerActivity;

public class VideoLibraryFragment extends Fragment
{

    public static ArrayList<VideoData> videoArrayList;
    private VideoData mVideoData;
    private VideoLayout mVideoLayout;
    private View rootView;
    private RecyclerView recyclerView;
    public static final int PERMISSION_READ = 0;
    private Handler mHandler = new Handler(); 
    private Runnable mFirstTimeRunner = new Runnable()
    {
        @Override 
        public void run() {
            mVideoLayout.setPathOrUrl("loginvideotype4.mp4");     
        }
    }; 
    
    private static final String EXTRA_TEXT = "text";

    public static VideoLibraryFragment newInstance(String text) {
        VideoLibraryFragment fragment = new VideoLibraryFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_video_library, container, false);
        return rootView;
    }
    
    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mVideoData = new VideoData(getActivity(), VideoData.FILENAME);
        
        if (checkPermission()) {
            videoList(view);
        }
    }
    
    public void videoList(View v) {
        mVideoLayout = (VideoLayout)v.findViewById(R.id.videoLayout);
        mHandler.postDelayed(mFirstTimeRunner, 200);
        recyclerView = (RecyclerView) v.findViewById(R.id.video_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        videoArrayList = getLocallyStoredData();
        VideoAdapter  adapter = new VideoAdapter(getActivity(), videoArrayList);
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new VideoAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(int pos, View v) {
                    /*Intent intent = new Intent(getActivity(), VideoPlayerActivity.class);
                    intent.setAction(VideoPlayerActivity.ACTION_VIDEO_PLAYER);
                    intent.putExtra(VideoPlayerActivity.VIDEO_INDEX, pos);
                    startActivity(intent);*/
                    VideoData video = videoArrayList.get(pos);
                    mVideoData.initialise(video);
                    final VideoKit.Builder builder = new VideoKit.Builder(getActivity());
                    builder.displayAt(50,200);  
                    builder.getTool().setConsoleWidth(240);
                    builder.getTool().setConsoleHeight(200);
                    builder.getTool().setVideoPath(video.getVideoPath());
                    builder.build(); 
                }
            });
    }

    public ArrayList<VideoData> getLocallyStoredData()
    {
        ArrayList<VideoData> items = null;
        try
        {
            items = mVideoData.loadFromFile();
        }
        catch (IOException | JSONException e)
        {
            e.printStackTrace();
        }

        if (items == null)
        {
            items = new ArrayList<>();
        }
        return items;
    }
    
    @Override
    public void onResume() {
        super.onResume();
        mVideoLayout.onResumeVideoLayout(); 
    }

    @Override
    public void onPause() {
        super.onPause();
        mHandler.removeCallbacks(mFirstTimeRunner);
        mVideoLayout.onPauseVideoLayout(); 
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mVideoLayout.onDestroyVideoLayout();
        mHandler.removeCallbacks(mFirstTimeRunner);
    }
    
  
    //runtime storage permission
    public boolean checkPermission() {
        int READ_EXTERNAL_PERMISSION = ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.READ_EXTERNAL_STORAGE);
        if((READ_EXTERNAL_PERMISSION != PackageManager.PERMISSION_GRANTED)) {
            ActivityCompat.requestPermissions(getActivity(), new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, PERMISSION_READ);
            return false;
        }
        return true;
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode) {
            case  PERMISSION_READ: {
                    if (grantResults.length > 0 && permissions[0].equals(Manifest.permission.READ_EXTERNAL_STORAGE)) {
                        if (grantResults[0] == PackageManager.PERMISSION_DENIED) {
                            Toast.makeText(getActivity(), "Please allow storage permission", Toast.LENGTH_LONG).show();
                        } else {
                            videoList(rootView);
                        }
                    }
                }
        }
    }
}
