package com.github.videobox;

import android.app.Application;
import android.app.Activity;
import android.content.Context;

import java.io.File;
import java.io.IOException;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.danikula.videocache.HttpProxyCacheServer;

import com.github.videobox.app.analytics.Analytics;
import com.github.videobox.app.permissions.PermissionsManager;
import com.github.videobox.app.permissions.PermissionsResultAction;
import com.github.videobox.app.settings.SharedPref;
import com.github.videobox.app.folders.VideoFolder;
import com.github.videobox.app.library.utils.FontsOverride;
import com.github.videobox.widget.MrToast;
import com.github.videobox.widget.soundPool.ISoundPoolLoaded;
import com.github.videobox.widget.soundPool.SoundPoolManager;

public class VideoBoxApplication extends Application {

    private static VideoBoxApplication sInstance;
	private static Context mContext;
    public static SharedPref sharedPref;
    private static SharedPref appPreferences = null;
    private HttpProxyCacheServer proxy;


    @Override
    public void onCreate() {
        super.onCreate();
        sInstance = this;
        mContext = getApplicationContext();
        sharedPref = new SharedPref(getApplicationContext());
        sharedPref.setFirstTimeLaunch(true);
        SoundPool();
        VideoFolder.initVideoBox(getApplicationContext());
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        try {
            Analytics.cleanVideoCacheDir(getContext());
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static synchronized VideoBoxApplication getInstance() {
        return sInstance;
    } 

    public static Context getContext() {
        return mContext;
    }

    public static SharedPref getAppPreferences(Context c) {
        if (appPreferences == null)
            appPreferences = SharedPref.loadPreferences(c);

        return appPreferences;
    }

    public static void checkPermissions(final Activity context) {
        PermissionsManager.getInstance().requestAllManifestPermissionsIfNecessary(context, new PermissionsResultAction() {
                @Override
                public void onGranted() {
                }

                @Override
                public void onDenied(String permission) {
                    String message = String.format(Locale.getDefault(), context.getString(R.string.message_denied), permission);
                    new MrToast(context).sendShortMessage(message);
                }
            });
    }

    public enum Video {

        ORANGE_1(Config.ROOT + "orange1.mp4"),
        ORANGE_2(Config.ROOT + "orange2.mp4"),
        ORANGE_3(Config.ROOT + "orange3.mp4"),
        ORANGE_4(Config.ROOT + "orange4.mp4"),
        ORANGE_5(Config.ROOT + "orange5.mp4");

        public final String url;

        Video(String url) {
            this.url = url;
        }

        private class Config {
            private static final String ROOT = "https://raw.githubusercontent.com/danikula/AndroidVideoCache/master/files/";
        }
    }
    
    public void SoundPool() {
        SoundPoolManager.CreateInstance();
        List<Integer> sounds = new ArrayList<Integer>();
        sounds.add(R.raw.sound1);
        sounds.add(R.raw.sound2);
        SoundPoolManager.getInstance().setSounds(sounds);
        try {
            SoundPoolManager.getInstance().InitializeSoundPool(getApplicationContext(), new ISoundPoolLoaded() {
                    @Override
                    public void onSuccess() {

                    }
                });
        } catch (Exception e) {
            e.printStackTrace();
        }

        SoundPoolManager.getInstance().setPlaySound(true);
    }

    public static HttpProxyCacheServer getProxy(Context context) {
        VideoBoxApplication app = (VideoBoxApplication) context.getApplicationContext();
        return app.proxy == null ? (app.proxy = app.newProxy()) : app.proxy;
    }

    private HttpProxyCacheServer newProxy() {
        return new HttpProxyCacheServer.Builder(this)
            .cacheDirectory(Analytics.getVideoCacheDir(this))
            .build();
    }
}
