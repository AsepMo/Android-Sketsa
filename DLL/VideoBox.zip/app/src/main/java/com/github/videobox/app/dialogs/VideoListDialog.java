package com.github.videobox.app.dialogs;

import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.DialogFragment;
import android.content.Context;
import android.content.ContentResolver;
import android.database.Cursor;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.LinearLayout;

import org.json.JSONException;

import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

import com.github.videobox.widget.BannerLayout;

import com.github.videobox.R;
import com.github.videobox.app.dialogs.interfaces.OnItemClickListener;
import com.github.videobox.app.dialogs.interfaces.OnItemLongClickListener;
import com.github.videobox.app.dialogs.interfaces.OnMenuItemClickListener;
import com.github.videobox.app.dialogs.interfaces.OnMenuItemLongClickListener;
import com.github.videobox.app.library.models.VideoData;
import com.github.videobox.app.library.utils.VideoPlayerUtils;
import com.github.videobox.app.library.adapters.VideoAdapter;
import com.github.videobox.app.player.VideoPlayer;
import com.github.videobox.widget.MrToast;

import static com.github.videobox.app.player.VideoPlayer.mPlaylist;

public class VideoListDialog extends DialogFragment {
    
    public static final String TAG = VideoListDialog.class.getSimpleName();
    
    private static VideoPlayer mVideoPlayer;
    private VideoData mVideoData;
    public static VideoListDialog newInstance(VideoPlayer mPlayer) {
        VideoListDialog fragment = new VideoListDialog();
        mVideoPlayer = mPlayer;
        return fragment;
    }
    
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setStyle(STYLE_NO_FRAME, R.style.MenuFragmentStyle);
    }
    
    @SuppressLint("NewApi")
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.video_library, container, false);
        
        initViews(rootView);
        //getDialog().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND);
       
        return rootView;
    }
    
    private void initViews(View view) {
        RecyclerView  recyclerView = (RecyclerView) view.findViewById(R.id.video_list);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        
        mVideoData = new VideoData(getActivity(), VideoData.FILENAME);
        mPlaylist = getLocallyStoredData();
        VideoAdapter  adapter = new VideoAdapter(getActivity(), mPlaylist);
        recyclerView.setAdapter(adapter);
        adapter.setOnItemClickListener(new VideoAdapter.OnItemClickListener() {
                @Override
                public void onItemClick(int pos, View v) {
                    VideoData video = mPlaylist.get(pos);
                    mVideoPlayer.setPlaylist(mPlaylist, pos);
                    MrToast.showToast(getActivity(), video.getVideoThumbnail(), "Video OnPlaying!", video.getVideoTitle());             
                    dismiss();
                }
            });
    }
 
    public ArrayList<VideoData> getLocallyStoredData()
    {
        ArrayList<VideoData> items = null;
        try
        {
            items = mVideoData.loadFromFile();
        }
        catch (IOException | JSONException e)
        {
            e.printStackTrace();
        }

        if (items == null)
        {
            items = new ArrayList<>();
        }
        return items;
    }
}
