package com.github.videobox;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.media.MediaPlayer.OnPreparedListener;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.VideoView;

import com.github.videobox.app.common.Api;
import com.github.videobox.app.common.Direction;
import com.github.videobox.app.common.SystemBarTintManager;
import com.github.videobox.app.common.MagicActivity;
import com.github.videobox.app.updater.VortexAnimUpdater;
import com.gplibs.magicsurfaceview.MagicUpdater;
import com.gplibs.magicsurfaceview.MagicUpdaterListener;

public class LoadingActivity extends MagicActivity {
    
    public static String TAG = LoadingActivity.class.getSimpleName();
     //private MagicSurfaceView mSurfaceView;
    private VideoView mVideoView;
    private int position = 0;
    
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        //int color = Api.getStatusBarColor(SettingsActivity.getPrimaryColor(this));
        if (Api.hasLollipop())
        {
            getWindow().setStatusBarColor(R.color.colorPrimaryDark);
        }
        else if (Api.hasKitKat())
        {
            SystemBarTintManager systemBarTintManager = new SystemBarTintManager(this);
            systemBarTintManager.setTintColor(Api.getStatusBarColor(getColor(R.color.colorPrimaryDark)));
            systemBarTintManager.setStatusBarTintEnabled(true);
        }
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
     
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_loading);
        //setTitle("VideoBox");
        hidePageTitleBar();
        mVideoView = (VideoView)findViewById(R.id.video_loading);
        mVideoView.setVideoPath("android.resource://" + getPackageName() + "/" + R.raw.loading_sound_effects);
        mVideoView.requestFocus();
        mVideoView.setOnPreparedListener(new OnPreparedListener() {
                @Override
                public void onPrepared(MediaPlayer mp) {
                    mVideoView.seekTo(position);
                    if (position == 0) {
                        mVideoView.start();              
                    } else {
                        mVideoView.pause();
                    }
                }
            });
        mVideoView.setOnCompletionListener(new OnCompletionListener() {
                @Override
                public void onCompletion(MediaPlayer mp) {
                    mVideoView.pause();
                    /*if (isFirtsTime) {
                     mHandler.postDelayed(mFirstTimeRunner, 500); 
                     } else {
                     mHandler.postDelayed(mSecondTimeRunner, 500); 
                     }*/
                    Intent intent = new Intent(LoadingActivity.this, VideoBoxActivity.class);
                    startActivity(intent);

                    LoadingActivity.this.finish();                              
                }
            });       
    }

    
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        super.onSaveInstanceState(savedInstanceState);
        savedInstanceState.putInt("Position", mVideoView.getCurrentPosition());
        mVideoView.pause();
    }

    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        position = savedInstanceState.getInt("Position");
        mVideoView.seekTo(position);
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (mVideoView != null && mVideoView.isPlaying()) {
            mVideoView.pause();
        }     
    }

    @Override
    protected void onResume() {
        super.onResume();
        mVideoView.start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (mVideoView != null) {
            mVideoView.stopPlayback();
        }
    }
     
    // 设置Page转场动画
    @Override
    protected MagicUpdater getPageUpdater(boolean isHide) {
        return new VortexAnimUpdater(isHide);
    }

}
