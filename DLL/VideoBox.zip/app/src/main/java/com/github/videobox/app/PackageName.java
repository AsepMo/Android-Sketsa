package com.github.videobox.app;

public class PackageName {
    public static final String XTERMINAL = "jackpal.androidterm";
    
    public static final String FACEBOOK = "com.facebook.katana";
    public static final String FACEBOOK_MESSENGER = "com.facebook.orca";
    public static final String FACEBOOK_LITE = "com.facebook.lite";
    public static final String FACEBOOK_MENTIONS = "com.facebook.Mentions";
    public static final String FACEBOOK_GROUPS = "com.facebook.groups";
    public static final String FACEBOOK_PAGES_MANAGER = "com.facebook.pages.app";
    public static final String MSQRD = "me.msqrd.android";
    public static final String WHATSAPP = "com.whatsapp";
    public static final String VIBER = "com.viber.voip";
    public static final String TELEGRAM = "org.telegram.messenger";
    public static final String GOOGLE_SEARCH = "com.google.android.googlequicksearchbox";
    public static final String GOOGLE_CHROME = "com.android.chrome";
    public static final String GOOGLE_PLAY = "com.android.vending";
    public static final String GOOGLE_DRIVE = "com.google.android.apps.docs";
    public static final String GOOGLE_TRANSLATE = "com.google.android.apps.translate";
    public static final String GOOGLE_CALENDAR = "com.google.android.calendar";
    public static final String GOOGLE_GMAIL = "com.google.android.gm";
    public static final String GOOGLE_YOUTUBE = "com.google.android.youtube";
    public static final String GOOGLE_MAPS = "com.google.android.apps.maps";
    public static final String GOOGLE_DOCS = "com.google.android.apps.docs.editors.docs";
    public static final String GOOGLE_SHEETS = "com.google.android.apps.docs.editors.sheets";
    public static final String GOOGLE_BLOG = "com.google.android.gm";
    public static final String GOOGLE_HANGOUTS = "com.google.android.talk";
    public static final String GOOGLE_ALLO = "com.google.android.apps.fireball";
    public static final String CLEAN_MASTER = "com.cleanmaster.mguard";
    public static final String UBER = "com.ubercab";
    public static final String LYFT = "me.lyft.android";
    public static final String DUBSMASH = "com.mobilemotion.dubsmash";
    public static final String SNAPCHAT = "com.snapchat.android";
    public static final String NETFLIX = "com.netflix.mediaclient";
    public static final String QUORA = "com.quora.android";
    public static final String LINKEDIN = "com.linkedin.android";
    public static final String PINTEREST = "com.pinterest";
    public static final String TUMBLR = "com.tumblr";
}
