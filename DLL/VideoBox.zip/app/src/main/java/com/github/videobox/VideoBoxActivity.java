package com.github.videobox;

import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Bundle;
import android.os.Build;
import android.view.Window;
import android.view.WindowManager;
import java.io.File;

import com.github.videobox.app.common.Api;
import com.github.videobox.app.common.SystemBarTintManager;
import com.github.videobox.widget.soundPool.SoundPoolManager;

public class VideoBoxActivity extends ApplicationActivity {
    public static String TAG = VideoBoxActivity.class.getSimpleName();   
    

    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        //int color = Api.getStatusBarColor(SettingsActivity.getPrimaryColor(this));
        if (Api.hasLollipop()) {
            getWindow().setStatusBarColor(R.color.colorPrimaryDark);
        } else if (Api.hasKitKat()) {
            SystemBarTintManager systemBarTintManager = new SystemBarTintManager(this);
            systemBarTintManager.setTintColor(Api.getStatusBarColor(getColor(R.color.colorPrimaryDark)));
            systemBarTintManager.setStatusBarTintEnabled(true);
        }
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_video_box);

        prepareTabDrawer();
        showFragment(new VideoBoxFragment());
    } 
 
}
