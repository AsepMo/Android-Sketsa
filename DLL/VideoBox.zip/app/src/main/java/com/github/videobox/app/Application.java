package com.github.videobox.app;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Process;
import android.os.Environment;
import android.text.TextUtils;
import android.widget.Toast;

import java.io.File;

import com.github.videobox.R;
import com.github.videobox.VideoBoxActivity;
import com.github.videobox.widget.MrToast;

public class Application
{
    public static String TAG = Application.class.getSimpleName();
    
    private static Application mInstance;
    
    public static void initDefault(Application engine)
    {
        mInstance = engine;
    }

    public static Application get()
    {
        if (mInstance == null)
        {
            mInstance = new Application(new Builder(getApplicationContext()));
        }
        return mInstance;
    }

    private final String mApplication;

    private final boolean isApplication;
    public static Context getApplicationContext()
    {
        return getApplicationContext();
    }

    protected Application(Builder builder)
    {
        mApplication = builder.mApplication;
        isApplication = builder.isApplication;
    }

    public String getApplication()
    {
        return mApplication;
    }

    public boolean isApplication()
    {
        return isApplication;
    }

    public static void startActivity(Context c, Class<?> mClass)
    {
        Intent mApplication = new Intent(c, mClass);
        c.startActivity(mApplication);
    }
    
    public static void stopActivity(Context c, Class<?> mClass)
    {
        new MrToast(c).sendShortMessage(mClass + " " + "Stop Process");
        Process.killProcess(Process.myPid());
    }
    
    public static void startService(Context c, Class<?> mClass)
    {
        Intent mApplication = new Intent(c, mClass);
        c.startService(mApplication);
    }
    
    public static void stopService(Context c, Class<?> mClass)
    {
        Intent mApplication = new Intent(c, mClass);
        c.stopService(mApplication);
    }
    
    public static void setNotification(final Context c, final String title, final String playlistId)
    {
        NotificationManager manager = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        Intent i = new Intent(c, VideoBoxActivity.class);
        //Intent deleteIntent = new Intent(c, VideoBoxActivity.class);
        //deleteIntent.setAction(VideoStarterActivity.ACTION_ADD_PLAYLIST);
        //deleteIntent.putExtra(VideoStarterActivity.ADD_PLAYLIST, playlistId);
        Notification notification = new Notification.Builder(c)
                .setContentTitle(title)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setAutoCancel(false)
                .setDefaults(Notification.DEFAULT_SOUND)
                //.setDeleteIntent(PendingIntent.getService(c, 0, deleteIntent, PendingIntent.FLAG_UPDATE_CURRENT))
                .setContentIntent(PendingIntent.getActivity(c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT))
                .build();

        manager.notify(100, notification);

    }

    public static class Builder
    {
        private boolean isApplication = false;

        private String mApplication = null;
        
        private Context mContext;

        public Builder(Context context){
            this.mContext = context;
        }

        public Application build()
        {
            this.isApplication = !TextUtils.isEmpty(mApplication);
            return new Application(this);
        }
    }
}

