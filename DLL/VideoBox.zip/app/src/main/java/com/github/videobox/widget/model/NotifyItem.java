package com.github.videobox.widget.model;

public class NotifyItem {
    
    private String contentTitle;
    public void setContentTitle(String contentTitle){
        this.contentTitle = contentTitle;
    }
}
