package com.github.videobox.app.updater.listeners;

import org.json.JSONObject;
import com.github.videobox.app.updater.models.UpdateModel;

public interface UpdateListener {
    void onJsonDataReceived(UpdateModel updateModel, JSONObject jsonObject);
    void onError(String error);
}

