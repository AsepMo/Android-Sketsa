package com.github.videobox.app.folders.listeners;

public interface onUpdatePathListener {
    void onUpdatePath(String path);
}

