package com.github.videobox.app.library;

public final class Constants {

    public static final String PROCESS_BROADCAST_ACTION = "com.github.videobox.process.BROADCAST";
    public static final String PROCESS_STATUS_KEY = "com.github.videobox.process.STATUS_KEY";
    public static final String PROCESS_STATUS_MESSAGE = "comgithub.videobox.process.STATUS_MESSAGE";
    public static final String PROCESS_DIR = "com.github.videobox.process.DIR";
    public static final String PROCESS_VIDEO_PATH = "com.github.videobox.process.VIDEO_PATH";
    public static final int PROCESS_NOTIFICATION_ID = 1;

    public final static String ACTION_VIDEO_HOME = "com.github.folders.action.VIDEO_HOME";
    public final static String ACTION_VIDEO_LIBRARY = "com.github.folders.action.VIDEO_LIBRARY";
    public final static String ACTION_VIDEO_STARTER = "com.github.folders.action.VIDEO_STARTER";

    public interface ACTION {
        String START_PROCESS = "com.github.videobox.process.action.START";
        String STOP_PROCESS = "com.github.videobox.process.action.STOP";
    }

}
