package com.github.videobox.app.library.fragments;

import android.support.v4.app.Fragment;
import android.support.annotation.IdRes;
import android.view.MotionEvent;
import android.view.View;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import android.os.Bundle;

import com.github.videobox.R;
import com.github.videobox.app.library.VideoBanner;
import com.github.videobox.app.library.tasks.VideoBannerTask;

public class VideoBannerFragment extends Fragment {
    
    public static String TAG = VideoBannerFragment.class.getSimpleName();
    private VideoBanner mVideoBanner;
    
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_video_banner, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mVideoBanner = (VideoBanner)view.findViewById(R.id.video_box);
        VideoBannerTask mVideoBannerTask = new VideoBannerTask(getActivity(), mVideoBanner);
        
        mVideoBannerTask.execute();
    }
    
}
