package com.github.videobox;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class TransTvActivity extends AppCompatActivity {


    private String TRANSTV = "https://video.detik.com/transtv/smil:transtv.smil/playlist.m3u8";
    private String TRANS7 = "https://video.detik.com/trans7/smil:trans7.smil/playlist.m3u8";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("TransTv")
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item){
                    Intent Trans = new Intent(TransTvActivity.this, ChannelTvActivity.class);
                    Trans.putExtra(ChannelTvActivity.CHANNEL_URL, TRANSTV);
                    startActivity(Trans);
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        return super.onCreateOptionsMenu(menu);
    }
    
}
