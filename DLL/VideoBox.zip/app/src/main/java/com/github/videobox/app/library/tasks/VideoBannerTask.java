package com.github.videobox.app.library.tasks;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.provider.MediaStore;
import android.net.Uri;
import android.os.AsyncTask;
import android.util.Log;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.text.SimpleDateFormat;

import com.github.videobox.R;
import com.github.videobox.VideoViewerActivity;
import com.github.videobox.app.library.VideoBanner;
import com.github.videobox.app.library.models.VideoModel;
import com.github.videobox.app.library.adapters.VideoBannerAdapter;
import com.github.videobox.widget.BannerLayout;

public class VideoBannerTask extends AsyncTask<Void, Void, ArrayList<VideoModel>> {

    private Context mContext;
    //private BannerLayout mVideoBannerLayout;
    private VideoBanner mVideoBanner;
    private OnVideoBannerClickListener onVideoBannerClickListener;
    private ArrayList<VideoModel> videoList;
    public interface OnVideoBannerClickListener {
        void OnVideoBannerClick(int position);
    }
    private String mHandle;
    private static final int REQUEST_WINDOW_HANDLE = 1;

    /** Called when the activity is first created. */
    public VideoBannerTask(Context context, VideoBanner mVideoBanner) {
        this.mContext = context;   
        this.mVideoBanner = mVideoBanner;    
    }  

    @Override
    protected void onPreExecute() {
        super.onPreExecute(); 
        mVideoBanner.setStatus(com.github.videobox.app.library.Status.LOADING);
    }

    @Override
    protected ArrayList<VideoModel> doInBackground(Void[] params) {
        videoList = new ArrayList<VideoModel>();
        Uri uri;
        Cursor mCursor;
        String absolutePathOfFile = null;
        int count = 0;
        uri = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;

        String[] projection = {MediaStore.MediaColumns.DATA, MediaStore.Video.Media.BUCKET_DISPLAY_NAME, MediaStore.Video.Media._ID, MediaStore.Video.Thumbnails.DATA};

        final String orderBy = MediaStore.Images.Media.DATE_TAKEN;
        mCursor = mContext.getApplicationContext().getContentResolver().query(uri, projection, null, null, orderBy + " DESC");
        int COLUMN_ID = mCursor.getColumnIndexOrThrow(MediaStore.Video.Media._ID);
        int COLUMN_INDEX_NAME = mCursor.getColumnIndexOrThrow(MediaStore.Video.Media.BUCKET_DISPLAY_NAME);
        int COLUMN_INDEX_PATH = mCursor.getColumnIndexOrThrow(MediaStore.MediaColumns.DATA);
        int COLUMN_INDEX_THUMBNAIL = mCursor.getColumnIndexOrThrow(MediaStore.Video.Thumbnails.DATA);
        int COLUMN_INDEX_DURATION = mCursor.getColumnIndexOrThrow(MediaStore.Video.Thumbnails.DATA);

        while (mCursor.moveToNext()) {
            absolutePathOfFile = mCursor.getString(COLUMN_INDEX_PATH);
            Log.e("Column", absolutePathOfFile);
            Log.e("Folder", mCursor.getString(COLUMN_INDEX_NAME));
            Log.e("column_id", mCursor.getString(COLUMN_ID));
            Log.e("thum", mCursor.getString(COLUMN_INDEX_THUMBNAIL));

            VideoModel videoData = new VideoModel();
            videoData.setSelected(false);
            videoData.setVideoTitle(mCursor.getString(COLUMN_INDEX_NAME));    
            videoData.setVideoPath(absolutePathOfFile);
            videoData.setVideoThumb(mCursor.getString(COLUMN_INDEX_THUMBNAIL));
            
            videoList.add(videoData);

        }
        return videoList;
    }

    @Override
    protected void onPostExecute(final ArrayList<VideoModel> result) {
        super.onPostExecute(result);
        if (result.size() < 1) {
            mVideoBanner.setStatus(com.github.videobox.app.library.Status.ERROR);
        } else {
            VideoBannerAdapter webBannerAdapter=new VideoBannerAdapter(mContext, result);
            webBannerAdapter.setOnBannerItemClickListener(new BannerLayout.OnBannerItemClickListener() {
                    @Override
                    public void onItemClick(int position) {
                        /*if (onVideoBannerClickListener != null) {
                            onVideoBannerClickListener.OnVideoBannerClick(position);
                        }*/
                        VideoModel video = result.get(position);
                        VideoViewerActivity.startVideoViewer(mContext, video.getVideoPath());
                        /*Intent intent = new Intent("com.github.video.player.RUN_SCRIPT");
                        intent.addCategory(Intent.CATEGORY_DEFAULT);
                        intent.putExtra("com.github.video.player.iInitialCommand", video.getVideoPath());
                        mContext.startActivity(intent);*/
                       // Toast.makeText(mContext, video.getVideoPath(),Toast.LENGTH_SHORT).show();
                    }
                });
            mVideoBanner.setStatus(com.github.videobox.app.library.Status.COMPLETE);
            mVideoBanner.setAdapter(webBannerAdapter);  

        }
    }

    public void setOnVideoBannerClickListener(OnVideoBannerClickListener onVideoBannerClickListener) {
        this.onVideoBannerClickListener = onVideoBannerClickListener;
    }
}
