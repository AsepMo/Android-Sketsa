package com.github.videobox.app.library;

public enum Status {
    IDLE, LOADING, ERROR, COMPLETE
}
