package com.github.videobox.widget;

import android.support.v4.app.NotificationCompat;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Calendar;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import com.github.videobox.R;
import com.github.videobox.VideoBoxActivity;
import com.github.videobox.VideoPlayerActivity;
import com.github.videobox.VideoBannerActivity;

public class MrToast {

    private Context mContext;
    private Toast mToast;
    private OnErrorListener mOnErrorListener;
    private static final int NOTIFICATION = 1;

    public MrToast(Context context) {
        mContext = context;
    }

    public void sendShortMessage(String message) {
        if (mToast != null) {
            mToast.cancel();
        }

        mToast = Toast.makeText(mContext, message, Toast.LENGTH_SHORT);
        mToast.show();
    }

    public void sendLongMessage(String message) {
        if (mToast != null) {
            mToast.cancel();
        }

        mToast = Toast.makeText(mContext, message, Toast.LENGTH_LONG);
        mToast.show();
    }
    
    public static void showToast(Context context, int resId) {
        Toast.makeText(context, context.getResources().getString(resId), Toast.LENGTH_SHORT).show();
    }

    public static void showToast(Activity context, int resourcesId, String title, String description) {
        final Toast toast = new Toast(context);
        toast.setDuration(Toast.LENGTH_LONG);
        View custom_view = context.getLayoutInflater().inflate(R.layout.video_player_toast_layout, null);
        ImageView icon = (ImageView)custom_view.findViewById(R.id.toast_icon);
        icon.setImageResource(resourcesId);
        TextView mTitle = (TextView)custom_view.findViewById(R.id.toast_title);
        mTitle.setText(title);
        TextView mDescription = (TextView)custom_view.findViewById(R.id.toast_description);
        mDescription.setText(description);
        toast.setView(custom_view);
        toast.show();
    }

    public static void showToast(Activity context, String resourcesId, String title, String description) {
        final Toast toast = new Toast(context);
        toast.setDuration(Toast.LENGTH_LONG);
        View custom_view = context.getLayoutInflater().inflate(R.layout.video_player_toast_layout, null);
        ImageView icon = (ImageView)custom_view.findViewById(R.id.toast_icon);
        
         Glide.with(context)
            .load(resourcesId)
            .apply(new RequestOptions().placeholder(R.drawable.video_placeholder).error(R.drawable.video_placeholder))
            .into(icon);   
        TextView mTitle = (TextView)custom_view.findViewById(R.id.toast_title);
        mTitle.setText(title);
        TextView mDescription = (TextView)custom_view.findViewById(R.id.toast_description);
        mDescription.setText(description);
        toast.setView(custom_view);
        toast.show();
    }
    
    public static void showToast(Activity context, Bitmap resourcesId, String title, String description) {
        final Toast toast = new Toast(context);
        toast.setDuration(Toast.LENGTH_LONG);
        View custom_view = context.getLayoutInflater().inflate(R.layout.video_player_toast_layout, null);
        ImageView icon = (ImageView)custom_view.findViewById(R.id.toast_icon);
        icon.setImageBitmap(resourcesId);
        icon.setImageAlpha(0);
        TextView mTitle = (TextView)custom_view.findViewById(R.id.toast_title);
        mTitle.setText(title);
        TextView mDescription = (TextView)custom_view.findViewById(R.id.toast_description);
        mDescription.setText(description);
        toast.setView(custom_view);
        toast.show();
    }
    
    public void showErrorDialog(String msg, OnErrorListener mOnErrorListener) {
        AlertDialog.Builder builder = buildErrorDialog(msg, mOnErrorListener);
        AlertDialog alert = builder.create();
        alert.show();
	}
    
    private AlertDialog.Builder buildErrorDialog(final String msg, final OnErrorListener mOnErrorListener) {
        return new AlertDialog.Builder(mContext).setMessage(msg).setCancelable(true)
            .setNeutralButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int id) {
                    if(mOnErrorListener != null){
                        mOnErrorListener.forceExit();
                    }
                }
            });
	}
    
    /**
     * Show a notification while this service is running.
     */
    @SuppressWarnings("deprecation")
    public static void showNotification(Context pContext, String pBroadcastAction) {
        // TODO use Notification.Builder
        Notification.Builder notification = new Notification.Builder(pContext);
        notification.setSmallIcon(R.mipmap.ic_launcher);
        notification.setTicker(pBroadcastAction);
        notification.setWhen(System.currentTimeMillis());

        // The PendingIntent to launch our activity if the user selects this notification
        PendingIntent contentIntent = PendingIntent.getActivity(pContext, 0, new Intent(pContext, VideoBoxActivity.class), 0);


        // Set the info for the views that show in the notification panel.
        notification.setContentTitle(pContext.getText(R.string.notification_title));
        notification.setContentText(pBroadcastAction);
        notification.setContentIntent(contentIntent);
        notification.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
        Notification notif = notification.build();
        // Send the notification.
        ((NotificationManager)pContext.getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTIFICATION, notif);
    }
    
    @SuppressWarnings("deprecation")
    public static void showNotification(Context pContext, int resourcesId, String notifTitle, String notifMessage) {
        // TODO use Notification.Builder
        Notification.Builder notification = new Notification.Builder(pContext);
        notification.setSmallIcon(resourcesId);
        notification.setTicker(notifMessage);
        notification.setWhen(System.currentTimeMillis());

        // The PendingIntent to launch our activity if the user selects this notification
        PendingIntent contentIntent = PendingIntent.getActivity(pContext, 0, new Intent(pContext, VideoBoxActivity.class), 0);


        // Set the info for the views that show in the notification panel.
        notification.setContentTitle(notifTitle);
        notification.setContentText(notifMessage);
        notification.setContentIntent(contentIntent);
        notification.setDefaults(Notification.DEFAULT_SOUND | Notification.DEFAULT_VIBRATE);
        Notification notif = notification.build();
        // Send the notification.
        ((NotificationManager)pContext.getSystemService(Context.NOTIFICATION_SERVICE)).notify(NOTIFICATION, notif);

    }
    
    @SuppressWarnings("deprecation")
    public static void showNotification(Context pContext) {
    // TODO use Notification.Builder
        // Assign big picture notification
        //Notification.BigPictureStyle bigPictureStyle = new Notification.BigPictureStyle();
        //bigPictureStyle.bigPicture(BitmapFactory.decodeFile(resId));

        // Gets an instance of the NotificationManager service
        NotificationManager notificationManager =(NotificationManager) pContext.getSystemService(Context.NOTIFICATION_SERVICE);

        
        //set intents and pending intents to call activity on click of "show activity" action button of notification
        Intent resultIntent = new Intent(pContext, VideoPlayerActivity.class);
        Intent videoBanner = new Intent(pContext, VideoBannerActivity.class);
        
        Notification.Builder builder = new Notification.Builder(pContext)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle("VideoBox")
            .setContentText("This is video library..")
            //.setStyle(bigPictureStyle)
            .setAutoCancel(false)
            .addAction(R.drawable.ic_video_player, "Player", PendingIntent.getActivity(pContext, 0, resultIntent, 0, null))
            .addAction(R.drawable.ic_image, "Poster", PendingIntent.getActivity(pContext, 0, videoBanner, 0, null))
            .setPriority(Notification.PRIORITY_DEFAULT);
        //to post your notification to the notification bar
        notificationManager.notify(0, builder.build());
        
    }
    
    public static void hideNotification(Context pContext) {
        ((NotificationManager)pContext.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(NOTIFICATION);
    }
    
    public void setOnErrorListener(OnErrorListener mOnErrorListener){
        this.mOnErrorListener = mOnErrorListener;
    }
    
    public interface OnErrorListener
    {
        void forceExit();
    }
}

