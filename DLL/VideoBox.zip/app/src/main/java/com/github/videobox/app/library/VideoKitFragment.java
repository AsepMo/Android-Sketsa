package com.github.videobox.app.library;

import android.animation.ValueAnimator;
import android.support.v4.app.Fragment;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

import com.github.videobox.R;
import com.github.videobox.app.dialogs.OptionsMenu;
import com.github.videobox.app.dialogs.interfaces.OnMenuItemClickListener;
import com.github.videobox.app.dialogs.interfaces.OnMenuItemLongClickListener;
import com.github.videobox.app.dialogs.animations.MenuParams;
import com.github.videobox.app.dialogs.models.MenuObject;
import com.github.videobox.app.dialogs.VideoListDialog;
import com.github.videobox.app.library.models.VideoData;
import com.github.videobox.app.library.adapters.VideoAdapter;
import com.github.videobox.app.library.utils.VideoPlayerUtils;
import com.github.videobox.app.player.VideoPlayer;
import com.github.videobox.app.player.VideoPlayer.OnVideoPlayerListener;
import com.github.videobox.widget.MrToast;
import com.github.videobox.VideoFolderActivity;
import com.github.videobox.VideoPlayerActivity;
import com.github.videobox.VideoEditorActivity;

import static com.github.videobox.app.library.fragments.VideoLibraryFragment.videoArrayList;

public class VideoKitFragment extends Fragment implements OnVideoPlayerListener {
    

    private static final int MINIFY_WIDTH = 132;
    private int CONSOLE_HEIGHT = 110;
    private int CONSOLE_WIDTH = 250;
    
    private View mRootView;

    private LayoutInflater mInflater;
    private VideoPlayer mConsole;
    private VideoPlayerUtils mVideoPlayerUtils;
    private VideoListDialog mVideoLibraryDialog;
    private VideoData mVideoData;   
    private FrameLayout mConsoleContainer;

    private View mPanel;
    private View mMinifyButton;

    private float dX;
    private float dY;

    private float startX = 0;
    private float startY = 0;

    public static String VIDEO_INDEX= "video_index";
    private final int VIDEO_INFO = 1;
    private final int VIDEO_PLAYER = 2;
    private final int VIDEO_FOLDER = 3;
    private final int VIDEO_RECORDER = 4;
    private final int VIDEO_MORE = 5;

    private final int VIDEO_MOVIE = 1;
    private final int VIDEO_3D = 2;
    private final int VIDEO_EDITOR = 3;
    private final int VIDEO_SHARE= 4;
    private final int VIDEO_MANAGE = 5;
    private Handler mHandler;
    private Runnable mRunner = new Runnable(){
        @Override
        public void run() {
            onMoreMenu();
        }
    };
    
    public static void setVideoPath(String index) {
        /*VideoKitFragment fragment = new VideoKitFragment();
        Bundle args = new Bundle();
        args.putString(VIDEO_INDEX, index);
        fragment.setArguments(args);
        return fragment;*/
        VIDEO_INDEX = index;
    }
    

    public void displayAt(float x, float y) {
        this.startX = x;
        this.startY = y;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mInflater = inflater;
        mRootView = inflater.inflate(R.layout.videokit_fragment_dev_tools, container, false);
        return mRootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        //LinearLayout mButtonContainer = (LinearLayout) mRootView.findViewById(R.id.debugkit_button_container);
        //String video_index = getArguments().getString(VIDEO_INDEX); 
        mConsole = (VideoPlayer) mRootView.findViewById(R.id.debugkit_console);
        // mConsole.setVideoPath("android.resource://" + getActivity().getPackageName() + "/" + R.raw.videokit);
        mConsole.setVideoPath(VIDEO_INDEX);
        mConsole.setOnVideoPlayerListener(this);
        mVideoPlayerUtils =  new VideoPlayerUtils(getActivity());
        
        mConsoleContainer = (FrameLayout) mRootView.findViewById(R.id.debugkit_console_scroll_view);
        mMinifyButton = mRootView.findViewById(R.id.debugkit_tools_minify);
        mPanel = mRootView.findViewById(R.id.debugkit_tools_panel);
        mRootView.findViewById(R.id.debugkit_tools_close_button).setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (isAdded()) {
                        try {
                            getActivity().getSupportFragmentManager()
                                .beginTransaction()
                                .remove(VideoKitFragment.this)
                                .commit();
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }
            });

        mRootView.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    return VideoKitFragment.this.onTouch(v, event);
                }
            });


        ViewGroup.LayoutParams layoutParams = mConsoleContainer.getLayoutParams();
        layoutParams.height = dpTopX(CONSOLE_HEIGHT);
        mConsoleContainer.setLayoutParams(layoutParams);

        layoutParams = mConsole.getLayoutParams();
        layoutParams.height = dpTopX(CONSOLE_HEIGHT);
        layoutParams.width = dpTopX(CONSOLE_WIDTH);
        mConsole.setLayoutParams(layoutParams);
        mConsole.setMinimumHeight(dpTopX(CONSOLE_HEIGHT));

        view.setX(startX);
        view.setY(startY);

        mMinifyButton.setTag(mMinifyButton.getId(), false);
        mMinifyButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    switchMinify();
                }
            });   
    }
    
    @Override
    public void onNavigationIconClick(View v) {
        getActivity().finish();
    }

    @Override
    public void onVideoPlaying(VideoPlayer mMediaPlayer, String title, String thumbnail, String path) {

    }

    @Override
    public void onVideoPlaylist(View v) {
        
    }

    @Override
    public void onVideoComplete(VideoPlayer mVP) {
        mVP.pauseVideo();
    }

    @Override
    public void onVideoOrientation(View v) {
        //mPlayer.getScreenOrientation(getActivity());
    }

    @Override
    public void onVideoConnection(View v) {
    }

    @Override
    public void onVideoMenu(View v) {
        mVideoPlayerUtils.setMenuFragment(getActivity(), VideoPlayerUtils.getOptionsMenu());
        mVideoPlayerUtils.setOnItemClickListener(new VideoPlayerUtils.OnItemClickListener(){
                @Override
                public void onItemClick(View clickedView, int position) {
                    switch (position) {
                        case VIDEO_INFO:
                            break;
                        case VIDEO_PLAYER:

                            break;  
                        case VIDEO_FOLDER:
                            VideoPlayerUtils.setActivity(getActivity(), VideoFolderActivity.class);
                            break; 
                        case VIDEO_RECORDER:
                            break; 
                        case VIDEO_MORE:
                            mHandler = new Handler();
                            mHandler.postDelayed(mRunner, 100);
                            break;    
                    }
                    Toast.makeText(getActivity(), "Clicked on position: " + position, Toast.LENGTH_SHORT).show();
                }
            });
        mVideoPlayerUtils.setOnItemLongClickListener(new VideoPlayerUtils.OnItemLongClickListener(){
                @Override
                public void onItemLongClick(View clickedView, int position) {
                    Toast.makeText(getActivity(), "Clicked on position: " + position, Toast.LENGTH_SHORT).show();
                }
            });
    }

    @Override
    public void onVideoError(VideoPlayer player, Exception e) {
    }

    
    public void onMoreMenu() {

        mVideoPlayerUtils.setMenuFragment(getActivity(), VideoPlayerUtils.getMoreMenu());
        mVideoPlayerUtils.setOnItemClickListener(new VideoPlayerUtils.OnItemClickListener(){
                @Override
                public void onItemClick(View clickedView, int position) {
                    switch (position) {
                        case VIDEO_MOVIE:
                            break;
                        case VIDEO_3D:
                            break;  
                        case VIDEO_EDITOR:
                            VideoEditorActivity.startVideoEditor(getActivity());
                            break; 
                        case VIDEO_SHARE:
                            break; 
                        case VIDEO_MANAGE:
                            break;    
                    }
                    Toast.makeText(getActivity(), "Clicked on position: " + position, Toast.LENGTH_SHORT).show();
                }
            });
        mVideoPlayerUtils.setOnItemLongClickListener(new VideoPlayerUtils.OnItemLongClickListener(){
                @Override
                public void onItemLongClick(View clickedView, int position) {
                    Toast.makeText(getActivity(), "Clicked on position: " + position, Toast.LENGTH_SHORT).show();
                }
            });
    }
    /**
     * Switch the tool to minify mode.
     */
    private void switchMinify() {

        RotateAnimation rotateAnimation;
        ValueAnimator heightValueAnimator;
        ValueAnimator widthValueAnimator;

        if ((boolean) mMinifyButton.getTag(mMinifyButton.getId())) {
            rotateAnimation = new RotateAnimation(180, 0, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
            heightValueAnimator = ValueAnimator.ofInt(0, dpTopX(CONSOLE_HEIGHT));
            widthValueAnimator = ValueAnimator.ofInt(dpTopX(MINIFY_WIDTH), dpTopX(CONSOLE_WIDTH));
            mMinifyButton.setTag(mMinifyButton.getId(), false);
        } else {
            rotateAnimation = new RotateAnimation(0, 180, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
            heightValueAnimator = ValueAnimator.ofInt(dpTopX(CONSOLE_HEIGHT), 0);
            widthValueAnimator = ValueAnimator.ofInt(dpTopX(CONSOLE_WIDTH), dpTopX(MINIFY_WIDTH));
            mMinifyButton.setTag(mMinifyButton.getId(), true);
        }

        heightValueAnimator.setDuration(200);
        heightValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator animation) {
                    Integer value = (Integer) animation.getAnimatedValue();
                    mConsoleContainer.getLayoutParams().height = value.intValue();
                    mConsoleContainer.requestLayout();
                }
            });
        widthValueAnimator.setDuration(200);
        widthValueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                public void onAnimationUpdate(ValueAnimator animation) {
                    Integer value = (Integer) animation.getAnimatedValue();
                    mConsole.getLayoutParams().width = value.intValue();
                    mConsole.requestLayout();
                }
            });

        rotateAnimation.setDuration(200);
        rotateAnimation.setFillAfter(true);
        mMinifyButton.startAnimation(rotateAnimation);
        heightValueAnimator.setInterpolator(new AccelerateInterpolator());
        heightValueAnimator.start();
        widthValueAnimator.setInterpolator(new AccelerateInterpolator());
        widthValueAnimator.start();
    }


    private boolean onTouch(View v, MotionEvent event) {

        switch (event.getAction()) {

            case MotionEvent.ACTION_DOWN:
                dX = v.getX() - event.getRawX();
                dY = v.getY() - event.getRawY();
                break;
            case MotionEvent.ACTION_MOVE:
                v.setX(event.getRawX() + dX);
                v.setY(event.getRawY() + dY);
                break;
            case MotionEvent.ACTION_UP:
                break;
            default:
                return false;
        }

        return true;
    }

    /**
     * Call this function at runtime if you want to clear the console.
     */
    public void clear() {    
        mConsole.pauseVideo();
    }

    private int dpTopX(int dp) {
        return Math.round(TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dp, getResources().getDisplayMetrics()));
    }

    private String getCurrentTime() {
        SimpleDateFormat df = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
        return df.format(Calendar.getInstance().getTime());
    }

    /**
     * Set the console height.
     *
     * @param consoleHeight represents the console height in dp.
     */
    public void setConsoleHeight(int consoleHeight) {
        this.CONSOLE_HEIGHT = consoleHeight;
    }

    /**
     * Set the console width.
     *
     * @param consoleWidth represents the console width in dp.
     */
    public void setConsoleWidth(int consoleWidth) {
        this.CONSOLE_WIDTH = consoleWidth;
    }

    /**
     * Enum, theme choices for the debug tool.
     */
    public enum DevToolTheme {
        DARK,
        LIGHT
        }
}
