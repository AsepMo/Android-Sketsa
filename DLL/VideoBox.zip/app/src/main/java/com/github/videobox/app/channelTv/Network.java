package com.github.videobox.app.channelTv;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;

import com.github.videobox.VideoBoxApplication;

public class Network {
    public static boolean IsConnected() {
        ConnectivityManager manager = (ConnectivityManager)VideoBoxApplication.getContext().getSystemService(Context.CONNECTIVITY_SERVICE);

        if (manager == null) return false;

        NetworkInfo network = manager.getActiveNetworkInfo();
        if (network == null) return false;

        return network.isConnected();
    }
}

