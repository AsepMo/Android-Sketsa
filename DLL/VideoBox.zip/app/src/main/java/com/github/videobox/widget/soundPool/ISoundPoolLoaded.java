package com.github.videobox.widget.soundPool;

public interface ISoundPoolLoaded {
    public void onSuccess();
}
