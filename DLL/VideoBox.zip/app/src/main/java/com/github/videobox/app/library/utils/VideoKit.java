package com.github.videobox.app.library.utils;

import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;

import java.util.ArrayList;
import java.util.List;

import com.github.videobox.app.library.VideoKitFragment;

public class VideoKit {

    public final static boolean devToolsEnabled = true;

    /**
     * Builder class for {@link DevToolFragment}
     */
    public static class Builder {

        private VideoKitFragment fragment;
        private FragmentActivity activity;

        private float startX = 0;
        private float starty = 0;

        /**
         * Constructor
         *
         * @param activity the activity the DevTool will be linked to.
         */
        public Builder(FragmentActivity activity) {
            fragment = new VideoKitFragment();
            this.activity = activity;
        }

        /**
         * Set the initial position of the debug tool. The tool is displayed (0,0) by default.
         * @param x
         * @param y
         * @return this to allow chaining.
         */
        public Builder displayAt(float x, float y) {
            this.startX = x;
            this.starty = y;
            return this;
        }

        /**
         * Build the tool and show it.
         *
         * @return this to allow chaining.
         */
        public Builder build() {
            if (devToolsEnabled) {
             
                fragment.displayAt(startX, starty);

                try {
                    FragmentManager fragmentManager = activity.getSupportFragmentManager();
                    fragmentManager.beginTransaction()
                        .add(android.R.id.content, fragment)
                        .commit();
                } catch (Exception exception) {
                    exception.printStackTrace();
                }

                
            }
            return this;
        }

        /**
         * Get the {@link DevToolFragment} instance created by the builder.
         */
        public VideoKitFragment getTool() {
            return fragment;
        }
    }
}
