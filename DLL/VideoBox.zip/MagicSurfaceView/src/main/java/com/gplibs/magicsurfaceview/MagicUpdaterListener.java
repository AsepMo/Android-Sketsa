package com.gplibs.magicsurfaceview;

public interface MagicUpdaterListener {
    void onStart();
    void onStop();
}
