package com.splash.project;

import android.app.Application;
import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import com.splash.project.engine.widget.soundPool.ISoundPoolLoaded;
import com.splash.project.engine.widget.soundPool.SoundPoolManager;

public class AppController extends Application {
    private static AppController isInstance;
    private static Context mContext;
    
    @Override
    public void onCreate() {
        super.onCreate();

        isInstance = this;
        mContext = this;
        
        SoundPool();
    }

    public static synchronized AppController getInstance() {
        return isInstance;
    }

    public static Context getContext() {
        return mContext;
    }

    public void SoundPool() {
        SoundPoolManager.CreateInstance();
        List<Integer> sounds = new ArrayList<Integer>();
        sounds.add(R.raw.sound1);
        sounds.add(R.raw.sound2);
        sounds.add(R.raw.add);
        sounds.add(R.raw.done);
        sounds.add(R.raw.error);
        SoundPoolManager.getInstance().setSounds(sounds);
        try {
            SoundPoolManager.getInstance().InitializeSoundPool(getApplicationContext(), new ISoundPoolLoaded() {
                    @Override
                    public void onSuccess() {

                    }
                });
        } catch (Exception e) {
            e.printStackTrace();
        }

        SoundPoolManager.getInstance().setPlaySound(true);
    }
}
