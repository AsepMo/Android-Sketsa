package com.server.client.service;

import android.app.Service;
import android.content.Intent;
import android.content.Context;
import android.os.IBinder;
import android.os.Build;
import android.os.Handler;
import android.os.StrictMode;
import android.util.Log;
import org.json.JSONObject;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

import com.server.client.engine.app.server.Server;
import com.server.client.engine.app.utils.ConnectionUtils;

public class ServerService extends Service {

    public static String TAG = ServerService.class.getSimpleName();

    public static final String EXTRA_PLAYLIST = "EXTRA_PLAYLIST";
    public static final String EXTRA_SHUFFLE = "EXTRA_SHUFFLE";
    private static boolean isRunning = false;
    Thread socketThread;
    Handler serverHandler;
    Runnable serverRunnable;
    int server_port = 50008;
    public static void startServer(Context c) {
        Intent i=new Intent(c, ServerService.class);
        i.putExtra(ServerService.EXTRA_PLAYLIST, "main");
        i.putExtra(ServerService.EXTRA_SHUFFLE, true);
        c.startService(i);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String playlist = intent.getStringExtra(EXTRA_PLAYLIST);
        boolean useShuffle = intent.getBooleanExtra(EXTRA_SHUFFLE, false);

        play(playlist, useShuffle);     

        return(START_NOT_STICKY);
    }

    @Override
    public void onDestroy() {
        stop();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return(null);
    }

    public static boolean isRunning() {
        return isRunning;
    }

    private void play(String playlist, boolean useShuffle) {
        if (!isRunning) {
            Log.w(getClass().getName(), "Got to play()!");
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
            
            Server server = Server.getInstance();
            server.init();

            serverHandler = new Handler();
            serverRunnable = new Runnable() {
                @Override
                public void run() {
                    try {
                        String ip_device = ConnectionUtils.getDeviceIp(getApplicationContext());
                        String ip_broadcast = ConnectionUtils.getBroadcastAddress(getApplicationContext()).getHostAddress();

                        JSONObject message = new JSONObject();
                        message.put("broadcast_ip", ip_broadcast);
                        message.put("device_ip", ip_device);
                        message.put("device_name", getDeviceName());

                        Log.d("TAGTAG", "IP BROADCAST: " + ip_broadcast);
                        Log.d("TAGTAG", "MESSAGE BROADCAST: " + message.toString());

                        DatagramSocket socket = new DatagramSocket();
                        InetAddress local = InetAddress.getByName(ip_broadcast);

                        int msg_length = message.toString().length();
                        byte[] msg = message.toString().getBytes();

                        DatagramPacket packet = new DatagramPacket(msg, msg_length, local, server_port);
                        socket.send(packet);
                        Log.d("TAGTAG", "data send");
                    } catch (Exception e) {
                        Log.d("TAGTAG", "data failed to send");
                        Log.d("TAGTAG", Log.getStackTraceString(e));
                    }

                    serverHandler.postDelayed(serverRunnable, 5000);
                }
            };
            socketThread = new Thread(serverRunnable);
            socketThread.start();
            isRunning = true;
        }
    }

    private void stop() {
        if (isRunning) {
            Log.w(getClass().getName(), "Got to stop()!");
            serverHandler.removeCallbacks(serverRunnable);
            if(null != socketThread)
                socketThread.stop();
            isRunning = false;
        }
    }


    private String getDeviceName() {
        String manufacturer = Build.MANUFACTURER;
        String model = Build.MODEL;
        if (model.startsWith(manufacturer)) {
            return capitalize(model);
        } else {
            return capitalize(manufacturer) + " " + model;
        }
    }

    private String capitalize(String s) {
        if (s == null || s.length() == 0) {
            return "";
        }
        char first = s.charAt(0);
        if (Character.isUpperCase(first)) {
            return s;
        } else {
            return Character.toUpperCase(first) + s.substring(1);
        }
    }
}
