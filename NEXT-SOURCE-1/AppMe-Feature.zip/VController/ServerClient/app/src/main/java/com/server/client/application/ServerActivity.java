package com.server.client.application;

import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.os.Handler;

import com.server.client.R;
import com.server.client.engine.app.server.ChatServerFragment;
import com.server.client.service.ServerService;

public class ServerActivity extends AppCompatActivity {
    
    public static String TAG = ServerActivity.class.getSimpleName();
    public final static String ACTION_SERVER_MESSAGE = "com.server.client.application.SERVER_MESSAGE";
    public final static String ACTION_SERVER_CAMERA = "com.server.client.application.SERVER_CAMERA";
    public final static String ACTION_SERVER_SCREEN = "com.server.client.application.SERVER_SCREEN";
    public final static String ACTION_SERVER_WEB = "com.server.client.application.SERVER_WEB";
    public final static String ACTION_SERVER_CONTROLLER = "com.server.client.application.SERVER_CONTROLLER";
    
    public final static String EXTRA_TYPE = "EXTRA_TYPE";
    public final static String EXTRA_PATH = "EXTRA_PATH";
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_application);
        
        Toolbar mToolbar = (Toolbar)findViewById(R.id.toolbar);
        setSupportActionBar(mToolbar);
        String action = getIntent().getAction();
        String subTitle = "";
        if (action != null && action.equals(ACTION_SERVER_MESSAGE)) {

            subTitle = "Chat Server";
            switchFragment(ChatServerFragment.createFor("Server"));
        } else if (action != null && action.equals(ACTION_SERVER_CAMERA)) {

            subTitle = "Camera Server";
            ServerService.startServer(this);
        }
        mToolbar.setSubtitle(subTitle);
    }
    
    public void switchFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    } 
}
