package com.server.client.engine.app.fragments;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Process;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

import com.server.client.R;
import com.server.client.application.Application;
import com.server.client.engine.app.connections.Hotspot;
import com.server.client.engine.app.connections.HotspotListener;
import com.server.client.engine.app.connections.ConnectedDevice;
import com.server.client.engine.app.connections.ConnectionResult;
import com.server.client.engine.app.server.menu.ServerLayout;

public class ServerFragment extends Fragment {

    public static String TAG = ServerFragment.class.getSimpleName();
    
    private static final String EXTRA_TEXT = "text";
    private Context mContext;
    private ServerLayout mServerLayout;
    private Handler mHandler;
    private Runnable mRunner = new Runnable(){
        @Override
        public void run(){
            
        }
    };
    
    public static ServerFragment createFor(String text) {
        ServerFragment fragment = new ServerFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_app_server, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        
        final String text = getArguments().getString(EXTRA_TEXT);
        mContext = getActivity();
        mServerLayout = (ServerLayout)view.findViewById(R.id.sdcard_monitor);
        mHandler = new Handler();
        mHandler.postDelayed(mRunner,1200);
        Toast.makeText(mContext, text, Toast.LENGTH_SHORT).show();
    }
    
   /* @Override
    public void OnDevicesConnectedRetrieved(ArrayList<ConnectedDevice> clients) {

        if(clients != null){
            Toast.makeText(mContext, String.valueOf(clients.size()), Toast.LENGTH_SHORT).show();
 
        }         
    }

    @Override
    public void OnHotspotStartResult(ConnectionResult result) {

    }*/

    @Override
    public void onPause() {
        super.onPause();
        mHandler.removeCallbacks(mRunner);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacks(mRunner);
    }
    
}

