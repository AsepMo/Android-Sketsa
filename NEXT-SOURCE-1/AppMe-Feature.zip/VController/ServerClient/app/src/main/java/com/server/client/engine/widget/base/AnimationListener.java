package com.server.client.engine.widget.base;

/**
 * AnimationListener
 */

public interface AnimationListener {
    void onAnimationEnd(HTextView hTextView);
}
