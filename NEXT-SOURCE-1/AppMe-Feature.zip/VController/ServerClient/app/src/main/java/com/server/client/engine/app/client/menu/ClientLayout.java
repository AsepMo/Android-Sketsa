package com.server.client.engine.app.client.menu;

import android.annotation.TargetApi;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Toast;

import java.util.Calendar;

import com.server.client.R;
import com.server.client.application.ApplicationActivity;
import com.server.client.engine.app.server.menu.ServerElement;

public class ClientLayout extends RelativeLayout {

    public static String TAG = ClientLayout.class.getSimpleName();

    private Activity mActivity;
    private Context mContext;
    private LayoutInflater mInflater;
    private View mFrameLayout;
    private MenuClient mMenuMonitor;

    public ClientLayout(Context context) {
        super(context);
        init(context, null);
    }

    public ClientLayout(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(context, attrs);
    }

    public ClientLayout(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context, attrs);
    }


    private void init(Context context, AttributeSet attrs) {
        setBackgroundColor(R.color.windowBackground);

        mContext = context;
        mActivity = (Activity)context;
    }

    // View events

    @Override
    protected void onFinishInflate() {
        super.onFinishInflate();

        setKeepScreenOn(true);

        // Instantiate and add TextureView for rendering
        mInflater = LayoutInflater.from(getContext());
        mFrameLayout = mInflater.inflate(R.layout.layout_menu_client, this, false);
        addView(mFrameLayout); 

        //mStorageMonitor = (StorageMonitor)mFrameLayout.findViewById(R.id.storage_monitor);
        mMenuMonitor = (MenuClient)mFrameLayout.findViewById(R.id.menu_monitor);
        ServerElement adsElement = new ServerElement();
        adsElement.setTitle("Share Your File, Screen And Apps For Your Friends");

        mMenuMonitor.isRTL(false);
        mMenuMonitor.addItem(new ServerElement().setTitle("Menu :"));
        mMenuMonitor.addMessage("Message");
        mMenuMonitor.addCamera("Camera");
        mMenuMonitor.addScreen("Screen");
        mMenuMonitor.addWeb("Web Client");
        mMenuMonitor.addController("Controller");
        
        mMenuMonitor.addItem(adsElement);
        mMenuMonitor.addItem(getCopyRightsElement());
    }

    public ServerElement getCopyRightsElement() {
        ServerElement copyRightsElement = new ServerElement();
        final String copyrights = String.format(mContext.getString(R.string.copy_right), Calendar.getInstance().get(Calendar.YEAR));
        copyRightsElement.setTitle(copyrights);
        copyRightsElement.setIconDrawable(R.drawable.about_icon_copy_right);
        copyRightsElement.setIconTint(R.color.about_item_icon_color);
        copyRightsElement.setIconNightTint(android.R.color.white);
        copyRightsElement.setGravity(Gravity.CENTER);
        copyRightsElement.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(mContext, copyrights, Toast.LENGTH_SHORT).show();
                }
            });
        return copyRightsElement;
    }

    public void onPause(){
        //mStorageMonitor.onPause();
    }

    public void onDestroy(){
        //mStorageMonitor.onDestroy();
    }
}

