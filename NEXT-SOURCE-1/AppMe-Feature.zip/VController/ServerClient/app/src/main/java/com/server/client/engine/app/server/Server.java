package com.server.client.engine.app.server;

import android.content.Context;
import android.os.Handler;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import com.server.client.engine.app.config.Command;
import com.server.client.engine.app.connections.CommandListener;
import com.server.client.AppController;

public class Server {
    public static String TAG = Server.class.getSimpleName();
    
    private static Server isInstance;
    private ServerSocket serverSocket;
    private Handler responseRequestHandler;
    
    
    Thread serverThread = null;
    public static final int SERVER_PORT = 6000;

    public static Server getInstance() {
        if (isInstance == null) {
            isInstance = new Server();
        }
        return isInstance;
    }

    public Server() {
        responseRequestHandler = new Handler();
    }

    public void init() {
        serverThread = new Thread(new ServerThread());
        serverThread.start();
    }

    public void stop() {
        try {
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class ServerThread extends Thread {
        public void run() {
            Socket socket = null;
            try {
                serverSocket = new ServerSocket(SERVER_PORT);
            } catch (IOException e) {
                e.printStackTrace();
            }
            while (!Thread.currentThread().isInterrupted()) {

                try {

                    socket = serverSocket.accept();

                    CommunicationThread commThread = new CommunicationThread(socket);
                    new Thread(commThread).start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class CommunicationThread extends Thread {
        private Socket clientSocket;
        private BufferedReader input;

        public CommunicationThread(Socket clientSocket) {
            this.clientSocket = clientSocket;
            try {
                this.input = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run() {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    String read = input.readLine();
                    CommandListener.with(AppController.getContext()).onCommandListener(responseRequestHandler, read, clientSocket);
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    
}

