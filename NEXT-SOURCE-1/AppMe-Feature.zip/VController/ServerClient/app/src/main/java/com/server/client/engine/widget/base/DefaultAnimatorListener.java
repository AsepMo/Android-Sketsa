package com.server.client.engine.widget.base;

import android.animation.Animator;

/**
 *
 */

public class DefaultAnimatorListener implements Animator.AnimatorListener {
    @Override
    public void onAnimationStart(Animator animation) {
        // no-op
    }

    @Override
    public void onAnimationEnd(Animator animation) {
        // no-op
    }

    @Override
    public void onAnimationCancel(Animator animation) {
        // no-op
    }

    @Override
    public void onAnimationRepeat(Animator animation) {
        // no-op
    }
}
