package com.server.client.engine.app.fragments;

import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;


import com.server.client.R;
import com.server.client.engine.app.client.menu.ClientLayout;

public class ClientFragment extends Fragment {

    public static String TAG = ClientFragment.class.getSimpleName();

    private static final String EXTRA_TEXT = "text";
    private Context mContext;
    private ClientLayout mClientLayout;
    
    public static ClientFragment createFor(String text) {
        ClientFragment fragment = new ClientFragment();
        Bundle args = new Bundle();
        args.putString(EXTRA_TEXT, text);
        fragment.setArguments(args);
        return fragment;
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_app_client, container, false);
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        mContext = getActivity();
        final String text = getArguments().getString(EXTRA_TEXT);
        mClientLayout = (ClientLayout)view.findViewById(R.id.sdcard_monitor);
        
        Toast.makeText(mContext, text, Toast.LENGTH_SHORT).show();
    } 
}

