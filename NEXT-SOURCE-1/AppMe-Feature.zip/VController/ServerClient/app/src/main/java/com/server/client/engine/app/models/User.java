package com.server.client.engine.app.models;

/**
 * Created by lcampos on 2015-09-21.
 */
public class User {
}
