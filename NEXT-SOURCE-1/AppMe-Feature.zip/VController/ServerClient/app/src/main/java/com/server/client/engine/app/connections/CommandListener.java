package com.server.client.engine.app.connections;

import android.content.Intent;
import android.content.Context;
import android.os.Handler;
import android.util.Log;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

import com.server.client.R;
import com.server.client.AppController;
import com.server.client.engine.app.config.Command;

public class CommandListener {
    
    public static String TAG = CommandListener.class.getSimpleName();
    private static volatile CommandListener Instance = null;
    private Context context;
    
    public static CommandListener getInstance() {
        CommandListener localInstance = Instance;
        if (localInstance == null) {
            synchronized (CommandListener.class) {
                localInstance = Instance;
                if (localInstance == null) {
                    Instance = localInstance = new CommandListener(AppController.getContext());
                }
            }
        }
        return localInstance;
    }

    private CommandListener(Context context) {
        this.context = context;
    }

    public static CommandListener with(Context context) {
        return new CommandListener(context);
    }
    
    public void onCommandListener(Handler responseRequestHandler, String read, Socket clientSocket)
    {
        if (read != null) {
            responseRequestHandler.post(new responseRequestThread(clientSocket, read));
        } else if (null == read || Command.MESSAGE_CLIENT_DISCONNECT.contentEquals(read)) {
            Thread.interrupted();        
            read = "Offline....";          
        } else if (null == read || Command.REQUEST_CLIENT_FEATUR.contentEquals(read)) {
          
        }
        else if (null == read || Command.REQUEST_CLIENT_SERVICE.contentEquals(read)) {
            
        }
        
    }
    
    private class responseRequestThread implements Runnable {
        private Socket clientSocket;
        private String request;

        public responseRequestThread(Socket clientSocket, String request) {
            this.clientSocket = clientSocket;
            this.request = request;
        }

        @Override
        public void run() {
            try {
                Log.d(TAG, "message: " + request);
                PrintWriter out;
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())), true);

                if (request.equals(Command.REQUEST_CLIENT_FEATUR)) {
                    out.println("Request Diterima..Tunggu Sebentar");
                } else if (request.equals(Command.REQUEST_CLIENT_SERVICE)) {
                    out.println("Request Diterima..Tunggu Sebentar");
                } else {
                    out.println("Hello, I'm a server");
                }
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
