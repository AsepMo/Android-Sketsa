package com.controller.client;

import android.app.Application;
import android.content.Context;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import com.controller.client.engine.widget.soundPool.SoundPoolManager;
import com.controller.client.engine.widget.soundPool.ISoundPoolLoaded;

public class AppController extends Application {
    
    public static String TAG = AppController.class.getSimpleName();
    private static AppController isInstance;
    private static Context mContext;
    
    @Override
    public void onCreate() {
        super.onCreate();

        isInstance = this;
        mContext = this;
        
        SoundPool();
    }

    public static synchronized AppController getInstance() {
        return isInstance;
    }

    public static Context getContext() {
        return mContext;
    }

    public void SoundPool() {
        SoundPoolManager.CreateInstance();
        List<Integer> sounds = new ArrayList<Integer>();
        sounds.add(R.raw.jumping);
        sounds.add(R.raw.jumping_fail);
        sounds.add(R.raw.add);
        sounds.add(R.raw.done);
        sounds.add(R.raw.error);
        SoundPoolManager.getInstance().setSounds(sounds);
        try {
            SoundPoolManager.getInstance().InitializeSoundPool(getApplicationContext(), new ISoundPoolLoaded() {
                    @Override
                    public void onSuccess() {

                    }
                });
        } catch (Exception e) {
            e.printStackTrace();
        }

        SoundPoolManager.getInstance().setPlaySound(true);
    }
}
