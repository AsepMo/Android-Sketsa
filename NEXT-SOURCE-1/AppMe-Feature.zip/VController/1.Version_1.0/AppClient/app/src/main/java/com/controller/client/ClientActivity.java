package com.controller.client;
 
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

import com.controller.client.engine.app.connections.ConnectionManager;
import com.controller.client.engine.app.command.Command;
import com.controller.client.engine.app.fragments.CameraClientFragment;

public class ClientActivity extends FragmentActivity implements ConnectionManager.IOIOResponseListener, ConnectionManager.ConnectionListener, OnClickListener{
    public static String TAG = ClientActivity.class.getSimpleName();
   
    public String dest_ip="", et_ip="";
    private ConnectionManager connectionManager;

    private static Boolean isQuit = false;
    private Timer timer = new Timer();
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client);
        
        Intent intent = getIntent();
        dest_ip = intent.getStringExtra("iptext");

        connectionManager = new ConnectionManager(this, dest_ip, "1234");
        connectionManager.start();
        connectionManager.setConnectionListener(this);
        connectionManager.setResponseListener(this);
       // switchFragment(new CameraClientFragment());
    }
    
    public void switchFragment(Fragment fragment) {
        getSupportFragmentManager()
            .beginTransaction()
            .replace(R.id.content_frame, fragment)
            .commit();
    } 
    
    @Override
    public void onClick(View v) {
    }
    
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add("Sound")
            //.setIcon(R.drawable.ic_microphone)
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    playStory();
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);
        menu.add("Camera")
            //.setIcon(R.drawable.ic_camera)
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    playSong();
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);  
        menu.add("Video")
            //.setIcon(R.drawable.ic_camera)
            .setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener(){
                @Override
                public boolean onMenuItemClick(MenuItem item) {
                    requestAutoFocus();
                    return true;
                }
            }).setShowAsAction(MenuItem.SHOW_AS_ACTION_IF_ROOM);  
        return super.onCreateOptionsMenu(menu);
    }
    
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (!isQuit) {
                isQuit = true;
                Toast.makeText(getBaseContext(), R.string.app_press_back_againt_to_exit, Toast.LENGTH_LONG).show();
                TimerTask task = null;
                task = new TimerTask() {
                    @Override
                    public void run() {
                        isQuit = false;
                    }
                };
                timer.schedule(task, 2000);
            } else {
                finish();
                System.exit(0);
            }
        }
        return false;
    }

    @Override
    public void onConnectionDown() {
        showToast(getString(R.string.app_connection_down));
        finish();
    }

    @Override
    public void onConnectionFailed() {
        showToast(getString(R.string.app_connection_failed));
        finish();
    }

    @Override
    public void onWrongPassword() {
        showToast(getString(R.string.app_wrong_password));
        finish();
    }

    @Override
    public void onIOIOConnected() {
        showToast(getString(R.string.app_connection_accepted));
    }
    public void showToast(String message) {
        Toast.makeText(getApplicationContext(), message, Toast.LENGTH_SHORT).show();
    }
    @Override
    public void onPictureTaken() {
        showToast(getString(R.string.app_photo_taken));
    }

    @Override
    public void onFlashUnavailable() {
        showToast(getString(R.string.app_unsupport_flash));
    }

    @Override
    public void onCameraImageIncoming(Bitmap bitmap) {
       
    }

    /**
     *
     */
    public void playSong() {
        connectionManager.sendCommand(Command.PLAYSONG);

    }

    public void playStory() {
        connectionManager.sendCommand(Command.PLAYSTORY);

    }

    public void playPause() {
        connectionManager.sendCommand(Command.PLAYPAUSE);

    }
    public void requestAutoFocus() {
        connectionManager.sendCommand(Command.FOCUS);

    }

    public void requestInitCar() {
        connectionManager.sendCommand(Command.INIT);

    }

    public void requestTakePhoto() {
        connectionManager.sendCommand(Command.SNAP);
    }

    public void requestFlash(CompoundButton buttonView, boolean isChecked) {
        if (isChecked) {
            connectionManager.sendCommand(Command.LED_ON);
        } else {
            connectionManager.sendCommand(Command.LED_OFF);
        }
    }

    /**
     *  control fragment set move command to this activity
     */
    public void sendMovement(String move, int speed) {
        connectionManager.sendMovement(move + speed);
    }

    public void sendStop() {
        Log.d("server", "sendStop=========================");
        connectionManager.sendMovement(Command.STOP);
        // connectionManager.sendMovement(Command.STOP);
    }

    @Override
    protected void onStart() {
        Log.v(TAG, "onStart");
        super.onStart();
        playSong();
    }

    @Override
    protected void onRestart() {
        Log.v(TAG, "onRestart");
        super.onRestart();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v(TAG, "onResume");
    }
    
    @Override
    protected void onPause() {
        Log.v(TAG, "onPause");
        super.onPause();
        playPause();
    }

    @Override
    protected void onStop() {
        Log.v(TAG, "onStop");
        super.onStop();
        connectionManager.stop();
        playPause();
    }
    
    @Override
    protected void onDestroy() {
        Log.v(TAG, "onDestroy");
        super.onDestroy();
        playPause();
    }

    @Override
    public void finish() {
        Log.v(TAG, "finish");
        super.finish();
    }
    
    
}
