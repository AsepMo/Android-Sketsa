package com.controller.client.engine.app.tasks;

public class ClientTask {
    
    public static String TAG = ClientTask.class.getSimpleName();
    
}
