package com.controller.client;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;

import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.util.Timer;
import java.util.TimerTask;

import com.controller.client.engine.app.utils.LoadingUtils;
import com.controller.client.receiver.WifiStateReceiver;
import com.controller.client.engine.widget.soundPool.SoundPoolManager;

public class ConnectActivity extends FragmentActivity implements Runnable, WifiStateReceiver.BRInteraction {

    public static String TAG = ConnectActivity.class.getSimpleName();
    private ImageView mIconLoading;
    private TextView mTextLoading;
    private TextView mCurrentStatus;
    private TextView mCurrentLine;

    private MulticastSocket ds;
    private String multicastHost = "224.0.0.1";
    private InetAddress receiveAddress;
    private WifiManager wifiManager;
    private WifiInfo wifiInfo;
    private String ip;
    private int port = 8093;
    private WifiStateReceiver wifiStateReceiver;


    private Handler myHandler = null;
    private Message msg = new Message();
    private String temp_ip = "";

    private  boolean isRun = true;
    private static Boolean isQuit = false;
    private Timer timer = new Timer();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_connection);

        mIconLoading = (ImageView)findViewById(R.id.icon_loading);
        LoadingUtils.setProgressVisibility(mIconLoading, true);
        mTextLoading = (TextView)findViewById(R.id.loading_info);
        mTextLoading.setText("Waiting for connect");
        mCurrentStatus = (TextView)findViewById(R.id.current_status);
        mCurrentStatus.setText(R.string.app_searching_server);
        mCurrentLine = (TextView)findViewById(R.id.current_line);
        mCurrentLine.setText("Please wait..");

        wifiStateReceiver = new WifiStateReceiver();
        wifiStateReceiver.setBRInteractionListener(this);
        wifiManager = (WifiManager) getSystemService(Context.WIFI_SERVICE);

        if (!wifiManager.isWifiEnabled()) {
            wifiManager.setWifiEnabled(true);
        }

        wifiInfo = wifiManager.getConnectionInfo();
        int ipAddress = wifiInfo.getIpAddress();


        ip = intToIp(ipAddress);
        mCurrentStatus.setText("IP : " + ip);
    }


    private String intToIp(int i) {

        return (i & 0xFF) + "." + ((i >> 8) & 0xFF) + "." + ((i >> 16) & 0xFF)
            + "." + (i >> 24 & 0xFF);
    }

    @Override
    public void run() {
        // TODO Auto-generated method stub
        byte buf[] = new byte[1024];
        DatagramPacket dp = new DatagramPacket(buf, buf.length, receiveAddress, port);                                           
        while (isRun) {
            try {
                ds.receive(dp);
                buf = dp.getData();
                ip = new String(buf, 0, dp.getLength());
                msg = myHandler.obtainMessage();
                msg.what = 1;
                msg.obj = ip;
                if (!temp_ip.equals(ip)) {
                    temp_ip = ip;
                    myHandler.sendMessage(msg);

                }
                Thread.sleep(3000);
                dp = new DatagramPacket(buf, buf.length, receiveAddress, 8093);

            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void Start() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        this.registerReceiver(wifiStateReceiver, filter);
    }

    @Override
    public void setText(String content) {

        myHandler = new Handler() {
            @Override
            public void handleMessage(Message msg) {
                super.handleMessage(msg);

                mCurrentStatus.setText("Connect To Server..");
                mCurrentLine.setText((String) msg.obj);
                SoundPoolManager.getInstance().playSound(R.raw.add);
                Intent mIntent = new Intent(ConnectActivity.this, ClientActivity.class);
                mIntent.putExtra("iptext", (String) msg.obj);
                isRun = false;
                startActivity(mIntent);
                finish();
            }
        };

        if (content != null) {
            Log.e("APActivity", "CONNECTED");
            wifiInfo = wifiManager.getConnectionInfo();
            ip = intToIp(wifiInfo.getIpAddress());
            mCurrentStatus.setText("IP ：" + ip);
            mCurrentLine.setText("Please wait……");

            try {
                ds = new MulticastSocket(8093);
                receiveAddress = InetAddress.getByName(multicastHost);
                ds.joinGroup(receiveAddress);
                new Thread(this).start();
            } catch (Exception e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }
            // broadcast(ip);
            // textView.setText(content);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {

        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (!isQuit) {
                isQuit = true;
                Toast.makeText(getBaseContext(),  R.string.app_press_back_againt_to_exit, Toast.LENGTH_LONG).show();
                TimerTask task = null;
                task = new TimerTask() {
                    @Override
                    public void run() {
                        isQuit = false;
                    }
                };
                timer.schedule(task, 2000);
            } else {
                finish();
                System.exit(0);
            }
        }
        return false;
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.v(TAG, "onStart:"); 
        Start();
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.v(TAG, "onResume:");  
    }

    @Override
    protected void onPause() {
        super.onPause();
        Log.v(TAG, "onPause:");
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.v(TAG, "onDestroy:");
        this.unregisterReceiver(wifiStateReceiver);
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Log.v(TAG, "onBackPressed:");
    }


}

