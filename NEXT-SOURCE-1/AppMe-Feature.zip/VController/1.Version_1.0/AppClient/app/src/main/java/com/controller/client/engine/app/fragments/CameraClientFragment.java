package com.controller.client.engine.app.fragments;

import android.support.v4.app.Fragment;
import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.Image;
import android.graphics.Matrix;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Surface;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;

import com.controller.client.R;
import com.controller.client.ClientActivity;
import com.controller.client.engine.app.controller.JoyStickManager;
import com.controller.client.engine.app.controller.JoyStickView;
import com.controller.client.engine.app.connections.ConnectionManager;
import com.controller.client.engine.app.command.Command;

public class CameraClientFragment extends BaseFragment implements OnClickListener, JoyStickManager.JoyStickEventListener {

    public static String FRAGMENT_TAG = CameraClientFragment.class.getSimpleName();
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String EXTRA_CAMERA = "EXTRA_CAMERA";
    private String message;
    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @return A new instance of fragment Record_Fragment.
     */
    public static CameraClientFragment newInstance(String msg) {
        CameraClientFragment f = new CameraClientFragment();
        Bundle b = new Bundle();
        b.putString(EXTRA_CAMERA, msg);
        f.setArguments(b);

        return f;
    }

    public CameraClientFragment() {
    }

    private View mRootView;
    private ImageView mCameraView;
    private TextView mCameraInfo;
    private RelativeLayout mJoyStickLayout;
    public ConnectionManager connectionManager;

    private ClientActivity activity;
    private int screenHeight;
    private JoyStickManager joyStickManager;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        message = getArguments().getString(EXTRA_CAMERA);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.fragment_app_client, container, false);    

        
        return mRootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mCameraView = (ImageView)view.findViewById(R.id.camera);
        mCameraInfo = (TextView)view.findViewById(R.id.camera_info);
        mJoyStickLayout = (RelativeLayout)view.findViewById(R.id.layout_joystick);
        mJoyStickLayout.setOnClickListener(this);
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
    }


    @Override
    public void onClick(View v) {
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onActivityCreated(savedInstanceState);
        activity = (ClientActivity) getActivity();

        screenHeight = activity.getWindowManager().getDefaultDisplay().getHeight();
        screenHeight=screenHeight*7/10;
        joyStickManager = new JoyStickManager(activity, mJoyStickLayout, screenHeight);
        joyStickManager.setJoyStickEventListener(this);

    }

    @Override
    public void showImage(Bitmap bitmap) {
        
    }

    @Override
    public void onJoyStickUp(int speed) {
        activity.sendMovement(Command.FORWARD, speed);
    }

    @Override
    public void onJoyStickUpRight(int speed) {
        activity.sendMovement(Command.FORWARD_RIGHT, speed);
    }

    @Override
    public void onJoyStickUpLeft(int speed) {
        activity.sendMovement(Command.FORWARD_LEFT, speed);
    }

    @Override
    public void onJoyStickDown(int speed) {
        activity.sendMovement(Command.BACKWARD, speed);
    }

    @Override
    public void onJoyStickDownRight(int speed) {
        activity.sendMovement(Command.BACKWARD_RIGHT, speed);
    }

    @Override
    public void onJoyStickDownLeft(int speed) {
        activity.sendMovement(Command.BACKWARD_LEFT, speed);
    }

    @Override
    public void onJoyStickRight(int speed) {
        activity.sendMovement(Command.RIGHT, speed);
    }

    @Override
    public void onJoyStickLeft(int speed) {
        activity.sendMovement(Command.LEFT, speed);
    }

    @Override
    public void onJoyStickNone() {
        activity.sendStop();
    }
}
