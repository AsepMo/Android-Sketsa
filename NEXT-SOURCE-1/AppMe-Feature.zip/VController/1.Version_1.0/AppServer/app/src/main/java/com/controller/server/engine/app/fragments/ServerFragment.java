package com.controller.server.engine.app.fragments;

import android.support.v4.app.Fragment;
import android.app.AlertDialog;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.net.wifi.WifiManager.MulticastLock;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.Display;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MenuInflater;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import com.controller.server.R;
import com.controller.server.engine.app.manager.CameraManager;
import com.controller.server.engine.app.manager.ConnectionManager;
import com.controller.server.engine.app.manager.OrientationManager;
import com.controller.server.engine.app.constant.Command;
import com.controller.server.engine.app.constant.DirectionState;
import com.controller.server.engine.app.utils.BlueTooth;
import com.controller.server.engine.app.utils.Kalman;
import com.controller.server.engine.app.utils.Method;
import com.controller.server.engine.app.utils.Sensors;
import com.controller.server.engine.widget.VideoBox;
import com.controller.server.engine.widget.soundPool.SoundPoolManager;
import com.controller.server.service.MusicService;
import com.controller.server.service.MusicService.MyBinder;
import com.controller.server.receiver.WifiStateReceiver;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

public class ServerFragment extends Fragment implements WifiStateReceiver.BRInteraction, ConnectionManager.ConnectionListener, ConnectionManager.ControllerCommandListener, ConnectionManager.SendCommandListener {

    public static String TAG = ServerFragment.class.getSimpleName();
    private Activity mActivity;
    private Context mContext;
    private View mRootView;
    private VideoBox mVideoBox;
    private static int defaultPort = 8888;
    public static ArrayList<Socket> socketList = new ArrayList<Socket>();
    private Handler handler = null;
    private Socket socket = null;
    private String tag = "chatRoom";
    private BufferedReader buRead = null;

    private final int UPDATE_HISTORY_CONTENT = 0;
    private final int UPDATE_INPUT_CONTENT = 1;
    private final int UPDATE_IP_CONTENT = 3;
    private final int MUSIC_PLAYSONG = 4;
    private final int MUSIC_PLAYSTORY = 5;
    private final int MUSIC_PAUSE = 6;

    private WifiStateReceiver wifiStateReceiver;
    private ServerSocket ss;
    private WifiManager wifiManager;
    private WifiInfo wifiInfo;
    private MyThread t;
    private InetAddress address;

    private String local_ip, dest_ip=null;

    private volatile boolean isBroadcastRuning = true, serverrun = true, mBound = false;

    private MulticastSocket ms;
    MulticastLock multicastLock;
    DatagramPacket dataPacket = null;

    Thread clientThread, serverThread;
    private MusicService audioService;
    Intent serviceIntent;

    private boolean isConnected = false;
    private OutputStream outputStream;
    private DataOutputStream dos;

    private ConnectionManager connectionManager;

    private String password="1234";
    private ServiceConnection conn = new ServiceConnection() {

        @Override
        public void onServiceDisconnected(ComponentName name) {
            // TODO Auto-generated method stub
            audioService = null;
        }

        @Override
        public void onServiceConnected(ComponentName name, IBinder binder) {
            //audioService binder
            MyBinder myBinder = (MyBinder) binder;
            audioService = (MusicService) myBinder.getService();
            mBound = true;
        }
    };

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        mRootView = inflater.inflate(R.layout.fragment_app_server, container, false);
        return mRootView;
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        mContext = getActivity();
        mActivity = (Activity)mContext;
        mVideoBox = (VideoBox)view.findViewById(R.id.ivVideo);
        mVideoBox.setVideoThumbnail(R.drawable.image_1);
        
        wifiStateReceiver = new WifiStateReceiver();
        wifiStateReceiver.setBRInteractionListener(this);
        wifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);

        if (!wifiManager.isWifiEnabled()) {
            wifiManager.setWifiEnabled(true);
        } else {
            wifiInfo = wifiManager.getConnectionInfo();
            int ipAddress = wifiInfo.getIpAddress();
            local_ip = intToIp(ipAddress);
        }

        
        serviceIntent = new Intent(mContext, MusicService.class);

        if (!mBound) {
            mContext.bindService(serviceIntent, conn, Context.BIND_AUTO_CREATE);
        }
        initService();
    }

    private void initService() {
        initWifi();
        connectionManager = new ConnectionManager(password);
        connectionManager.start();
        connectionManager.setConnectionListener(this);
        connectionManager.setCommandListener(this);
        connectionManager.setSendCommandListener(this);
        serverrun = false;
        Log.d(tag, "onCreate===================");
    }

    private void initWifi() {

        IntentFilter filter = new IntentFilter();
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        mContext.registerReceiver(wifiStateReceiver, filter);
    }

    public class MyThread extends Thread {

        @Override
        public void run() {

            byte[] data = local_ip.getBytes();
            while (isBroadcastRuning) {
                data = local_ip.getBytes();
                dataPacket = new DatagramPacket(data, data.length, address, 8093);                                                
                try {
                    ms.send(dataPacket);
                    Thread.sleep(3000);

                    Log.e(TAG, "broadcast over000000");

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            try {
                ms.leaveGroup(address);
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            ms.close();
        }
    }

    @Override
    public void onStop() {
        Log.i("MainActivity", "onStop===============");
        connectionManager.stop();
        super.onStop();
    }

    @Override
    public void onDestroy() {
        // TODO Auto-generated method stub
        mContext.unregisterReceiver(wifiStateReceiver);

        Log.i("MainActivity", "onDestroy===============");
        serverrun = false;
        isConnected = false;
        try {
            if (ss != null)
                ss.close();          
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        mContext.unbindService(conn);
        mContext.stopService(serviceIntent);
        super.onDestroy();

    }

    public void showToast(String message) {
        Toast.makeText(mContext, message, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void setText(String content) {
        if (content != null) {
            Log.d("APActivityt", "setText=======CONNECTED,CONNECTED");
            wifiInfo = wifiManager.getConnectionInfo();
            local_ip = intToIp(wifiInfo.getIpAddress());

            broadcast(local_ip);
            
        }
    }
    
    private String intToIp(int i) {

        return (i & 0xFF) + "." + ((i >> 8) & 0xFF) + "." + ((i >> 16) & 0xFF)
            + "." + (i >> 24 & 0xFF);
    }

    private void allowMulticast() {
        WifiManager wifiManager = (WifiManager) mContext.getSystemService(Context.WIFI_SERVICE);
        multicastLock = wifiManager.createMulticastLock("multicast.test");
        multicastLock.acquire();
    }

    private void broadcast(String ip) {
        allowMulticast();

        try {         
            ms = new MulticastSocket(8093);
            ms.setTimeToLive(1);
            address = InetAddress.getByName("224.0.0.1");

            ms.joinGroup(address);

            t = new MyThread();
            t.start();

            Log.e("APActivityt", "broadcast over");
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        multicastLock.release();
    }

    @Override
    public void onControllerConnected(Socket socket) {
        isConnected = true;
        InetAddress ip = socket.getInetAddress();
        //tv_ip_view.setText("connected");

        isConnected = true;
        connectionManager.sendCommand(Command.ACCEPT_CONNECTION);
        SoundPoolManager.getInstance().playSound(R.raw.add);
    }

    @Override
    public void onWrongPassword() {
        connectionManager.sendCommand(Command.WRONG_PASSWORD);
        connectionManager.restart();
        SoundPoolManager.getInstance().playSound(R.raw.sound_error);
    }

    @Override
    public void onControllerDisconnected() {
        showToast(getString(R.string.app_server_connection_down));

        SoundPoolManager.getInstance().playSound(R.raw.sound_error);
    }

    @Override
    public void onControllerClosed() {

        SoundPoolManager.getInstance().playSound(R.raw.sound_error);

    }

    @Override
    public void onDataIncoming() {

    }

    @Override
    public void onFlashCommand(String command) {

    }

    @Override
    public void onRequestTakePicture() {

    }

    @Override
    public void onRequestAutoFocus() {
        mVideoBox.setVideoPath("android.resource://" + getActivity().getPackageName() + "/" + R.raw.loading_sound_effects);
    }

    @Override
    public void onRequestPlaySong() {
        if (mBound) {
            audioService.playSong();
            getActivity().setTitle("Play Song");
        }
    }
    
    @Override
    public void onRequestPlayStory() {
        if (mBound) {
            audioService.playStory();
            getActivity().setTitle("Play Story");
        }
    }

    @Override
    public void onRequestPlayPause() {
        if (mBound) {
            audioService.pause();
            getActivity().setTitle("Pause");
        }
    }

    @Override
    public void onMoveForwardCommand(int movementSpeed) {

    }

    @Override
    public void onMoveForwardRightCommand(int movementSpeed) {

    }

    @Override
    public void onMoveForwardLeftCommand(int movementSpeed) {

    }

    @Override
    public void onMoveBackwardCommand(int movementSpeed) {

    }

    @Override
    public void onMoveBackwardRightCommand(int movementSpeed) {

    }

    @Override
    public void onMoveBackwardLeftCommand(int movementSpeed) {

    }

    @Override
    public void onMoveLeftCommand(int movementSpeed) {

    }

    @Override
    public void onMoveRightCommand(int movementSpeed) {

    }

    @Override
    public void onMoveStopCommand() {

    }

    @Override
    public void onInitCommand() {

    }

    @Override
    public void onSendCommandSuccess() {

    }

    @Override
    public void onSendCommandFailure() {
        isConnected = false;
    }
}
