package com.controller.server;
 
import android.support.v4.app.FragmentActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

import com.controller.server.application.Application;
import com.controller.server.engine.app.models.VideoData;
import com.controller.server.engine.app.folders.FolderMe;

public class SplashActivity extends FragmentActivity { 
    public static String TAG = SplashActivity.class.getSimpleName();
    
    private Application mApplication;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        mApplication = Application.getInstance();
        mApplication.setPermission(SplashActivity.this, mApplication.requestPermissionStorage, new Application.OnActionPermissionListener(){
                @Override
                public void onGranted() {
                    setTransition();
                    FolderMe.initVideoBox(SplashActivity.this);    
                }

                @Override
                public void onDenied(String permission) {

                    Log.i(TAG, "onDenied: Write Storage: " + permission);
                    String message = String.format(Locale.getDefault(), getString(R.string.message_denied), permission);
                    Toast.makeText(SplashActivity.this, message, Toast.LENGTH_SHORT).show();
                }    
            });
        
    }
    
    public void setTransition() {
        int SPLASH_TIME_OUT = 2000;
        new Handler().postDelayed(new Runnable() {

                /*
                 * Showing splash screen with a timer. This will be useful when you
                 * want to show case your app logo / company
                 */

                @Override
                public void run() {

                    Application.getInstance().setApplicationTaskListener(SplashActivity.this, new Application.OnApplicationTaskListener(){
                            @Override
                            public void onPreExecute() {
                                Application.getInstance().soundPlay(R.raw.add);
                            }

                            @Override
                            public void onSuccess(ArrayList<VideoData> result) {
                                Intent mIntent = new Intent(SplashActivity.this, ServerActivity.class);
                                startActivity(mIntent);    
                                SplashActivity.this.finish();                                  
                                Application.getInstance().soundPlay(R.raw.done);
                            }

                            @Override
                            public void onFailed() {
                                Application.getInstance().soundPlay(R.raw.error);
                            }

                            @Override
                            public void isEmpty() {

                            } 
                        });                                                                
                }
            }, SPLASH_TIME_OUT); 
    }

}
