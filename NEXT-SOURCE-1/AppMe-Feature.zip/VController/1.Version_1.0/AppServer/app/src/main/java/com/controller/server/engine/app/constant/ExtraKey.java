package com.controller.server.engine.app.constant;

/**
 * Created by Akexorcist on 9/5/15 AD.
 */
public class ExtraKey {
    public static final String SETUP_PREFERENCE = "setup_preference";
    public static final String QUALITY = "quality";
    public static final String PREVIEW_SIZE = "preview_size";
    public static final String OWN_PASSWORD = "own_password";
    public static final String TARGET_PASSWORD = "target_password";
    public static final String IP_ADDRESS = "ip_address";

}
