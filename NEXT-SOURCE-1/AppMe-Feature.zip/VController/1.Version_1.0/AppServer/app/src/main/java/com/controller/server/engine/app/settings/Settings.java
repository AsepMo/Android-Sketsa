package com.controller.server.engine.app.settings;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Environment;
import android.preference.PreferenceManager;

import java.io.File;
import java.security.InvalidParameterException;
import java.util.Comparator;

public class Settings {
    
    public static String TAG = Settings.class.getSimpleName();
    private static SharedPreferences prefs;
    private static final String NAME = "SharedPref";
    
    public static void init(Context context)
    {
        prefs =PreferenceManager.getDefaultSharedPreferences(context) ;
    }
    
    
    public static void setIsShortCut(Context context, Boolean isLogin) {
        SharedPreferences sp = context.getSharedPreferences(NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sp.edit();
        editor.putBoolean("isShortCut", isLogin);
        editor.commit();
    }

    public static Boolean isShortCut(Context context) {
        SharedPreferences sp = context.getSharedPreferences(NAME, Context.MODE_PRIVATE);
        return sp.getBoolean("isShortCut", false);
    }
    
    
    public static String getWebFileMd5()
    {
        return prefs.getString("web_file_md5", "");
    }
    
    public static void setWebFileMd5(String md5)
    {
        prefs.edit().putString("web_file_md5", md5).commit();
    }
    
    public static int getPort()
    {
        return prefs.getInt("server_port", 8080);
    }
    
    public static void setPort(int port){
        prefs.edit().putInt("server_port", port).commit();
	}
}
