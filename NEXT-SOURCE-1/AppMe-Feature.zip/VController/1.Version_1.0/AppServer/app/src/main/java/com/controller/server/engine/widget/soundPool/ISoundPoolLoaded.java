package com.controller.server.engine.widget.soundPool;

public interface ISoundPoolLoaded {
    public void onSuccess();
}
