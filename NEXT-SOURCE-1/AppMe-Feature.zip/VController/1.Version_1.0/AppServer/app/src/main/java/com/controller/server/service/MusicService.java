package com.controller.server.service;

import java.io.IOException;

import android.app.Service;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;

import com.controller.server.R;
import com.controller.server.application.Application;

public class MusicService extends Service {

    private static final String TAG = MusicService.class.getSimpleName();
    
    public IBinder musicBinder  = new MyBinder();
    private MediaPlayer mediaPlayer;
    private String path = "/storage/sdcard1/Music/浪漫满屋.mp3";
    
    @Override
    public void onCreate() {
        super.onCreate();
        Log.d(TAG, "onCreate() executed");

        init();

    }

    @Override
    public IBinder onBind(Intent arg0) {
        // TODO Auto-generated method stub
        return musicBinder;
    }

    public class MyBinder extends Binder{

        public Service getService(){
            return MusicService.this;
        }
    }

    
    public void init(){

       try {
            mediaPlayer = MediaPlayer.create(this,R.raw.sound1); //new MediaPlayer();
           
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);

            // prepare 
            mediaPlayer.prepareAsync();

        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }

    public double getProgress(){
        int position = mediaPlayer.getCurrentPosition();

        int time = mediaPlayer.getDuration();

        double progress = (double)position / (double)time;

        return progress;
    }

    public void setProgress(int max , int dest){
        int time = mediaPlayer.getDuration();
        mediaPlayer.seekTo(time*dest/max);
    }

    public void play(){
        if(mediaPlayer != null){
            mediaPlayer.start();
        }
    }
    
    public void pause() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
        }
    }

    public void playSong(){
        if (mediaPlayer != null){
          
            mediaPlayer.reset();
            try {
                mediaPlayer.setDataSource(this,Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.sound_error));
                mediaPlayer.setLooping(true);
                mediaPlayer.prepare();
                mediaPlayer.start();
            } catch (IllegalArgumentException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SecurityException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IllegalStateException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
    }

    public void playStory(){
        if (mediaPlayer != null){
            mediaPlayer.reset();
            try {
                mediaPlayer.setDataSource(this,Uri.parse("android.resource://" + getPackageName() + "/" + R.raw.sound1));
                mediaPlayer.prepare();
                mediaPlayer.setLooping(true);
                mediaPlayer.start();
            } catch (IllegalArgumentException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (SecurityException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IllegalStateException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }

        }
    }

    
    @Override
    public void onDestroy() {
        if (mediaPlayer != null && mediaPlayer.isPlaying()) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        super.onDestroy();
    }
}

