package com.razor.broadcast;

public class Command {
    public static final String REQUEST_FEATUR = "Request Featur";
    public static final String REQUEST_SALAM = "hei";
    
}
