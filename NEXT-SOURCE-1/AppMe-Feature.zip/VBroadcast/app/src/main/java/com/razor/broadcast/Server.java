package com.razor.broadcast;

import android.content.Context;
import android.os.Vibrator;
import android.os.Handler;
import android.util.Log;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;

public class Server {
   
    private static Context mContext;
    private static Server _instance;

    private ServerSocket serverSocket;

    Handler responseRequestHandler;

    Thread serverThread = null;
    public static final int SERVER_PORT = 5050;

    public static Server getInstance() {
        if (_instance == null) {
            _instance = new Server(mContext);
        }

        return _instance;
    }

    public Server(Context context) {
        this.mContext = context;
        responseRequestHandler = new Handler();
    }

    public void init() {
        serverThread = new Thread(new ServerThread());
        serverThread.start();
    }

    public void stop() {
        try {
            serverSocket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private class ServerThread extends Thread {
        public void run() {
            Socket socket = null;
            try {
                serverSocket = new ServerSocket(SERVER_PORT);
            } catch (IOException e) {
                e.printStackTrace();
            }
            while (!Thread.currentThread().isInterrupted()) {

                try {

                    socket = serverSocket.accept();

                    CommunicationThread commThread = new CommunicationThread(mContext, socket);
                    new Thread(commThread).start();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class CommunicationThread extends Thread {
        private Socket clientSocket;
        private BufferedReader input;
        private Context c;
        public CommunicationThread(Context c, Socket clientSocket) {
            this.c = c;
            this.clientSocket = clientSocket;
            try {
                this.input = new BufferedReader(new InputStreamReader(this.clientSocket.getInputStream()));
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        public void run() {
            while (!Thread.currentThread().isInterrupted()) {
                try {
                    String read = input.readLine();
                    if (read != null) {
                        responseRequestHandler.post(new responseRequestThread(clientSocket, read));
                    }if (null == read || Command.REQUEST_SALAM.contentEquals(read)) {
                        Thread.interrupted();
                        read = "Offline....";
                        Vibrator vibrate = (Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);
                        vibrate.vibrate(300);
                        break;
                    }
                } catch (UnknownHostException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private class responseRequestThread implements Runnable {
        private Socket clientSocket;
        private String request;

        public responseRequestThread(Socket clientSocket, String request) {
            this.clientSocket = clientSocket;
            this.request = request;
        }

        @Override
        public void run() {
            try {
                Log.d("TAGTAG", "message: " + request);
                PrintWriter out;
                out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(clientSocket.getOutputStream())), true);
                        
                if (request.equals(Command.REQUEST_FEATUR)) {
                    out.println("Keren Banget Dah..");
                }else if (request.equals(Command.REQUEST_SALAM)) {
                    out.println("hei,juga..");
                }
                else {
                    out.println("Hello, I'm a ");
                }
            } catch (UnknownHostException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
