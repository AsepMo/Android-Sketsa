package com.github.template.engine.widget.soundPool;

public interface ISoundPoolLoaded {
    public void onSuccess();
}
