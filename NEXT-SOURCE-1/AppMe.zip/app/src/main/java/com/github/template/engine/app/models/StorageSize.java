package com.github.template.engine.app.models;

public class StorageSize {

    public float value;

    public String suffix;

}

