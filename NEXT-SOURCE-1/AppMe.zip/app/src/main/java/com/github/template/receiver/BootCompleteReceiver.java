package com.github.template.receiver;

import android.content.Context;
import android.content.Intent;
import android.content.BroadcastReceiver;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

import com.github.template.R;
import com.github.template.service.CleanerService;

public class BootCompleteReceiver extends BroadcastReceiver {

    public static String TAG = BootCompleteReceiver.class.getSimpleName();
    
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);

        String action = intent.getAction();

        if (action != null) {
            if (action.equals(Intent.ACTION_BOOT_COMPLETED)) {
                if (sharedPreferences.getBoolean(context.getString(R.string.clean_on_system_startup_key), false)) {
                    Intent serviceIntent = new Intent(context, CleanerService.class);
                    serviceIntent.setAction(CleanerService.ACTION_CLEAN_AND_EXIT);
                    context.startService(serviceIntent);
                }
            }
        }
    }
    
    
}
