package com.github.template.engine.view;

public class MenuMore {
    
    public static String TAG = MenuMore.class.getSimpleName();
    
}