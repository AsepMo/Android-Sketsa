package com.github.template.engine.app.models;

public class SDCardInfo {
    public long total;

    public long free;
}

