package com.github.template.engine.widget.callback;

public interface DragListener {

    void onDrag(float progress);
}
