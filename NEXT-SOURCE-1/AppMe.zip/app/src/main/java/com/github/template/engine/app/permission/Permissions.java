package com.github.template.engine.app.permission;

public enum Permissions {
    GRANTED,
    DENIED,
    NOT_FOUND
    }

